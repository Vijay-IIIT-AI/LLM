import os
import json
import asyncio
import re
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime
from typing import Sequence

import pandas as pd

from autogen_core.models import ModelFamily
from autogen_core.memory import ListMemory, MemoryContent, MemoryMimeType

from autogen_agentchat.agents import AssistantAgent, CodeExecutorAgent
from autogen_agentchat.teams import SelectorGroupChat
from autogen_agentchat.messages import TextMessage, BaseChatMessage, StopMessage

from autogen_ext.models.openai import OpenAIChatCompletionClient
from autogen_ext.code_executors.local import LocalCommandLineCodeExecutor
from autogen_agentchat.agents._code_executor_agent import ApprovalResponse

import random

from utils import load_dataset, verify_dataset, run_with_retries, should_use_direct_qa, sheet_data_to_markdown, excel_has_merged_cells
from prompts import (
    manager_system_message,
    analysis_system_message,
    coder_system_message,
    qc_system_message,
    cleaner_system_message,
    returner_system_message,
    cleaning_planner_message,
    cleaning_coder_message,
    cleaning_qc_message,
)
from agent_config import (
    API_KEY,
    MODEL_BASE_URL,
    MODEL_NAME,
    MODEL_TEMPERATURE,
    WORKSPACE_DIR,
    CODE_EXECUTOR_TIMEOUT,
    MAX_TURNS_ANALYSIS_TEAM,
    MAX_TURNS_CLEANING_TEAM,
    DEFAULT_RETRIES,
    LOGS_DIR,
    LOG_MAX_BYTES,
    LOG_BACKUP_COUNT,
    LOG_LEVEL,
    PLOT_FOOTER_TEXT,
)


def _setup_logging(session_id: str) -> logging.Logger:
    """
    Set up logging with rotation for a specific session.
    
    Args:
        session_id: Unique identifier for this analysis session
        
    Returns:
        Configured logger instance
    """
    # Create logs directory if it doesn't exist
    os.makedirs(LOGS_DIR, exist_ok=True)
    
    # Create logger with session ID
    logger = logging.getLogger(f"analysis_{session_id}")
    logger.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))
    
    # Remove existing handlers to avoid duplicates
    logger.handlers.clear()
    
    # Create rotating file handler
    log_filename = os.path.join(LOGS_DIR, f"analysis_{session_id}.log")
    handler = RotatingFileHandler(
        log_filename,
        maxBytes=LOG_MAX_BYTES,
        backupCount=LOG_BACKUP_COUNT,
        encoding='utf-8'
    )
    
    # Set formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - [%(agent)s] - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    handler.setFormatter(formatter)
    
    logger.addHandler(handler)
    
    # Also add console handler for immediate feedback
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)  # Only show warnings and errors in console
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    return logger


def _build_model_client():
    return OpenAIChatCompletionClient(
        model=MODEL_NAME,
        base_url=MODEL_BASE_URL,
        api_key=API_KEY,
        model_info={
            "vision": True,
            "function_calling": True,
            "json_output": True,
            "family": ModelFamily.UNKNOWN,
            "structured_output": True,
            "multiple_system_messages": True,
        },
        temperature=MODEL_TEMPERATURE,
    )


def _build_cleaning_team(ollama_client, shared_memory):
    cleaning_planner = AssistantAgent(
        "cleaning_planner", ollama_client, memory=[shared_memory],
        system_message=cleaning_planner_message(WORKSPACE_DIR)
    )

    cleaning_coder = AssistantAgent(
        "cleaning_coder", ollama_client, memory=[shared_memory],
        system_message=cleaning_coder_message(WORKSPACE_DIR)
    )

    executor_clean = LocalCommandLineCodeExecutor(work_dir=WORKSPACE_DIR, timeout=CODE_EXECUTOR_TIMEOUT)

    cleaning_executor = CodeExecutorAgent(
        "cleaning_executor",
        code_executor=executor_clean,
        approval_func=lambda code: ApprovalResponse(
            approved=True,
            reason="Auto-approved for cleaning task"
        )
    )

    cleaning_qc = AssistantAgent(
        "cleaning_qc", ollama_client, memory=[shared_memory],
        system_message=cleaning_qc_message()
    )

    cleaning_team = SelectorGroupChat(
        participants=[cleaning_planner, cleaning_coder, cleaning_executor, cleaning_qc],
        model_client=ollama_client,
        max_turns=MAX_TURNS_CLEANING_TEAM,
    )

    async def run_cleaning(dataset_file: str, sheet_data: dict, logger: logging.Logger = None):
        cleaning_task = f"""
        Dataset file: {dataset_file}
        Sheets available: {list(sheet_data.keys())}

        Your job:
        - Clean messy headers (flatten, rename, stringify).
        - Save cleaned sheets in the current working directory (where code executes) as:
          cleaned_<randomid>_<sheetname>.xlsx
        - At the end, only return the absolute file paths.
        """
        if logger:
            logger.info("Starting data cleaning process", extra={"agent": "CLEANING_TEAM"})
        cleaned_paths = []
        async for msg in cleaning_team.run_stream(task=cleaning_task):
            if hasattr(msg, "content") and hasattr(msg, "source"):
                # Log cleaning team messages
                if logger:
                    try:
                        content = str(msg.content)[:500] if msg.content else ""
                        logger.info(f"Cleaning message from {msg.source}: {content}", extra={"agent": msg.source})
                    except Exception:
                        pass
                if msg.source == "cleaning_qc":
                    try:
                        cleaned_paths = json.loads(msg.content.strip())
                        if logger:
                            logger.info(f"Cleaned files: {cleaned_paths}", extra={"agent": "CLEANING_TEAM"})
                    except Exception as e:
                        if logger:
                            logger.warning(f"Error parsing cleaned paths: {e}", extra={"agent": "CLEANING_TEAM"})
                        pass
        return cleaned_paths

    return run_cleaning


def clean_unicode_spaces(text: str) -> str:
    """
    Clean problematic Unicode space characters from text.
    Replaces special Unicode spaces with regular spaces (U+0020).
    """
    if not isinstance(text, str):
        return text
    
    problematic_unicode_spaces = [
        '\u202f',  # Narrow no-break space
        '\u00a0',  # Non-breaking space
        '\u2009',  # Thin space
        '\u2008',  # Punctuation space
        '\u2007',  # Figure space
        '\u2006',  # Six-per-em space
        '\u2005',  # Four-per-em space
        '\u2004',  # Three-per-em space
        '\u2003',  # Em space
        '\u2002',  # En space
        '\u2001',  # Em quad
        '\u2000',  # En quad
    ]
    cleaned = text
    for unicode_space in problematic_unicode_spaces:
        cleaned = cleaned.replace(unicode_space, ' ')
    return cleaned


def find_recent_plot_files(search_dir: str, max_age_seconds: int = 300) -> list:
    """
    Find recently created plot files in the specified directory.
    
    Args:
        search_dir: Directory to search for plot files (should be Workspace folder)
        max_age_seconds: Maximum age of files to include (default 5 minutes)
    
    Returns:
        List of plot file paths, sorted by modification time (newest first)
    """
    import time
    import glob
    
    plot_extensions = ['*.png', '*.jpg', '*.jpeg', '*.gif', '*.svg']
    plot_files = []
    current_time = time.time()
    
    if not os.path.exists(search_dir):
        return plot_files
    
    for ext in plot_extensions:
        pattern = os.path.join(search_dir, ext)
        plot_files.extend(glob.glob(pattern))
    
    # Filter by modification time (recent files only)
    recent_plots = []
    for plot_file in plot_files:
        try:
            mtime = os.path.getmtime(plot_file)
            age = current_time - mtime
            if age <= max_age_seconds:
                recent_plots.append((plot_file, mtime))
        except Exception:
            continue
    
    # Sort by modification time (newest first) and return paths
    recent_plots.sort(key=lambda x: x[1], reverse=True)
    return [path for path, _ in recent_plots]


class StopWhenAnswered:
    def __init__(self):
        self._terminated = False

    @property
    def terminated(self):
        return self._terminated

    async def __call__(self, messages: Sequence[BaseChatMessage]):
        for msg in messages:
            if isinstance(msg, TextMessage):
                if msg.source == "returner" and len((msg.content or "").strip()) > 10:
                    self._terminated = True
                    return StopMessage(
                        source="terminator",
                        content="Workflow stopped: Final beautified Markdown answer delivered."
                    )
        return None

    async def reset(self):
        self._terminated = False


async def run_analysis(file_path: str, user_question: str, enable_cleaning: bool = False):
    # Generate unique session ID for this analysis
    session_id = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{random.randint(1000, 9999)}"
    
    # Set up logging for this session
    logger = _setup_logging(session_id)
    
    # Log session start
    logger.info(f"=== Analysis Session Started ===", extra={"agent": "SYSTEM"})
    logger.info(f"Session ID: {session_id}", extra={"agent": "SYSTEM"})
    logger.info(f"File: {file_path}", extra={"agent": "SYSTEM"})
    logger.info(f"Question: {user_question}", extra={"agent": "SYSTEM"})
    logger.info(f"Cleaning enabled: {enable_cleaning}", extra={"agent": "SYSTEM"})
    
    # Create fresh shared memory and reset termination condition for each run
    shared_memory = ListMemory()
    termination_condition = StopWhenAnswered()
    ollama_client = _build_model_client()

    manager_agent = AssistantAgent(
        "manager", ollama_client, memory=[shared_memory],
        system_message=manager_system_message(),
    )
    data_analysis_agent = AssistantAgent(
        "analysis", ollama_client, memory=[shared_memory],
        system_message=analysis_system_message(),
    )
    coding_agent = AssistantAgent(
        "coder", ollama_client, memory=[shared_memory],
        system_message=coder_system_message(WORKSPACE_DIR, PLOT_FOOTER_TEXT),
    )

    executor = LocalCommandLineCodeExecutor(work_dir=WORKSPACE_DIR, timeout=CODE_EXECUTOR_TIMEOUT)
    executor_agent = CodeExecutorAgent(
        "executor",
        code_executor=executor,
        approval_func=lambda code: ApprovalResponse(
            approved=True,
            reason="Auto-approved for execution (DEV ONLY)"
        )
    )

    qc_agent = AssistantAgent(
        "qc", ollama_client, memory=[shared_memory],
        system_message=qc_system_message(),
    )

    data_cleaner_agent = AssistantAgent(
        "cleaner", ollama_client, memory=[shared_memory],
        system_message=cleaner_system_message(),
    )

    return_agent = AssistantAgent(
        "returner", ollama_client, memory=[shared_memory],
        system_message=returner_system_message(WORKSPACE_DIR),
    )

    team = SelectorGroupChat(
        participants=[
            data_cleaner_agent, manager_agent, data_analysis_agent, coding_agent,
            executor_agent, qc_agent, return_agent
        ],
        model_client=ollama_client,
        termination_condition=termination_condition,
        max_turns=MAX_TURNS_ANALYSIS_TEAM,
    )

    # Ensure Workspace directory exists - code executor runs here
    os.makedirs(WORKSPACE_DIR, exist_ok=True)

    try:
        logger.info("Loading dataset...", extra={"agent": "SYSTEM"})
        dataset_file, sheet_data = load_dataset(file_path)
        logger.info(f"Dataset loaded successfully: {len(sheet_data)} sheet(s)", extra={"agent": "SYSTEM"})
        
        verify_report = verify_dataset(sheet_data)
        sample_info = json.dumps(verify_report, indent=2)
        logger.debug(f"Dataset verification: {sample_info}", extra={"agent": "SYSTEM"})

        if enable_cleaning:
            logger.info("Cleaning enabled - starting cleaning process", extra={"agent": "SYSTEM"})
            run_cleaning = _build_cleaning_team(ollama_client, shared_memory)
            try:
                cleaned_files = await run_cleaning(dataset_file, sheet_data, logger)
                if cleaned_files:
                    logger.info(f"Cleaning completed: {len(cleaned_files)} file(s)", extra={"agent": "SYSTEM"})
                    # If multiple cleaned files, take the first; re-load
                    dataset_file = cleaned_files[0]
                    dataset_file, sheet_data = load_dataset(dataset_file)
                    verify_report = verify_dataset(sheet_data)
                    sample_info = json.dumps(verify_report, indent=2)
                else:
                    logger.warning("Cleaning completed but no files returned", extra={"agent": "SYSTEM"})
            except Exception as e:
                logger.error(f"Error during cleaning process: {e}", extra={"agent": "SYSTEM"}, exc_info=True)
                # Continue with original dataset if cleaning fails
                logger.info("Continuing with original dataset", extra={"agent": "SYSTEM"})

        await shared_memory.add(
            MemoryContent(
                content=(
                    f"Question from the user is: {user_question} and the "
                    f"Dataset file: {dataset_file}\nVerification summary:\n{sample_info}\n"
                    f"Available sheets: {list(sheet_data.keys())}"
                ),
                mime_type=MemoryMimeType.TEXT,
            )
        )

        # Decide whether to answer directly (RAG-style) from markdown instead of coding
        direct_qa = should_use_direct_qa(user_question, sheet_data, dataset_file)
        merged_present = excel_has_merged_cells(dataset_file)

        
        markdown_context = sheet_data_to_markdown(sheet_data) if direct_qa else ""
        
        data_block = ""
        if direct_qa:
            data_block = "DATA (MARKDOWN FROM FILE):\n" + markdown_context

        if direct_qa:
            instruction_block = (
                "- Execute the code to answer the question only if needed or else Answer directly from the provided data in markdown.\n"
                "- Only if user asks for a plot, then generate the plot. Do NOT generate plots for simple statistical questions.\n"
                "- If the data looks like a perfect table, generate code to answer the question from the data.(Do not look data_block for this)"
                
            )
        else:
            # Get absolute path for the dataset file
            dataset_abs_path = os.path.abspath(dataset_file)
            instruction_block = (
                f"- **CRITICAL: Coder MUST load the dataset file using pandas in the code itself. The absolute dataset file path is: {dataset_abs_path}**\n"
                f"- **Coder MUST NOT assume 'sheet_data' variable exists - it does NOT exist in the execution environment.**\n"
                f"- **Coder must start code with: import pandas as pd; import os; df = pd.read_excel(r'{dataset_abs_path}') or pd.read_csv(r'{dataset_abs_path}')**\n"
                f"- **Use the exact absolute path shown above (with 'r' prefix for raw string to handle Windows paths).**\n"
                f"- Coder writes code (saving plots in the current working directory where code executes).\n"
                "  filename randomid_ as prefix to the plots.\n"
                "use randomid as prefix to the plots and code to avoid overwriting existing plots and code."
                "use python random library to generate randomid."
                "- Executor runs code.\n"
                "- QC validates and passes to Manager.\n"
            )
            if merged_present:
                instruction_block += (
                    "- Headers may be merged or multi-row. Do NOT assume first row is header.\n"
                    "- Flatten/normalize headers by inspecting the first 10-15 rows.\n"
                    "- Create robust column names (no NaN), concatenating multi-levels if needed.\n"
                    "- Ensure resulting column names are valid strings for JSON/printing.\n"
                )

        task_prompt = f"""
        Dataset file: {dataset_file}

        Verification summary:
        {sample_info}

        User Question: {user_question}

        {data_block}

        Instructions:
        - Manager coordinates and forwards final raw answer to Returner.
        - Analysis interprets.
        {instruction_block}
        - Manager forwards to Returner.
        - Returner beautifies in Markdown.
        - Terminator stops workflow when Returner is done.
        - No JSON, only plain human-readable answer.

        Important Instructions (Handling User Questions):
        - **CRITICAL: Coder MUST load the dataset file using pandas in the code itself. The absolute file path is: {os.path.abspath(dataset_file)}**\n"
        - **DO NOT assume 'sheet_data' variable exists - it does NOT exist in the execution environment.**\n"
        - ** First row may not always be header - so handle it Accordingly in all codes - think in all direction user may have merged cells or normal data etc..,(eg. create a correct mapping of coloumn names after handling the rows** 
        - **Analyze user intent first.** Your primary goal is to answer questions *about the provided dataset*.
        - **Plots:** Only generate a plot if the user *explicitly* asks for a "plot," "chart," "graph," or "visualization." Do not generate plots for simple statistical questions.
        - **Relevance:** If the user's question is irrelevant to the dataset (e.g., "What is the capital of France?", "Who are you?"), you MUST reject it. State that you can only answer questions about the loaded data.
        - **Complexity:** This is a data analysis agent, not a machine learning platform. You MUST reject complex, out-of-scope requests like:
            - "Train a machine learning model."
            - "Build a predictive model."
            - "Perform deep learning."
            - Any other complex AI or model training tasks.
        - **If a question is rejected:** The 'manager' or 'analysis' agent should state *why* it is being rejected and forward it to the 'returner'.

        - If multiple sheets exist, clarify sheet usage.
        - If user references multiple sheets, coder should load each sheet separately and merge or compare them using pandas.
        - If sheet not specified, assume the first sheet by default.
        """

       
        async def run_stream_and_capture():
            final_from_returner = None
            fallback_answer = None  # Store fallback from manager/QC/executor
            last_manager_msg = None
            last_qc_msg = None
            last_executor_msg = None
            
            stream = None
            try:
                stream = team.run_stream(task=task_prompt)
                async for msg in stream:
                    if hasattr(msg, "content") and hasattr(msg, "source"):
                        # Handle different content types (string, list, etc.)
                        raw_content = msg.content
                        if isinstance(raw_content, list):
                            # If content is a list, join it or take first element
                            content = " ".join(str(item) for item in raw_content) if raw_content else ""
                        elif isinstance(raw_content, (dict, object)):
                            # If content is dict or object, convert to string
                            content = str(raw_content) if raw_content else ""
                        else:
                            # Assume it's a string or can be converted
                            content = str(raw_content) if raw_content else ""
                        
                        source = msg.source
                        
                        # Log all team messages
                        try:
                            # Truncate very long messages for logging (keep first 500 chars)
                            log_content = content[:500] + "..." if len(content) > 500 else content
                            logger.info(f"Message from {source}: {log_content}", extra={"agent": source})
                        except Exception as log_err:
                            # Don't let logging errors break the flow
                            pass
                        
                        # Priority 1: Capture returner output
                        if source == "returner" and content and content.strip():
                            final_from_returner = content
                        
                        # Priority 2: Store fallback messages from other agents
                        elif source == "manager" and content and content.strip() and len(content.strip()) > 20:
                            last_manager_msg = content
                            # If manager explicitly forwards to returner, use it as fallback
                            if "returner" in content.lower() or "final" in content.lower():
                                fallback_answer = content
                        elif source == "qc" and content and content.strip() and len(content.strip()) > 20:
                            last_qc_msg = content
                            # QC validated results are good fallback
                            if "plot" in content.lower() or "successfully" in content.lower() or "result" in content.lower():
                                fallback_answer = content
                        elif source == "executor" and content and content.strip():
                            last_executor_msg = content
                            # Executor output can be used if no other answer
                            if not fallback_answer and "plot saved" in content.lower():
                                fallback_answer = content
            except asyncio.CancelledError:
                # Handle cancellation gracefully - use whatever we captured so far
                logger.warning("Stream was cancelled", extra={"agent": "SYSTEM"})
                pass
            except Exception as e:
                # Log other exceptions but continue with what we have
                logger.error(f"Exception during team stream: {e}", extra={"agent": "SYSTEM"}, exc_info=True)
                print(f"Warning: Exception during team stream: {e}")
            finally:
                # Properly close the stream to avoid cleanup errors
                if stream is not None:
                    try:
                        # The stream should complete naturally, but ensure it's closed
                        if hasattr(stream, 'aclose'):
                            await stream.aclose()
                    except Exception:
                        pass  # Ignore cleanup errors
            
            # Return returner output if available, otherwise use fallback
            if final_from_returner:
                return final_from_returner
            
            # Fallback strategy: try to construct a response from available messages
            if fallback_answer:
                return fallback_answer
            elif last_qc_msg:
                return last_qc_msg
            elif last_manager_msg:
                return last_manager_msg
            elif last_executor_msg:
                return last_executor_msg
            
            return None

        try:
            final_json_text = await run_with_retries(run_stream_and_capture, retries=DEFAULT_RETRIES)
        except Exception as retry_err:
            logger.error(f"Error during retries: {retry_err}", extra={"agent": "SYSTEM"}, exc_info=True)
            return {"error": f"Analysis failed after retries: {str(retry_err)}"}
        
        if not final_json_text:
            logger.error("No output from returner or other agents", extra={"agent": "SYSTEM"})
            return {"error": "No output from returner or other agents. Please retry the analysis."}
        
        logger.info(f"Received response from agents (length: {len(final_json_text) if final_json_text else 0})", extra={"agent": "SYSTEM"})

        # Clean up the text: remove markdown code blocks and extra formatting
        cleaned = final_json_text.strip()
        
        # Clean Unicode characters: replace problematic Unicode spaces with regular spaces
        cleaned = clean_unicode_spaces(cleaned)
        
        # Remove markdown code fences (```json ... ``` or ``` ... ```)
        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            # Remove first line if it's ```json or ```
            if lines[0].strip().startswith("```"):
                lines = lines[1:]
            # Remove last line if it's ```
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            cleaned = "\n".join(lines)
        
        # Remove "json" prefix if present
        cleaned = cleaned.strip()
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:].strip()
        
        # Try to parse as JSON
        try:
            logger.debug("Parsing JSON response", extra={"agent": "SYSTEM"})
            parsed = json.loads(cleaned)
            logger.debug("JSON parsed successfully", extra={"agent": "SYSTEM"})
            
            # Handle nested structure: {"result": {"text": "...", "plots": [...]}}
            result = parsed.get("result") if isinstance(parsed, dict) else None
            if isinstance(result, dict):
                text = result.get("text")
                plots = result.get("plots")
                # Clean Unicode characters from text
                if isinstance(text, str):
                    text = clean_unicode_spaces(text)
                if plots:
                    return {"text": text, "plots": plots}
                if text:
                    return {"text": text}
            
            # Handle direct structure: {"text": "...", "plots": [...]}
            if isinstance(parsed, dict):
                text = parsed.get("text")
                plots = parsed.get("plots")
                # Clean Unicode characters from text
                if isinstance(text, str):
                    text = clean_unicode_spaces(text)
                
                # Validate and find plot files if plots are mentioned but paths might be wrong
                if plots:
                    validated_plots = []
                    for plot_path in plots:
                        # Check if plot exists, if not search in workspace
                        if not os.path.exists(plot_path):
                            # Try to find in workspace
                            basename = os.path.basename(plot_path) if plot_path else None
                            if basename:
                                workspace_path = os.path.join(WORKSPACE_DIR, basename)
                                if os.path.exists(workspace_path):
                                    validated_plots.append(workspace_path)
                                else:
                                    # Try to find by pattern
                                    found = find_recent_plot_files(WORKSPACE_DIR)
                                    if found:
                                        validated_plots.extend(found[:1])  # Take first match
                        else:
                            validated_plots.append(plot_path)
                    
                    # If no validated plots but plots mentioned, search workspace
                    if not validated_plots:
                        found = find_recent_plot_files(WORKSPACE_DIR)
                        validated_plots = found[:5]  # Limit to 5 most recent
                    
                    if validated_plots:
                        logger.info(f"Returning result with {len(validated_plots)} plot(s)", extra={"agent": "SYSTEM"})
                        return {"text": text, "plots": validated_plots}
                    # If plots mentioned but not found, search workspace
                    elif text and ("plot" in text.lower() or "chart" in text.lower() or "graph" in text.lower()):
                        found = find_recent_plot_files(WORKSPACE_DIR)
                        if found:
                            logger.info(f"Found plots in workspace: {len(found)} plot(s)", extra={"agent": "SYSTEM"})
                            return {"text": text, "plots": found[:5]}  # Limit to 5 most recent
                
                # If text mentions plots/charts/graphs but no plots array, search workspace
                if text and ("plot" in text.lower() or "chart" in text.lower() or "graph" in text.lower() or ".png" in text.lower() or ".jpg" in text.lower()):
                    logger.info("Text mentions plots but no plots array found, searching workspace", extra={"agent": "SYSTEM"})
                    # Extract plot filename from text if mentioned
                    plot_filename_match = re.search(r'(\d+_[^\s`]+\.(?:png|jpg|jpeg|gif|svg))', text, re.IGNORECASE)
                    if plot_filename_match:
                        plot_filename = plot_filename_match.group(1)
                        plot_path = os.path.join(WORKSPACE_DIR, plot_filename)
                        if os.path.exists(plot_path):
                            return {"text": text, "plots": [plot_path]}
                    
                    # If no specific filename found, search for recent plots
                    found = find_recent_plot_files(WORKSPACE_DIR)
                    if found:
                        return {"text": text, "plots": found[:5]}  # Limit to 5 most recent
                
                if text:
                    return {"text": text}
            
            # If it's a string or other format, return as text
            if isinstance(parsed, str):
                return {"text": clean_unicode_spaces(parsed)}
            
            # Fallback: return JSON string representation
            return {"text": clean_unicode_spaces(str(parsed))}
            
        except json.JSONDecodeError as e:
            # If it's not valid JSON (e.g., fallback answer from manager/QC), wrap it properly
            # This handles cases where returner didn't format properly or we used fallback
            logger.warning(f"JSON decode error: {e}. Attempting to extract from text.", extra={"agent": "SYSTEM"})
            if cleaned and len(cleaned.strip()) > 0:
                # First, try to find plot files in workspace directory
                plot_paths = find_recent_plot_files(WORKSPACE_DIR)
                
                # If no plots found by search, try extracting from text
                if not plot_paths:
                    # Try to extract plot paths if mentioned (look in Workspace directory)
                    plot_paths = re.findall(r'(?:Workspace[/\\]|^)[^\s]+\.(?:png|jpg|jpeg|gif|svg)', cleaned, re.IGNORECASE)
                    # Also try to find just filenames that look like plots
                    if not plot_paths:
                        plot_paths = re.findall(r'\d+_[^\s]+\.(?:png|jpg|jpeg|gif|svg)', cleaned, re.IGNORECASE)
                
                # Validate found plot paths exist
                validated_plots = []
                for plot_path in plot_paths:
                    # If it's just a filename, prepend workspace
                    if not os.path.dirname(plot_path):
                        plot_path = os.path.join(WORKSPACE_DIR, plot_path)
                    elif not os.path.isabs(plot_path):
                        # Relative path, check if it's in workspace
                        full_path = os.path.join(WORKSPACE_DIR, os.path.basename(plot_path))
                        if os.path.exists(full_path):
                            plot_path = full_path
                    
                    if os.path.exists(plot_path):
                        validated_plots.append(plot_path)
                
                # If we found plots, return them
                if validated_plots:
                    logger.info(f"Extracted {len(validated_plots)} plot(s) from text", extra={"agent": "SYSTEM"})
                    # Remove plot paths from text and return separately
                    text_without_plots = cleaned
                    for plot_path in validated_plots:
                        # Remove references to this plot from text
                        basename = os.path.basename(plot_path)
                        text_without_plots = text_without_plots.replace(basename, "").strip()
                        text_without_plots = text_without_plots.replace(plot_path, "").strip()
                    # Clean Unicode characters from the final text
                    text_without_plots = clean_unicode_spaces(text_without_plots)
                    return {"text": text_without_plots, "plots": validated_plots}
                
                # No plots found, return as plain text wrapped in JSON
                logger.info("Returning text-only result (fallback)", extra={"agent": "SYSTEM"})
                # Clean Unicode characters from the final text
                return {"text": clean_unicode_spaces(cleaned)}
            else:
                # Empty content - should not happen but handle gracefully
                return {"text": "Analysis completed but no output was generated. Please retry."}

    except (FileNotFoundError, ValueError) as e:
        logger.error(f"Validation error: {e}", extra={"agent": "SYSTEM"}, exc_info=True)
        return {"error": str(e)}
    except Exception as e:
        logger.error(f"Unexpected error: {e}", extra={"agent": "SYSTEM"}, exc_info=True)
        return {"error": f"Unexpected error: {e}"}
    finally:
        # Ensure termination condition is reset for next run
        try:
            if 'termination_condition' in locals():
                await termination_condition.reset()
        except Exception as e:
            if 'logger' in locals():
                logger.warning(f"Error resetting termination condition: {e}", extra={"agent": "SYSTEM"})
            pass  # Ignore cleanup errors
        
        # After completion, search for any plots that were created
        try:
            # Find recent plot files created during this run
            recent_plots = find_recent_plot_files(WORKSPACE_DIR, max_age_seconds=600)
            # If we have plots but they weren't in the result, add them
            if recent_plots and 'final_json_text' in locals():
                # This will be handled in the JSON parsing section
                if 'logger' in locals():
                    logger.info(f"Found {len(recent_plots)} plot(s) in workspace", extra={"agent": "SYSTEM"})
        except Exception as e:
            if 'logger' in locals():
                logger.warning(f"Error searching for plots: {e}", extra={"agent": "SYSTEM"})
            pass  # Ignore plot search errors
        
        # Log session end
        try:
            if 'logger' in locals():
                logger.info("=== Analysis Session Completed ===", extra={"agent": "SYSTEM"})
        except Exception:
            pass  # Ignore logging errors during cleanup


def analyze(file_path: str, user_question: str, enable_cleaning: bool = False):
    """
    Run analysis with proper event loop management.
    Each call creates a fresh event loop to avoid 'team already running' errors.
    """
    # asyncio.run() automatically creates a new event loop and closes it after
    # This ensures clean state between runs
    try:
        return asyncio.run(run_analysis(file_path, user_question, enable_cleaning))
    except RuntimeError as e:
        # Handle case where event loop might already exist (shouldn't happen with asyncio.run())
        if "cannot be called from a running event loop" in str(e):
            # Fallback: create new event loop manually
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                return loop.run_until_complete(run_analysis(file_path, user_question, enable_cleaning))
            finally:
                loop.close()
        else:
            raise


