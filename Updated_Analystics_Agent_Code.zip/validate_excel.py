import os
import sys
from typing import Tuple, Optional

import pandas as pd
from openpyxl import load_workbook

from agent_config import (
    EXCEL_FILE_SIZE_LIMIT_MB,
    EXCEL_MIN_ROWS,
    CSV_MIN_ROWS,
)
from utils import load_dataset


class ValidationError(Exception):
    pass


def _validate_file_size(file_path: str) -> None:
    limit_bytes = EXCEL_FILE_SIZE_LIMIT_MB * 1024 * 1024
    if os.path.getsize(file_path) > limit_bytes:
        raise ValidationError(f"File size exceeds {EXCEL_FILE_SIZE_LIMIT_MB}MB limit")


def _validate_excel(file_path: str) -> None:
    """
    Delegate structural/content validation to utils.load_dataset (config-driven):
    - Enforces sheet limits, merged-cell policy, image/chart rejection.
    Then ensure minimum rows per EXCEL_MIN_ROWS.
    """
    try:
        _, sheet_data = load_dataset(file_path)
    except Exception as e:
        # Mirror utils decisions (images/charts/merged/sheet count) as a single error
        raise ValidationError(str(e))

    # Ensure minimum rows across the (allowed) sheets
    total_rows = 0
    try:
        for _, df in sheet_data.items():
            total_rows += int(df.shape[0])
    except Exception:
        total_rows = 0
    if total_rows < EXCEL_MIN_ROWS:
        raise ValidationError(f"The Excel file must have at least {EXCEL_MIN_ROWS} rows of data")


def _validate_csv(file_path: str) -> None:
    if not os.path.exists(file_path):
        raise ValidationError("File not found")
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
    except Exception as e:
        raise ValidationError(f"Invalid CSV file: {e}")

    if not lines:
        raise ValidationError("CSV is Empty")

    headers = lines[0].strip()
    data_lines = lines[1:]
    if not headers:
        raise ValidationError("No header found")
    if len(data_lines) < CSV_MIN_ROWS:
        raise ValidationError(f"The CSV file must have at least {CSV_MIN_ROWS} rows of data")


def validate_upload(file_path: str, file_type: str) -> Tuple[bool, Optional[str]]:
    """
    Validate an uploaded file per current policies in agent_config.
    Returns (ok, error_message). If ok is True, error_message is None.
    """
    try:
        if not os.path.exists(file_path):
            return False, "File not found"

        _validate_file_size(file_path)

        if file_type.lower() in ("xlsx", "excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"):
            _validate_excel(file_path)
        elif file_type.lower() in ("csv", "text/csv"):
            _validate_csv(file_path)
        else:
            return False, "Unsupported file type"

        return True, None
    except ValidationError as ve:
        return False, str(ve)
    except Exception as e:
        return False, f"Validation failed: {e}"


