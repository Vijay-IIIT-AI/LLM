"""
Example script to demonstrate how to use the analysis module.

This script shows how to:
1. Run analysis without cleaning
2. Run analysis with cleaning enabled
3. Handle the results
"""

from analysis import analyze
from utils import to_base64_if_exists

# Example 1: Basic analysis without cleaning
def example_basic_analysis():
    """Run a simple analysis on a CSV/Excel file."""
    file_path = r"C:\Users\Vijay\Downloads\Online-Store-Orders.xlsx"  # Replace with your file path
    user_question = """
    1.What is this dataset about?"""
    
    print("Running basic analysis...")
    result = analyze(file_path, user_question, enable_cleaning=False)
    
    if "error" in result:
        print(f"Error: {result['error']}")
    elif "plots" in result:
        print(f"Text Answer:\n{result['text']}")
        print(f"\nPlots generated:\n{result['plots']}")
    else:
        print(f"Answer:\n{result['text']}")
    
    return result


output = example_basic_analysis()
output = to_base64_if_exists(output)
print("--------------------------------")
print(output)
print("--------------------------------")


# Example 2: Analysis with cleaning enabled
def example_analysis_with_cleaning():
    """Run analysis with data cleaning first."""
    file_path = "path/to/your/messy_data.xlsx"  # Replace with your file path
    user_question = "Can you plot the age distribution?"
    
    print("Running analysis with cleaning...")
    result = analyze(file_path, user_question, enable_cleaning=True)
    
    if "error" in result:
        print(f"Error: {result['error']}")
    elif "plots" in result:
        print(f"Text Answer:\n{result['text']}")
        print(f"\nPlots generated:\n{result['plots']}")
    else:
        print(f"Answer:\n{result['text']}")


# Example 3: Using async directly
async def example_async_usage():
    """Example of using the async function directly."""
    from analysis import run_analysis
    
    file_path = "path/to/your/data.csv"
    user_question = "What are the top 5 rows?"
    
    result = await run_analysis(file_path, user_question, enable_cleaning=False)
    
    if "error" in result:
        print(f"Error: {result['error']}")
    else:
        print(f"Result: {result}")


# if __name__ == "__main__":
#     # Uncomment the example you want to run:
    
#     # Example 1: Basic analysis
#     # example_basic_analysis()
    
#     # Example 2: Analysis with cleaning
#     # example_analysis_with_cleaning()
    
#     # Example 3: Async usage (requires asyncio.run() or async context)
#     # import asyncio
#     # asyncio.run(example_async_usage())
    
#     print("Please uncomment one of the examples above and update the file_path to test.")

