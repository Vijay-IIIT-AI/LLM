import os

# API Configuration
API_KEY = "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"

# Model Configuration
MODEL_BASE_URL = "https://openrouter.ai/api/v1"
MODEL_NAME =  "openai/gpt-oss-20b:free"
MODEL_TEMPERATURE = 0.4

# Directory Configuration - Code executor runs in Workspace folder
WORKSPACE_DIR = "Workspace_NPPLLM"  # Code executor runs here, all files save in this folder

# Execution Configuration
CODE_EXECUTOR_TIMEOUT = 600
MAX_TURNS_ANALYSIS_TEAM = 40
MAX_TURNS_CLEANING_TEAM = 20

# Retry Configuration
DEFAULT_RETRIES = 3

# Direct-QA/RAG thresholds and markdown render limits
MARKDOWN_MAX_ROWS_PER_SHEET = 20

# Excel ingestion policy
EXCEL_REQUIRE_SINGLE_SHEET = True  # if True, overrides limit to exactly 1
MAX_SHEETS_ALLOWED = 1             # general sheet limit when single-sheet is not enforced
ALLOW_MERGED_CELLS = True         # if False, reject Excel files containing merged cells

# Validation limits (used by validate_excel.py)
EXCEL_FILE_SIZE_LIMIT_MB = 5           # Max upload size for Excel/CSV files
EXCEL_MIN_ROWS = 10                    # Minimum data rows required for Excel
CSV_MIN_ROWS = 10                      # Minimum data rows required for CSV
EXCEL_HEADER_REQUIRED = True           # Require header row in Excel
EXCEL_REJECT_IMAGES = True             # Reject Excel sheets with embedded images
EXCEL_REJECT_CHARTS = True             # Reject Excel sheets with charts

# Plot handling
MAX_PLOT_FILE_SIZE_BYTES = 5_000_000  # 5 MB safety cap for base64 conversion
PLOT_ADDITIONAL_SEARCH_DIRS = [
    WORKSPACE_DIR,  # All plots save in Workspace folder
]
PLOT_FOOTER_TEXT = "AgentGenz"  # Footer text to add to all generated plots (set to empty string to disable)

# Logging Configuration
LOGS_DIR = "logs"  # Directory for log files
LOG_MAX_BYTES = 10 * 1024 * 1024  # 10 MB per log file
LOG_BACKUP_COUNT = 5  # Keep 5 backup log files
LOG_LEVEL = "INFO"  # Logging level: DEBUG, INFO, WARNING, ERROR

# Validate API Key
if not API_KEY:
    raise ValueError(
        "API_KEY not set in agent_config.py. "
        "Please set it before running the script."
    )

