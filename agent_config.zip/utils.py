import os
import json
import asyncio
import random
import base64
import glob
import pandas as pd
import openpyxl
import datetime
from agent_config import (
    MARKDOWN_MAX_ROWS_PER_SHEET,
    EXCEL_REQUIRE_SINGLE_SHEET,
    MAX_SHEETS_ALLOWED,
    ALLOW_MERGED_CELLS,
    PLOT_DIR,
    WORKSPACE_DIR,
    MAX_PLOT_FILE_SIZE_BYTES,
    PLOT_ADDITIONAL_SEARCH_DIRS,
)


def load_dataset(file_path: str):
    """
    Load a single CSV or Excel file.
    - If CSV: returns (file_path, {"Sheet1": df})
    - If Excel: returns (file_path, {sheet_name: df, ...})
    - Reject Excel sheets containing images or charts
    """
    if not file_path or not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    if file_path.endswith(".csv"):
        df = pd.read_csv(file_path, header=0)
        return file_path, {"Sheet1": df}

    if file_path.endswith(".xlsx"):
        try:
            workbook = openpyxl.load_workbook(file_path)
            # Enforce sheet limit policy
            sheet_count = len(workbook.sheetnames)
            effective_limit = 1 if EXCEL_REQUIRE_SINGLE_SHEET else int(MAX_SHEETS_ALLOWED)
            if sheet_count != 1 and EXCEL_REQUIRE_SINGLE_SHEET:
                raise ValueError(
                    f"Excel file must contain exactly one sheet (found {sheet_count})."
                )
            if not EXCEL_REQUIRE_SINGLE_SHEET and sheet_count > effective_limit:
                raise ValueError(
                    f"Excel file exceeds sheet limit {effective_limit} (found {sheet_count})."
                )
            sheet_data = {}
            for sheet_name in workbook.sheetnames:
                sheet = workbook[sheet_name]
                # Reject merged cells if not allowed
                try:
                    has_merged = bool(getattr(sheet, "merged_cells", None) and sheet.merged_cells.ranges)
                except Exception:
                    has_merged = False
                if (not ALLOW_MERGED_CELLS) and has_merged:
                    raise ValueError(
                        f"Excel sheet '{sheet_name}' contains merged cells. Not allowed."
                    )
                if getattr(sheet, "_images", None) or getattr(sheet, "_charts", None):
                    raise ValueError(
                        f"Excel sheet '{sheet_name}' contains images or charts. Not allowed."
                    )
                df = pd.read_excel(file_path, header=0, sheet_name=sheet_name)
                sheet_data[sheet_name] = df
            return file_path, sheet_data
        except Exception as e:
            raise e

    raise ValueError("Unsupported file type. Only .csv and .xlsx are supported")


def safe_jsonify_value(v):
    if isinstance(v, (pd.Timestamp, pd.Timedelta, datetime.datetime, datetime.date, datetime.time)):
        return str(v)
    return v


def verify_dataset(sheet_data: dict):
    report = {}
    for sheet_name, df in sheet_data.items():
        report[sheet_name] = {
            "shape": df.shape,
            "missing_values": {str(k): int(v) for k, v in df.isnull().sum().to_dict().items()},
            "duplicates": int(df.duplicated().sum()),
            "dtypes": {str(k): str(v) for k, v in df.dtypes.to_dict().items()},
            "head": [
                {str(k): safe_jsonify_value(v) for k, v in row.items()}
                for row in df.head(3).to_dict(orient="records")
            ],
        }
    return report


async def run_with_retries(coro_factory, retries: int = 3):
    """
    Retry an async operation returned by coro_factory with exponential backoff.
    Returns the result of the successful run.
    """
    for attempt in range(1, retries + 1):
        try:
            return await coro_factory()
        except Exception as e:
            wait_time = (2 ** attempt) + random.random()
            if attempt < retries:
                await asyncio.sleep(wait_time)
            else:
                raise e


def convert_plots_to_base64(plot_paths: list, plot_dir: str = None) -> list:
    """
    Convert plot file paths to base64 encoded strings.
    
    Args:
        plot_paths: List of plot file paths (can be relative or absolute)
        plot_dir: Base directory for relative paths
    
    Returns:
        List of base64 encoded strings with format: "data:image/png;base64,<encoded_string>"
    """
    base64_plots = []
    
    for plot_path in plot_paths:
        try:
            # Handle relative paths
            if not os.path.isabs(plot_path):
                if plot_dir:
                    plot_path = os.path.join(plot_dir, plot_path)
                else:
                    # Try current directory
                    if not os.path.exists(plot_path):
                        # Try common plot directories
                        for common_dir in ["Plots", "plots", ".", "Workspace"]:
                            potential_path = os.path.join(common_dir, plot_path)
                            if os.path.exists(potential_path):
                                plot_path = potential_path
                                break
            
            # Normalize path
            plot_path = os.path.normpath(plot_path)
            
            # Check if file exists
            if not os.path.exists(plot_path):
                print(f"Warning: Plot file not found: {plot_path}")
                continue
            
            # Read file and encode to base64
            with open(plot_path, "rb") as image_file:
                encoded_string = base64.b64encode(image_file.read()).decode("utf-8")
                
                # Determine MIME type from file extension
                ext = os.path.splitext(plot_path)[1].lower()
                mime_types = {
                    ".png": "image/png",
                    ".jpg": "image/jpeg",
                    ".jpeg": "image/jpeg",
                    ".gif": "image/gif",
                    ".svg": "image/svg+xml",
                    ".pdf": "application/pdf",
                }
                mime_type = mime_types.get(ext, "image/png")
                
                # Return data URI format
                base64_plots.append(f"data:{mime_type};base64,{encoded_string}")
                
        except Exception as e:
            print(f"Error converting plot {plot_path} to base64: {e}")
            continue
    
    return base64_plots


def to_base64_if_exists(result: dict) -> dict:
    """
    Post-process an analysis result dict to convert plot paths to base64 if present.
    If any plot file is missing, append a retry note to the text.
    """
    if not isinstance(result, dict):
        return result
    text = result.get("text")
    plots = result.get("plots")
    if not plots:
        return result
    base64_plots: list[str] = []
    missing_any = False
    for plot_path in plots:
        normalized_path = os.path.normpath(plot_path)
        candidate_paths = [normalized_path]
        # If relative, consider additional search roots and basenames
        if not os.path.isabs(normalized_path):
            for root in PLOT_ADDITIONAL_SEARCH_DIRS:
                candidate_paths.append(os.path.normpath(os.path.join(root, normalized_path)))
                candidate_paths.append(os.path.normpath(os.path.join(root, os.path.basename(normalized_path))))
        # Also try bare basename in CWD
        candidate_paths.append(os.path.normpath(os.path.basename(normalized_path)))

        found_path = None
        for cand in candidate_paths:
            if os.path.exists(cand):
                found_path = cand
                break

        if found_path:
            try:
                # Enforce size cap to avoid huge payloads
                try:
                    if os.path.getsize(found_path) > MAX_PLOT_FILE_SIZE_BYTES:
                        missing_any = True
                        continue
                except Exception:
                    pass
                with open(found_path, "rb") as f:
                    encoded = base64.b64encode(f.read()).decode("utf-8")
                # Infer mime type from extension (default png)
                ext = os.path.splitext(found_path)[1].lower()
                mime = {
                    ".png": "image/png",
                    ".jpg": "image/jpeg",
                    ".jpeg": "image/jpeg",
                    ".gif": "image/gif",
                    ".svg": "image/svg+xml",
                }.get(ext, "image/png")
                base64_plots.append(f"data:{mime};base64,{encoded}")
            except Exception:
                missing_any = True
        else:
            # Try glob search across configured roots using stem-based pattern
            try:
                stem, ext = os.path.splitext(os.path.basename(normalized_path))
                if not ext:
                    ext = ".png"
                patterns = []
                for root in PLOT_ADDITIONAL_SEARCH_DIRS:
                    patterns.append(os.path.join(root, f"*{stem}*{ext}"))
                    patterns.append(os.path.join(root, "**", f"*{stem}*{ext}"))
                patterns = list(dict.fromkeys(patterns))  # de-dup
                matches = []
                for pattern in patterns:
                    matches = sorted(glob.glob(pattern, recursive=True))
                    if matches:
                        break
                if matches:
                    try:
                        best = max(matches, key=lambda p: os.path.getmtime(p))
                        if os.path.getsize(best) > MAX_PLOT_FILE_SIZE_BYTES:
                            missing_any = True
                            continue
                        with open(best, "rb") as f:
                            encoded = base64.b64encode(f.read()).decode("utf-8")
                        mime = {
                            ".png": "image/png",
                            ".jpg": "image/jpeg",
                            ".jpeg": "image/jpeg",
                            ".gif": "image/gif",
                            ".svg": "image/svg+xml",
                        }.get(ext.lower(), "image/png")
                        base64_plots.append(f"data:{mime};base64,{encoded}")
                    except Exception:
                        missing_any = True
                else:
                    missing_any = True
            except Exception:
                missing_any = True
    out: dict = {"text": text}
    if base64_plots:
        out["plots"] = base64_plots
    if missing_any:
        suffix = "\n\n---\nSome issue generating plot. Please retry later."
        out["text"] = f"{text}{suffix}" if text else suffix
    return out


def sheet_data_to_markdown(sheet_data: dict, max_rows_per_sheet: int = MARKDOWN_MAX_ROWS_PER_SHEET) -> str:
    """
    Convert a dict of DataFrames to a compact markdown representation.
    Limits rows/columns to keep prompt sizes manageable.
    """
    parts: list[str] = []
    for sheet_name, df in sheet_data.items():
        limited_df = df.iloc[:max_rows_per_sheet, :]
        parts.append(f"\n### Sheet: {sheet_name}\n")
        try:
            md = limited_df.to_markdown(index=False)
        except Exception:
            md = limited_df.head(10).to_csv(index=False)
            md = "```\n" + md + "\n```"
        parts.append(md)
    return "\n".join(parts)


def should_use_direct_qa(user_question: str, sheet_data: dict, file_path: str) -> bool:
    """
    Decide to bypass code execution ONLY based on row count per sheet.
    If ALL sheets have rows <= MARKDOWN_MAX_ROWS_PER_SHEET, use direct QA.
    """
    try:
        for _, df in sheet_data.items():
            if int(df.shape[0]) > MARKDOWN_MAX_ROWS_PER_SHEET:
                return False
        return True
    except Exception:
        return False


def excel_has_merged_cells(file_path: str) -> bool:
    """Return True if the given .xlsx file contains any merged cell ranges."""
    try:
        if not file_path.lower().endswith(".xlsx"):
            return False
        wb = openpyxl.load_workbook(file_path)
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            try:
                if getattr(ws, "merged_cells", None) and ws.merged_cells.ranges:
                    return True
            except Exception:
                # If merged detection fails for any sheet, assume not merged for safety
                continue
        return False
    except Exception:
        return False


