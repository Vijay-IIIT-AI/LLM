import os

# API Configuration
API_KEY = "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"

# Model Configuration
MODEL_BASE_URL = "https://openrouter.ai/api/v1"
MODEL_NAME =  "google/gemma-3-27b-it"
MODEL_TEMPERATURE = 0.4

# Directory Configuration
PLOT_DIR = "Workspace\Plots"
CLEANED_DIR = "Workspace\Cleaned"
WORKSPACE_DIR = "Workspace"
WORKSPACE_CLEAN_DIR = "Workspace"

# Execution Configuration
CODE_EXECUTOR_TIMEOUT = 600
MAX_TURNS_ANALYSIS_TEAM = 40
MAX_TURNS_CLEANING_TEAM = 20

# Retry Configuration
DEFAULT_RETRIES = 3

# Direct-QA/RAG thresholds and markdown render limits
MARKDOWN_MAX_ROWS_PER_SHEET = 20

# Excel ingestion policy
EXCEL_REQUIRE_SINGLE_SHEET = True  # if True, overrides limit to exactly 1
MAX_SHEETS_ALLOWED = 1             # general sheet limit when single-sheet is not enforced
ALLOW_MERGED_CELLS = True         # if False, reject Excel files containing merged cells

# Plot handling
MAX_PLOT_FILE_SIZE_BYTES = 5_000_000  # 5 MB safety cap for base64 conversion
PLOT_ADDITIONAL_SEARCH_DIRS = [
    PLOT_DIR,
    WORKSPACE_DIR,
    os.path.join(WORKSPACE_DIR, "Plots"),
    ".",
]

# Validate API Key
if not API_KEY:
    raise ValueError(
        "API_KEY not set in agent_config.py. "
        "Please set it before running the script."
    )

