import os
import requests
from time import sleep
import unicodedata
from copy import copy
from string import Template
from typing import cast




def remove_control_characters(s):
    return "".join(ch for ch in s if unicodedata.category(ch)[0] != "C")


class BaseTranslator:
    name = "base"
    envs = {}
    lang_map: dict[str, str] = {}
    CustomPrompt = False

    def __init__(self, lang_in: str, lang_out: str, model: str):
        lang_in = self.lang_map.get(lang_in.lower(), lang_in)
        lang_out = self.lang_map.get(lang_out.lower(), lang_out)
        self.lang_in = lang_in
        self.lang_out = lang_out
        self.model = model

    def set_envs(self, envs):
        # Detach from self.__class__.envs
        self.envs = copy(self.envs)
        needUpdate = False
        for key in self.envs:
            if key in os.environ:
                self.envs[key] = os.environ[key]
                needUpdate = True
        if envs is not None:
            for key in envs:
                self.envs[key] = envs[key]

    def translate(self, text: str) -> str:
        """
        Translate the text, and the other part should call this method.
        :param text: text to translate
        :return: translated text
        """
        return self.do_translate(text)

    def do_translate(self, text: str) -> str:
        """
        Actual translate text, override this method
        :param text: text to translate
        :return: translated text
        """
        raise NotImplementedError

    def prompt(
        self, text: str, prompt_template: Template | None = None
    ) -> list[dict[str, str]]:
        try:
            return [
                {
                    "role": "user",
                    "content": cast(Template, prompt_template).safe_substitute(
                        {
                            "lang_in": self.lang_in,
                            "lang_out": self.lang_out,
                            "text": text,
                        }
                    ),
                }
            ]
        except AttributeError:  # `prompt_template` is None
            pass
        except Exception:
            pass  # Error parsing prompt, use the default prompt

        return [
            {
                "role": "user",
                "content": (
                    "You are a professional, authentic machine translation engine. "
                    "Only Output the translated text, do not include any other text."
                    "\n\n"
                    f"Translate the following markdown source text to {self.lang_out}. "
                    "Keep the formula notation {v*} unchanged. "
                    "Output translation directly without any additional text."
                    "\n\n"
                    f"Source Text: {text}"
                    "\n\n"
                    "Translated Text:"
                ),
            },
        ]

    def __str__(self):
        return f"{self.name} {self.lang_in} {self.lang_out} {self.model}"

    def get_rich_text_left_placeholder(self, id: int):
        return f"<b{id}>"

    def get_rich_text_right_placeholder(self, id: int):
        return f"</b{id}>"

    def get_formular_placeholder(self, id: int):
        return self.get_rich_text_left_placeholder(
            id
        ) + self.get_rich_text_right_placeholder(id)


class MistralTranslator(BaseTranslator):
    name = "mistral"
    CustomPrompt = True

    def __init__(
        self,
        lang_in: str,
        lang_out: str,
        model: str = "mistral-small-latest",
        api_key: str = "mjLoMvjl6nnvofomLxPNDMWZsvuouvCz",
        envs=None,
        prompt: Template | None = None,
    ):
        super().__init__(lang_in, lang_out, model)
        self.api_key = api_key
        self.prompt_template = prompt
        self.url = "https://api.mistral.ai/v1/chat/completions"
        self.headers = {"Authorization": f"Bearer {self.api_key}"}

    def do_translate(self, text: str) -> str:
        sleep(10)  # Rate limiting as per your original code
        
        # Handle empty or whitespace-only text
        if not text or not text.strip():
            return text
            
        # Improved system prompt for better translation quality
        system_content = f"You are a professional translator. Translate the following text from {self.lang_in} to {self.lang_out}. Only output the translated text, no explanations or additional content."
        
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "system", 
                    "content": system_content
                },
                {"role": "user", "content": text}
            ]
        }
        
        try:
            resp = requests.post(self.url, headers=self.headers, json=payload)
            resp.raise_for_status()
            result = resp.json()["choices"][0]["message"]["content"]
            
            # Ensure we return something meaningful
            if not result or not result.strip():
                return text  # Return original if translation is empty
                
            return result.strip()
        except Exception as e:
            return text  # Return original text if translation fails

    def get_formular_placeholder(self, id: int):
        return "{{v" + str(id) + "}}"

    def get_rich_text_left_placeholder(self, id: int):
        return self.get_formular_placeholder(id)

    def get_rich_text_right_placeholder(self, id: int):
        return self.get_formular_placeholder(id + 1)
