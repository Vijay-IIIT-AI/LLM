# V3_translate - Simplified PDF Math Translator

A streamlined version of PDFMathTranslate with only the core functionality and custom Mistral API translator.

## Features

- ✅ **No CLI/GUI/Celery** - Pure Python function calls
- ✅ **Custom Mistral API Translator** - Uses your provided API key and configuration
- ✅ **All Core Logic Preserved** - Same PDF processing, layout detection, and rendering
- ✅ **English Documentation** - No Chinese helper docs
- ✅ **Simplified Architecture** - Easy to integrate and use

## Quick Start

### 1. Basic Usage

```python
from V3_translate.main import translate_pdf

# Translate a PDF file
mono_pdf, dual_pdf = translate_pdf(
    input_pdf_path="path/to/your/document.pdf",
    output_dir="path/to/output/folder",
    lang_in="en",
    lang_out="Korean"
)

print(f"Translated files created:")
print(f"- Mono (Korean only): {mono_pdf}")
print(f"- Dual (English + Korean): {dual_pdf}")
```

### 2. Advanced Usage

```python
from V3_translate.main import translate_pdf

# Translate specific pages with custom settings
mono_pdf, dual_pdf = translate_pdf(
    input_pdf_path="document.pdf",
    output_dir="./translated",
    lang_in="en",
    lang_out="Korean",
    pages=[1, 2, 3],  # Only translate pages 1-3
    thread=8,         # Use 8 threads for faster processing
    compatible=True,  # Convert to PDF/A format
    ignore_cache=True # Force retranslation
)
```

### 3. Run the Example

```python
# Edit the paths in main.py and run:
python V3_translate/main.py
```

## Parameters

- `input_pdf_path`: Path to input PDF file
- `output_dir`: Output directory (default: same as input)
- `lang_in`: Source language code (default: "en")
- `lang_out`: Target language code (default: "Korean")
- `pages`: List of pages to translate (1-indexed), None for all
- `thread`: Number of translation threads (default: 4)
- `vfont`: Regex pattern for formula fonts
- `vchar`: Regex pattern for formula characters
- `compatible`: Convert to PDF/A format
- `skip_subset_fonts`: Skip font subsetting
- `ignore_cache`: Ignore translation cache

## API Configuration

The Mistral API key is configured in `translator.py`. Update the `api_key` parameter in the `MistralTranslator` class if needed.

## Offline/Local Asset Configuration

You can override paths so no downloads are attempted:

- `DOC_LAYOUT_ONNX_PATH`: Absolute path to the ONNX layout model. If set, this path is used instead of downloading via `babeldoc`/Hugging Face.
- `NOTO_FONT_PATH`: Either a full path to a `.ttf` file or a directory that contains the selected font. When a directory is provided, the code will try to resolve the expected filename (e.g., `GoNotoKurrent-Regular.ttf`, `SourceHanSerifKR-Regular.ttf`, etc.).

These values can be provided via environment variables or written into the config using `ConfigManager.set(key, value)`.

## Dependencies

All dependencies are the same as the original PDFMathTranslate project. The V3_translate version uses the existing environment and packages.
