"""
V3 PDF Math Translate - Main Entry Point
A simplified version with only Mistral API translator, no CLI/GUI/Celery
"""

import os
from pathlib import Path
from typing import Optional, List

from V3_translate.high_level import translate
from V3_translate.doclayout import OnnxModel, ModelInstance


def translate_pdf(
    input_pdf_path: str,
    output_dir: str = "",
    lang_in: str = "en",
    lang_out: str = "Korean",
    pages: Optional[List[int]] = None,
    thread: int = 4,
    vfont: str = "",
    vchar: str = "",
    compatible: bool = False,
    skip_subset_fonts: bool = False,
) -> tuple:
    """
    Main function to translate a PDF file using V3 translator
    
    Args:
        input_pdf_path: Path to the input PDF file
        output_dir: Output directory for translated files (default: same as input)
        lang_in: Source language code (default: "en")
        lang_out: Target language code (default: "Korean") 
        pages: List of page numbers to translate (1-indexed), None for all pages
        thread: Number of threads for translation (default: 4)
        vfont: Regex pattern for formula fonts
        vchar: Regex pattern for formula characters
        compatible: Convert to PDF/A format for better compatibility
        skip_subset_fonts: Skip font subsetting
        
    Returns:
        tuple: (mono_pdf_path, dual_pdf_path) - paths to generated files
    """
    
    # Validate input file
    if not os.path.exists(input_pdf_path):
        raise FileNotFoundError(f"Input PDF file not found: {input_pdf_path}")
    
    # Set output directory
    if not output_dir:
        output_dir = os.path.dirname(input_pdf_path)
    
    # Create output directory if it doesn't exist
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    
    # Initialize the document layout model
    if ModelInstance.value is None:
        print("Loading document layout model...")
        ModelInstance.value = OnnxModel.load_available()
    
    # Convert 1-indexed pages to 0-indexed if provided
    if pages:
        pages = [p - 1 for p in pages]
    
    print(f"Starting translation of: {input_pdf_path}")
    print(f"Source language: {lang_in}")
    print(f"Target language: {lang_out}")
    print(f"Output directory: {output_dir}")
    
    try:
        # Perform translation
        result_files = translate(
            files=[input_pdf_path],
            output=output_dir,
            pages=pages,
            lang_in=lang_in,
            lang_out=lang_out,
            service="mistral",  # Always use mistral service
            thread=thread,
            vfont=vfont,
            vchar=vchar,
            compatible=compatible,
            model=ModelInstance.value,
            skip_subset_fonts=skip_subset_fonts
        )
        
        if result_files:
            mono_path, dual_path = result_files[0]
            print(f"Translation completed successfully!")
            print(f"Mono PDF (target language only): {mono_path}")
            print(f"Dual PDF (original + translation): {dual_path}")
            return mono_path, dual_path
        else:
            raise RuntimeError("Translation failed - no output files generated")
            
    except Exception as e:
        print(f"Translation failed: {str(e)}")
        raise


def main():
    """
    Example usage of the translate_pdf function
    """
    # Example usage - modify these paths and parameters as needed
    input_pdf = r"C:\Users\Vijay\Downloads\Artificial Intelligence.pdf"
    output_directory = r"C:\Users\Vijay\Downloads\translated_pdfs"
    
    try:
        mono_pdf, dual_pdf = translate_pdf(
            input_pdf_path=input_pdf,
            output_dir=output_directory,
            lang_in="en",
            lang_out="Korean",
            pages=None,  # Translate all pages, or specify like [1, 2, 3] for specific pages
            thread=4,
            compatible=False,
        )
        
        print(f"\n✅ Translation completed successfully!")
        print(f"📄 Mono PDF: {mono_pdf}")
        print(f"📄 Dual PDF: {dual_pdf}")
        
    except Exception as e:
        print(f"\n❌ Translation failed: {str(e)}")


if __name__ == "__main__":
    main()
