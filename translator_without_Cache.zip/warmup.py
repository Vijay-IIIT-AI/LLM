# warmup_assets.py
from babeldoc.assets.assets import get_doclayout_onnx_model_path, get_font_and_metadata

# 1) Layout model (ONNX)
onnx_path = get_doclayout_onnx_model_path()
print("ONNX model at:", onnx_path)

# 2) Fonts (Noto/Tiro)
font_name = "noto"  # this codebase uses NOTO_NAME="noto"
font_path, meta = get_font_and_metadata(font_name)
print("Fonts at:", font_path)