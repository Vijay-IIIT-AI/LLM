from V3_translate.high_level import translate, translate_stream

__version__ = "3.0.0"
__author__ = "V3_Custom"
__all__ = ["translate", "translate_stream"]
