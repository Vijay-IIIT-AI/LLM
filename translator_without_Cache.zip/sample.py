# Navigate to the pdf2zh directory
import sys
sys.path.append(r'C:\Users\Vijay\Downloads\PDFMathTranslate-main\PDFMathTranslate-main\pdf2zh')

from V3_translate.main import translate_pdf
from V3_translate.config import ConfigManager
import os

# Configure local assets (no CLI)
ConfigManager.set(
    "DOC_LAYOUT_MODELS_DIR",
    r"C:\Users\Vijay\Downloads\PDFMathTranslate-main\PDFMathTranslate-main\pdf2zh\V3_translate\babeldoc\models",
)
ConfigManager.set(
    "NOTO_FONT_PATH",
    r"C:\Users\Vijay\Downloads\PDFMathTranslate-main\PDFMathTranslate-main\pdf2zh\V3_translate\babeldoc\fonts",
)

ConfigManager.set(
    "CACHE_DB_PATH",
    r"C:\Users\Vijay\Downloads\PDFMathTranslate-main\PDFMathTranslate-main\pdf2zh\V3_translate\cache\cache.v3.db",
)

# Translate your PDF - Korean to English
mono_pdf, dual_pdf = translate_pdf(
    input_pdf_path=r"C:\Users\Vijay\Desktop\Input\yolo_1.pdf",
    output_dir=r"C:\Users\Vijay\Desktop\Input\translated_pdfs",
    lang_in="en",  # Korean input
    lang_out="ko",  # English output
    pages=None,  # All pages, or [1,2,3] for specific pages
    thread=4
)

print(f"✅ Translation completed!")
print(f"📄 Mono (target only): {mono_pdf}")
print(f"📄 Dual (original + target): {dual_pdf}")