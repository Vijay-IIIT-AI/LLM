import os
import json
import asyncio
from typing import Sequence

import pandas as pd

from autogen_core.models import ModelFamily
from autogen_core.memory import ListMemory, MemoryContent, MemoryMimeType

from autogen_agentchat.agents import AssistantAgent, CodeExecutorAgent
from autogen_agentchat.teams import SelectorGroupChat
from autogen_agentchat.messages import TextMessage, BaseChatMessage, StopMessage

from autogen_ext.models.openai import OpenAIChatCompletionClient
from autogen_ext.code_executors.local import LocalCommandLineCodeExecutor
from autogen_agentchat.agents._code_executor_agent import ApprovalResponse

import random

from utils import load_dataset, verify_dataset, run_with_retries, should_use_direct_qa, sheet_data_to_markdown, excel_has_merged_cells
from prompts import (
    manager_system_message,
    analysis_system_message,
    coder_system_message,
    qc_system_message,
    cleaner_system_message,
    returner_system_message,
    cleaning_planner_message,
    cleaning_coder_message,
    cleaning_qc_message,
)
from agent_config import (
    API_KEY,
    MODEL_BASE_URL,
    MODEL_NAME,
    MODEL_TEMPERATURE,
    PLOT_DIR,
    CLEANED_DIR,
    WORKSPACE_DIR,
    WORKSPACE_CLEAN_DIR,
    CODE_EXECUTOR_TIMEOUT,
    MAX_TURNS_ANALYSIS_TEAM,
    MAX_TURNS_CLEANING_TEAM,
    DEFAULT_RETRIES,
)


def _build_model_client():
    return OpenAIChatCompletionClient(
        model=MODEL_NAME,
        base_url=MODEL_BASE_URL,
        api_key=API_KEY,
        model_info={
            "vision": True,
            "function_calling": True,
            "json_output": True,
            "family": ModelFamily.UNKNOWN,
            "structured_output": True,
            "multiple_system_messages": True,
        },
        temperature=MODEL_TEMPERATURE,
    )


def _build_cleaning_team(ollama_client, shared_memory):
    cleaning_planner = AssistantAgent(
        "cleaning_planner", ollama_client, memory=[shared_memory],
        system_message=cleaning_planner_message(CLEANED_DIR)
    )

    cleaning_coder = AssistantAgent(
        "cleaning_coder", ollama_client, memory=[shared_memory],
        system_message=cleaning_coder_message(CLEANED_DIR)
    )

    executor_clean = LocalCommandLineCodeExecutor(work_dir=WORKSPACE_CLEAN_DIR, timeout=CODE_EXECUTOR_TIMEOUT)

    cleaning_executor = CodeExecutorAgent(
        "cleaning_executor",
        code_executor=executor_clean,
        approval_func=lambda code: ApprovalResponse(
            approved=True,
            reason="Auto-approved for cleaning task"
        )
    )

    cleaning_qc = AssistantAgent(
        "cleaning_qc", ollama_client, memory=[shared_memory],
        system_message=cleaning_qc_message()
    )

    cleaning_team = SelectorGroupChat(
        participants=[cleaning_planner, cleaning_coder, cleaning_executor, cleaning_qc],
        model_client=ollama_client,
        max_turns=MAX_TURNS_CLEANING_TEAM,
    )

    async def run_cleaning(dataset_file: str, sheet_data: dict):
        os.makedirs(CLEANED_DIR, exist_ok=True)
        cleaning_task = f"""
        Dataset file: {dataset_file}
        Sheets available: {list(sheet_data.keys())}

        Your job:
        - Clean messy headers (flatten, rename, stringify).
        - Save cleaned sheets into '{CLEANED_DIR}' as:
          cleaned_<randomid>_<sheetname>.xlsx
        - At the end, only return the absolute file paths.
        """
        cleaned_paths = []
        async for msg in cleaning_team.run_stream(task=cleaning_task):
            if hasattr(msg, "content") and hasattr(msg, "source"):
                if msg.source == "cleaning_qc":
                    try:
                        cleaned_paths = json.loads(msg.content.strip())
                    except Exception:
                        pass
        return cleaned_paths

    return run_cleaning


class StopWhenAnswered:
    def __init__(self):
        self._terminated = False

    @property
    def terminated(self):
        return self._terminated

    async def __call__(self, messages: Sequence[BaseChatMessage]):
        for msg in messages:
            if isinstance(msg, TextMessage):
                if msg.source == "returner" and len((msg.content or "").strip()) > 10:
                    self._terminated = True
                    return StopMessage(
                        source="terminator",
                        content="Workflow stopped: Final beautified Markdown answer delivered."
                    )
        return None

    async def reset(self):
        self._terminated = False


async def run_analysis(file_path: str, user_question: str, enable_cleaning: bool = False):
    shared_memory = ListMemory()
    ollama_client = _build_model_client()

    manager_agent = AssistantAgent(
        "manager", ollama_client, memory=[shared_memory],
        system_message=manager_system_message(),
    )
    data_analysis_agent = AssistantAgent(
        "analysis", ollama_client, memory=[shared_memory],
        system_message=analysis_system_message(),
    )
    coding_agent = AssistantAgent(
        "coder", ollama_client, memory=[shared_memory],
        system_message=coder_system_message(PLOT_DIR),
    )

    executor = LocalCommandLineCodeExecutor(work_dir=WORKSPACE_DIR, timeout=CODE_EXECUTOR_TIMEOUT)
    executor_agent = CodeExecutorAgent(
        "executor",
        code_executor=executor,
        approval_func=lambda code: ApprovalResponse(
            approved=True,
            reason="Auto-approved for execution (DEV ONLY)"
        )
    )

    qc_agent = AssistantAgent(
        "qc", ollama_client, memory=[shared_memory],
        system_message=qc_system_message(),
    )

    data_cleaner_agent = AssistantAgent(
        "cleaner", ollama_client, memory=[shared_memory],
        system_message=cleaner_system_message(),
    )

    return_agent = AssistantAgent(
        "returner", ollama_client, memory=[shared_memory],
        system_message=returner_system_message(PLOT_DIR),
    )

    team = SelectorGroupChat(
        participants=[
            data_cleaner_agent, manager_agent, data_analysis_agent, coding_agent,
            executor_agent, qc_agent, return_agent
        ],
        model_client=ollama_client,
        termination_condition=StopWhenAnswered(),
        max_turns=MAX_TURNS_ANALYSIS_TEAM,
    )

    os.makedirs(PLOT_DIR, exist_ok=True)
    os.makedirs(WORKSPACE_DIR, exist_ok=True)

    try:
        dataset_file, sheet_data = load_dataset(file_path)
        verify_report = verify_dataset(sheet_data)
        sample_info = json.dumps(verify_report, indent=2)

        if enable_cleaning:
            run_cleaning = _build_cleaning_team(ollama_client, shared_memory)
            cleaned_files = await run_cleaning(dataset_file, sheet_data)
            if cleaned_files:
                # If multiple cleaned files, take the first; re-load
                dataset_file = cleaned_files[0]
                dataset_file, sheet_data = load_dataset(dataset_file)
                verify_report = verify_dataset(sheet_data)
                sample_info = json.dumps(verify_report, indent=2)

        await shared_memory.add(
            MemoryContent(
                content=(
                    f"Question from the user is: {user_question} and the "
                    f"Dataset file: {dataset_file}\nVerification summary:\n{sample_info}\n"
                    f"Available sheets: {list(sheet_data.keys())}"
                ),
                mime_type=MemoryMimeType.TEXT,
            )
        )

        # Decide whether to answer directly (RAG-style) from markdown instead of coding
        direct_qa = should_use_direct_qa(user_question, sheet_data, dataset_file)
        merged_present = excel_has_merged_cells(dataset_file)

        
        markdown_context = sheet_data_to_markdown(sheet_data) if direct_qa else ""
        
        data_block = ""
        if direct_qa:
            data_block = "DATA (MARKDOWN FROM FILE):\n" + markdown_context

        if direct_qa:
            instruction_block = (
                "- Execute the code to answer the question only if needed or else Answer directly from the provided data in markdown.\n"
                "- Only if user asks for a plot, then generate the plot. Do NOT generate plots for simple statistical questions.\n"
                "- If the data looks like a perfect table, generate code to answer the question from the data.(Do not look data_block for this)"
                
            )
        else:
            instruction_block = (
                f"- Coder writes code (saving plots to '{PLOT_DIR}').\n"
                "  filename randomid_ as prefix to the plots.\n"
                "use randomid as prefix to the plots and code to avoid overwriting existing plots and code."
                "use python random library to generate randomid."
                "- Executor runs code.\n"
                "- QC validates and passes to Manager.\n"
            )
            if merged_present:
                instruction_block += (
                    "- Headers may be merged or multi-row. Do NOT assume first row is header.\n"
                    "- Flatten/normalize headers by inspecting the first 10-15 rows.\n"
                    "- Create robust column names (no NaN), concatenating multi-levels if needed.\n"
                    "- Ensure resulting column names are valid strings for JSON/printing.\n"
                )

        task_prompt = f"""
        Dataset file: {dataset_file}

        Verification summary:
        {sample_info}

        User Question: {user_question}

        {data_block}

        Instructions:
        - Manager coordinates and forwards final raw answer to Returner.
        - Analysis interprets.
        {instruction_block}
        - Manager forwards to Returner.
        - Returner beautifies in Markdown.
        - Terminator stops workflow when Returner is done.
        - No JSON, only plain human-readable answer.

        Important Instructions (Handling User Questions):
        - ** First row may not always be header - so handle it Accordingly in all codes - think in all direction user may have merged cells or normal data etc..,(eg. create a correct mapping of coloumn names after handling the rows** 
        - **Analyze user intent first.** Your primary goal is to answer questions *about the provided dataset*.
        - **Plots:** Only generate a plot if the user *explicitly* asks for a "plot," "chart," "graph," or "visualization." Do not generate plots for simple statistical questions.
        - **Relevance:** If the user's question is irrelevant to the dataset (e.g., "What is the capital of France?", "Who are you?"), you MUST reject it. State that you can only answer questions about the loaded data.
        - **Complexity:** This is a data analysis agent, not a machine learning platform. You MUST reject complex, out-of-scope requests like:
            - "Train a machine learning model."
            - "Build a predictive model."
            - "Perform deep learning."
            - Any other complex AI or model training tasks.
        - **If a question is rejected:** The 'manager' or 'analysis' agent should state *why* it is being rejected and forward it to the 'returner'.

        - If multiple sheets exist, clarify sheet usage.
        - If user references multiple sheets, coder should merge or compare them using pandas.
        - If sheet not specified, assume the first sheet by default.
        """

       
        async def run_stream_and_capture():
            final_from_returner = None
            async for msg in team.run_stream(task=task_prompt):
                if hasattr(msg, "content") and hasattr(msg, "source"):
                    if msg.source == "returner":
                        final_from_returner = msg.content
            return final_from_returner

        final_json_text = await run_with_retries(run_stream_and_capture, retries=DEFAULT_RETRIES)
        if not final_json_text:
            return {"error": "No output from returner"}

        # Clean up the text: remove markdown code blocks and extra formatting
        cleaned = final_json_text.strip()
        
        # Remove markdown code fences (```json ... ``` or ``` ... ```)
        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            # Remove first line if it's ```json or ```
            if lines[0].strip().startswith("```"):
                lines = lines[1:]
            # Remove last line if it's ```
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            cleaned = "\n".join(lines)
        
        # Remove "json" prefix if present
        cleaned = cleaned.strip()
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:].strip()
        
        # Try to parse as JSON
        try:
            parsed = json.loads(cleaned)
            
            # Handle nested structure: {"result": {"text": "...", "plots": [...]}}
            result = parsed.get("result") if isinstance(parsed, dict) else None
            if isinstance(result, dict):
                text = result.get("text")
                plots = result.get("plots")
                if plots:
                    return {"text": text, "plots": plots}
                if text:
                    return {"text": text}
            
            # Handle direct structure: {"text": "...", "plots": [...]}
            if isinstance(parsed, dict):
                text = parsed.get("text")
                plots = parsed.get("plots")
                if plots:
                    return {"text": text, "plots": plots}
                if text:
                    return {"text": text}
            
            # If it's a string or other format, return as text
            if isinstance(parsed, str):
                return {"text": parsed}
            
            # Fallback: return JSON string representation
            return {"text": str(parsed)}
            
        except json.JSONDecodeError:
            # If it's not valid JSON, return as plain text
            return {"text": cleaned}

    except (FileNotFoundError, ValueError) as e:
        return {"error": str(e)}
    except Exception as e:
        return {"error": f"Unexpected error: {e}"}


def analyze(file_path: str, user_question: str, enable_cleaning: bool = False):
    return asyncio.run(run_analysis(file_path, user_question, enable_cleaning))


