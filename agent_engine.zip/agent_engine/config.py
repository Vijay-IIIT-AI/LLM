
import json
import uuid
import sys
from typing import TypedDict, Annotated, Optional, Dict, Any, List
from pydantic import BaseModel
from langgraph.graph.message import add_messages
from langchain_core.messages import BaseMessage

# ==============================================================================
# CONFIGURATION
# ==============================================================================
class Config:
    """Central configuration for easy tuning."""

    class Models:
        MAIN = "models/"  # change to your model/model path
        FAST = "models/"  # optional: use a smaller/cheaper model for light tasks
        TEMPERATURE = 0.2

    class Identity:
        APP_NAME = "AgenticCode"
        DEVELOPER_NAME = "Vijay"

    class Collections:
        RAG = "rag_global"
        ROUTES = "router_routes"
        FILE_METADATA = "file_metadata"

    class Thresholds:
        # Router confidence
        EMBEDDING_HIGH = 0.85
        EMBEDDING_MEDIUM = 0.75
        ROUTER_FALLBACK = 0.75
        DOC_FALLBACK_SIM = 0.35

        # Route-specific
        ROUTE_DOCUMENT = 0.65
        ROUTE_GENERAL = 0.60

    class Weights:
        HYBRID_DENSE = 0.7
        HYBRID_SPARSE = 0.3

    class Limits:
        MAX_MESSAGES = 50
        MAX_RAG_CONTEXT_CHARS = 20000 

    class TokenBudgets:
        """Token budgets for context management using tiktoken."""
        # Total context window (adjust based on your model)
        TOTAL_CONTEXT_TOKENS = 125000

        # Budget allocations
        SYSTEM_PROMPT_BUDGET = 10000 
        HISTORY_BUDGET = 35000 
        RAG_BUDGET = 65000 
        BUFFER = 15000 

        @classmethod
        def validate(cls):
            """Validate that budgets don't exceed total context."""
            total_allocated = (
                    cls.SYSTEM_PROMPT_BUDGET +
                    cls.HISTORY_BUDGET +
                    cls.RAG_BUDGET +
                    cls.BUFFER
            )
            if total_allocated > cls.TOTAL_CONTEXT_TOKENS:
                raise ValueError(
                    f"Token budgets exceed total context: "
                    f"{total_allocated} > {cls.TOTAL_CONTEXT_TOKENS}"
                )
            return True


# Legacy compatibility - map old constants to Config class
DEFAULT_MODEL = Config.Models.MAIN
FAST_MODEL = Config.Models.FAST
DEFAULT_TEMPERATURE = Config.Models.TEMPERATURE
MAX_MESSAGES = Config.Limits.MAX_MESSAGES
MAX_RAG_CONTEXT_CHARS = Config.Limits.MAX_RAG_CONTEXT_CHARS
RAG_COLLECTION_NAME = Config.Collections.RAG
FILE_METADATA_COLLECTION = Config.Collections.FILE_METADATA

# Router confidence thresholds
EMBEDDING_HIGH_CONFIDENCE = Config.Thresholds.EMBEDDING_HIGH
EMBEDDING_MEDIUM_CONFIDENCE = Config.Thresholds.EMBEDDING_MEDIUM
ROUTER_FALLBACK_THRESHOLD = Config.Thresholds.ROUTER_FALLBACK
DOC_FALLBACK_SIM_THRESHOLD = Config.Thresholds.DOC_FALLBACK_SIM

# Route-specific thresholds
ROUTE_THRESHOLD_DOCUMENT = Config.Thresholds.ROUTE_DOCUMENT
ROUTE_THRESHOLD_GENERAL = Config.Thresholds.ROUTE_GENERAL

# Hybrid routing weights
HYBRID_DENSE_WEIGHT = Config.Weights.HYBRID_DENSE
HYBRID_SPARSE_WEIGHT = Config.Weights.HYBRID_SPARSE


# ==============================================================================
# STATE & SCHEMAS
# ==============================================================================
class ChatResponse(BaseModel):
    """Structured response for API output."""
    answer: str
    metadata: Optional[Dict[str, Any]] = None
    debug: Optional[Dict[str, Any]] = None


class ChatState(TypedDict):
    """LangGraph State schema."""
    messages: Annotated[List[BaseMessage], add_messages]

    # Session identifier (e.g., thread_id)
    session_id: str
    # Chat mode: "auto", "rag", or "general"
    _chat_mode: str
    # Session document state
    session_docs: List[Dict[str, Any]]  # [{doc_id, doc_name}]
    # Cache control
    enable_cache: bool  # True to use semantic cache, False to disable
    # Router state
    router_intent: str  # "general" or "document"
    router_confidence: str  # "high", "medium", or "none"
    router_multi_doc: bool  # True if comparing/analyzing multiple documents
    rag_context: Optional[str]  # Last retrieved RAG chunks (if any)
    # Router node decision (for conditional edges)
    _router_next: str  # "rag", "tools", "chat", "finalizer" - next node to route to
    _router_tool_call: Optional[Dict[str, Any]]  # Tool call info if routing to tools
    # Query resolution context (for follow-ups)
    last_resolved_query: Optional[str]  # Last resolved query (for follow-up expansion)
    last_assistant_answer: Optional[str]  # Last assistant response (for context)
    last_suggestive_question: Optional[str]  # Last follow-up prompt extracted from assistant answer
    last_followup_action: Optional[Dict[str, Any]]  # Stored follow-up action payload (for continue/yes)
    _execute_followup: Optional[Dict[str, Any]]  # Ephemeral execution flag for follow-up actions
    
    # User context for personalization
    user_context: Optional[Dict[str, Any]]  # User preferences (username, style, etc.)


class UserContext(BaseModel):
    """User preferences and context for personalization."""
    username: str = "User"
    response_style: str = "detailed"  # detailed, concise, explain_like_im_5
    language_preference: str = "auto"
    custom_instructions: str = ""

    def to_prompt_context(self) -> str:
        """Format as prompt string."""
        return f"""
- Username: {self.username}
- Style: {self.response_style}
- Language: {self.language_preference}
- Instructions: {self.custom_instructions}
""".strip()

DEFAULT_USER_CONTEXT = UserContext()

# Chat Modes
CHAT_MODES = {
    "auto": "System automatically routes between RAG and General Chat.",
    "rag": "Forces RAG mode for document querying.",
    "general": "Forces General Chat (no RAG)."
}

STATE_DEFAULTS = {
    "session_id": "default",
    "_chat_mode": "auto",
    "session_docs": [],
    "enable_cache": True,
    "router_intent": "general",
    "router_confidence": "none",
    "router_multi_doc": False,
    "_router_next": "chat",
    "user_context": None
}
