from .config import *
from .utils import log, safe_parse_json
from . import prompts  # Import the new prompts module
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from langchain_openai import ChatOpenAI

# ==============================================================================
# ROUTER LOGIC
# ==============================================================================

# NOTE: run_embedding_router removed - all routing now uses LLM for accuracy.
# Removed functions: run_embedding_router, run_hybrid_router, optimize_route_thresholds, evaluate_router

# NOTE: optimize_route_thresholds and evaluate_router removed - no longer needed without embedding router

def run_unified_router(llm: ChatOpenAI, user_text: str, session_docs: List[Dict[str, Any]], messages: List[BaseMessage] = []) -> Dict[str, Any]:
    """
    ONE call to rule them all. Replaces Safety, Resolver, Decomposer, and Intent Router.
    """
    # Quick embedding check (Zero Latency)
    # If we have docs, check if query is even remotely related before asking LLM
    doc_embedding_sim = 0.0
    if session_docs:
        # NOTE: embedding_model is not defined in this scope in original code, assuming it's available or this block is skipped
        # Keeping logic structure identical to original v2.py
        pass

    # Context for the LLM
    doc_context = ""
    if session_docs:
        doc_list = "\n".join([f"- {d.get('doc_name')} (id: {d.get('doc_id')})" for d in session_docs[:10]])
        doc_context = f"Available Documents:\n{doc_list}"
    else:
        doc_context = "No documents uploaded."

    # 1. Format Context from History (Last 3 turns)
    history_context = ""
    if messages:
        # Get last 3 pairs of messages (excluding current one)
        recent_msgs = messages[:-1][-6:] 
        history_context = "\nConversation History:\n" + "\n".join(
            [f"{'User' if isinstance(m, HumanMessage) else 'Assistant'}: {m.content}" for m in recent_msgs]
        )

    # 2. Add History to Prompt
    prompt = prompts.get_unified_router_prompt(user_text, history_context, doc_context)
    
    try:
        # Fast LLM (gpt-4o-mini or similar)
        # Use centralized system prompt
        resp = llm.invoke([prompts.UNIFIED_ROUTER_SYSTEM, HumanMessage(content=prompt)])
        result = safe_parse_json(resp.content) or {"safe": True, "intent": "general", "refined_query": user_text}
        
        # Ensure all required fields are present
        if "safe" not in result:
            result["safe"] = True
        if "intent" not in result:
            result["intent"] = "general"
        if "refined_query" not in result:
            result["refined_query"] = user_text
        if "confidence" not in result:
            result["confidence"] = "high"
        if "file_ids" not in result:
            result["file_ids"] = None
        if "is_metadata" not in result:
            result["is_metadata"] = False
            
        log("UNIFIED_ROUTER", f"Result: safe={result.get('safe')}, intent={result.get('intent')}, confidence={result.get('confidence')}")
        return result
    except Exception as e:
        log("UNIFIED_ROUTER", f"Unified router failed: {e}")
        return {"safe": True, "intent": "general", "refined_query": user_text, "confidence": "high", "file_ids": None, "is_metadata": False}

def run_router(
        llm: ChatOpenAI,
        user_text: str,
        session_docs: List[Dict[str, Any]],
        route_filter: Optional[List[str]] = None,
        top_k: int = 1,
        previous_intent: Optional[str] = None,
        chat_mode: str = "auto"
):
    """
    LLM-based router: Always uses LLM for accurate intent classification.
    """
    # Always use LLM router for accurate classification
    log("ROUTER", "Using LLM router for intent classification")

    doc_embedding_sim = 0.0
   
    try:
        # Format session_docs for the LLM prompt (human-readable format with full details)
        session_docs_info = ""
        if session_docs:
            doc_list = "\n".join(
                [f"  - {i + 1}. {doc.get('doc_name', 'Unknown')} (doc_id: {doc.get('doc_id', 'unknown')})"
                 for i, doc in enumerate(session_docs)])
            session_docs_info = f"""
SESSION DOCUMENTS (available in this session):
- Total count: {len(session_docs)} document(s)
- Document list:
{doc_list}

IMPORTANT: Use this information to answer questions about:
- Document count ("how many documents", "how many files", "number of documents", etc.) → Set about_documents=true, doc_metadata=true, intent=general
- Document names/list ("what documents", "list files", "list down the docs", "show me uploaded files", "tell me the names", etc.) → Set about_documents=true, doc_metadata=true, intent=general
- Document content/questions requiring document content → Set intent=document, about_documents=false, doc_metadata=false

CRITICAL: Queries asking to "list", "show", "tell me the names of", or "what documents/files" are ALWAYS about_documents=true, doc_metadata=true, intent=general (even if they mention "uploaded" or "have").
"""
        else:
            session_docs_info = """
SESSION DOCUMENTS: None (no documents uploaded in this session)

IMPORTANT: If the user asks about documents (count, list, names), they have no documents. 
Set about_documents=true, doc_metadata=true, intent=general to handle this appropriately.
"""
        # Use prompt builder
        router_input_text = prompts.get_router_input_text(user_text, session_docs_info, previous_intent)

        resp = llm.invoke([
            prompts.ROUTER_SYSTEM,
            HumanMessage(content=router_input_text)
        ])
        parsed = safe_parse_json(resp.content) or {}
        # Default schema when missing
        if "intent" not in parsed:
            parsed["intent"] = "general"
        if "confidence" not in parsed:
            parsed["confidence"] = "none"
        if "multi_doc" not in parsed:
            parsed["multi_doc"] = False
        if "about_documents" not in parsed:
            parsed["about_documents"] = False
        if "doc_metadata" not in parsed:
            parsed["doc_metadata"] = False

        # Post-processing: Use LLM to double-check if this is a metadata query
        if not parsed.get("about_documents") and not parsed.get("doc_metadata"):
            # Only check if router didn't already classify it as metadata
            metadata_check = llm.invoke([
                prompts.get_metadata_check_system(),
                HumanMessage(content=user_text)
            ])
            try:
                metadata_result = safe_parse_json(metadata_check.content or "{}")
                if metadata_result.get("is_metadata_query", False):
                    # Override router classification for metadata queries
                    parsed["intent"] = "general"
                    parsed["about_documents"] = True
                    parsed["doc_metadata"] = True
                    parsed["confidence"] = "none"
                    log("ROUTER",
                        f"Post-processing: Detected metadata query via LLM check, setting about_documents=True, doc_metadata=True")
            except Exception as e:
                log("ROUTER", f"Error in metadata query post-processing: {e}")

        parsed["routing_method"] = "llm"
        parsed["_embedding_doc_sim"] = doc_embedding_sim  # Include for fallback gating
        return parsed
    except Exception as e:
        log("ROUTER", f"Error in LLM router: {e}")
        return {"intent": "general", "confidence": "none", "multi_doc": False, "about_documents": False,
                "doc_metadata": False, "routing_method": "llm", "_embedding_doc_sim": doc_embedding_sim}


def run_safety_guardrail(llm: ChatOpenAI, user_text: str) -> Dict[str, Any]:
    """
    Lightweight jailbreak/safety guardrail using the LLM for classification.
    Returns {"safe": bool, "category": str, "reason": str}
    """
    prompt = prompts.get_safety_guardrail_prompt(user_text)
    try:
        resp = llm.invoke([SystemMessage(content=prompt)])
        parsed = safe_parse_json(resp.content) or {}
        safe = bool(parsed.get("safe", True))
        category = parsed.get("category", "safe")
        reason = parsed.get("reason", "")
        log("SAFETY", f"safe={safe}, category={category}, reason={reason[:80]}")
        return {"safe": safe, "category": category, "reason": reason}
    except Exception as e:
        log("SAFETY", f"Error running safety guardrail: {e}")
        return {"safe": True, "category": "safe", "reason": ""}


def classify_continuation(
        llm: ChatOpenAI,
        user_text: str,
        last_assistant_answer: Optional[str],
        has_pending_followup: bool = False
) -> Dict[str, Any]:
    """
    Classify how the assistant should continue the conversation.
    """
    prompt = prompts.get_continuation_prompt(user_text, last_assistant_answer, has_pending_followup)

    try:
        resp = llm.invoke([SystemMessage(content=prompt)])
        result = safe_parse_json(resp.content) or {"action": "proceed_normal", "presence": "light"}
        action = result.get("action", "proceed_normal")
        presence = result.get("presence", "light")
        # Never allow silence - enforce minimum presence
        if presence == "none":
            presence = "light"
        result["presence"] = presence
        log("CONTINUATION",
            f"User: '{user_text[:30]}...' -> action={action}, presence={presence}, pending_followup={has_pending_followup}")
        return result
    except Exception as e:
        log("CONTINUATION", f"Error: {e}")
        return {"action": "proceed_normal"}


def decompose_intents(llm: ChatOpenAI, query: str, has_session_docs: bool = False) -> List[Dict[str, str]]:
    """
    Decompose a compound query into atomic intents.
    """
    prompt = prompts.get_decompose_prompt(query, has_session_docs)

    try:
        resp = llm.invoke([SystemMessage(content=prompt)])
        result = safe_parse_json(resp.content) or {}
        intents = result.get("intents", [{"type": "general", "text": query}])
        if len(intents) > 1:
            log("DECOMPOSE", f"Split into {len(intents)} intents: {[i['type'] for i in intents]}")
        return intents
    except Exception as e:
        log("DECOMPOSE", f"Error: {e}")
        return [{"type": "general", "text": query}]


def extract_file_ids_from_query(
        llm: ChatOpenAI,
        query: str,
        available_files: List[Dict[str, Any]],
        session_id: str = "default"
) -> Dict[str, Any]:
    """
    LLM-based file selection: Determines which file(s) to query based on user query.
    """
    if not available_files:
        return {
            "file_ids": None,
            "confidence": "none",
            "needs_clarification": False,
            "clarification_message": None
        }

    # If only one file, no need for selection
    if len(available_files) == 1:
        return {
            "file_ids": [available_files[0]["doc_id"]],
            "confidence": "high",
            "needs_clarification": False,
            "clarification_message": None
        }

    # Build file list for LLM
    file_list = "\n".join([
        f"- {i + 1}. {f['doc_name']} (id: {f['doc_id'][:8]}...)"
        for i, f in enumerate(available_files)
    ])

    prompt = prompts.get_file_selection_prompt(query, file_list)

    try:
        resp = llm.invoke([SystemMessage(
            content="You are a file selection assistant. Analyze queries and determine which files to search."),
                           HumanMessage(content=prompt)])
        result = safe_parse_json(resp.content) or {}

        # Validate and set defaults
        file_ids = result.get("file_ids")
        confidence = result.get("confidence", "medium")
        needs_clarification = result.get("needs_clarification", False)
        clarification_message = result.get("clarification_message")

        # Validate file_ids if provided
        if file_ids and isinstance(file_ids, list) and len(file_ids) > 0:
            valid_file_ids = []
            available_file_ids = {f["doc_id"] for f in available_files}
            for fid in file_ids:
                if fid in available_file_ids:
                    valid_file_ids.append(fid)
                else:
                    # Try to match by partial ID
                    for f in available_files:
                        if f["doc_id"].startswith(fid) or fid in f["doc_id"]:
                            valid_file_ids.append(f["doc_id"])
                            break

            if not valid_file_ids:
                # Invalid file_ids, default to search all (safer than error)
                log("FILE_SELECT", f"Invalid file_ids provided, defaulting to search all files")
                file_ids = None
                confidence = "low"
            else:
                file_ids = valid_file_ids
        elif file_ids == []:
            # Empty list - treat as None (search all)
            log("FILE_SELECT", "Empty file_ids list, defaulting to search all files")
            file_ids = None

        # If needs clarification but no message, generate one
        if needs_clarification and not clarification_message:
            file_names = [f["doc_name"] for f in available_files]
            clarification_message = f"I found {len(available_files)} files. Which one(s) would you like me to use?\n\n" + "\n".join(
                [f"- {f['doc_name']}" for f in
                 available_files]) + "\n\nYou can say 'all files', specific file names, or numbers."

        log("FILE_SELECT",
            f"Query: '{query[:50]}...', file_ids={file_ids}, confidence={confidence}, needs_clarification={needs_clarification}")

        return {
            "file_ids": file_ids,
            "confidence": confidence,
            "needs_clarification": needs_clarification,
            "clarification_message": clarification_message
        }
    except Exception as e:
        log("FILE_SELECT", f"Error in file selection: {e}, defaulting to search all files")
        # On error, default to searching all files (safer than asking)
        return {
            "file_ids": None,
            "confidence": "low",
            "needs_clarification": False,
            "clarification_message": None
        }


def run_query_resolver(llm: ChatOpenAI, current_message: str, last_answer: Optional[str] = None,
                       session_docs: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """
    Resolve ambiguous queries using LLM.
    Detects if query requires context and adjusts confidence accordingly.
    """
    try:
        has_context = last_answer is not None and len(last_answer) > 0

        context_note = ""
        if not has_context:
            context_note = """
IMPORTANT: There is NO previous conversation context available. 
If the user's message contains references (like "it", "them", "those", "that", "the other thing"), 
the resolved query should indicate that context is missing, or set confidence to "low".
"""
        session_docs_names = [d.get('doc_name', 'unknown') for d in (session_docs or [])][:5]
        prompt = prompts.get_query_resolver_prompt(current_message, last_answer[:200] if last_answer else 'None (no previous context)', session_docs_names, context_note)
        
        resp = llm.invoke([SystemMessage(content=prompt)])
        result = safe_parse_json(resp.content) or {}
        resolved = result.get("resolved_query", current_message)
        confidence = result.get("confidence", "medium")
        requires_context = result.get("requires_context", False)

        # Lower confidence if context is required but missing
        if requires_context and not has_context:
            confidence = "low"
            log("QUERY_RESOLVER", f"Context-dependent query detected but no context available - lowering confidence")

        log("QUERY_RESOLVER",
            f"'{current_message[:50]}...' -> '{resolved[:80]}...' (confidence={confidence}, requires_context={requires_context})")
        return {"resolved_query": resolved, "confidence": confidence, "requires_context": requires_context}
    except Exception as e:
        log("QUERY_RESOLVER", f"Error: {e}")
        return {"resolved_query": current_message, "confidence": "low", "requires_context": False}



# rag_query moved to tools.py


