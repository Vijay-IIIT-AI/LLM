
import logging
import sys
import json
import pprint
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage

try:
    import tiktoken
    TIKTOKEN_AVAILABLE = True
except ImportError:
    TIKTOKEN_AVAILABLE = False

from .config import Config

# ==============================================================================
# LOGGING UTILS
# ==============================================================================
# Setup file logger
LOG_DIR = Path("./logs")
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE = LOG_DIR / f"chat_{datetime.now().strftime('%Y%m%d')}.log"

# Configure file logger
file_logger = logging.getLogger("chat_file")
file_logger.setLevel(logging.DEBUG)
file_handler = logging.FileHandler(LOG_FILE, encoding='utf-8')
file_handler.setLevel(logging.DEBUG)
file_formatter = logging.Formatter(
    '%(asctime)s [%(levelname)s] [%(name)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
file_handler.setFormatter(file_formatter)
file_logger.addHandler(file_handler)
file_logger.propagate = False  # Prevent duplicate logs

# Console logger (for errors/warnings only)
console_logger = logging.getLogger("chat_console")
console_logger.setLevel(logging.WARNING)
console_handler = logging.StreamHandler(sys.stderr)
console_handler.setLevel(logging.WARNING)
console_formatter = logging.Formatter('[%(levelname)s] %(message)s')
console_handler.setFormatter(console_formatter)
console_logger.addHandler(console_handler)
console_logger.propagate = False


def log(tag: str, message: str, data: Any = None):
    """Unified logger - writes to file, not console."""
    timestamp = datetime.now().strftime("%H:%M:%S")
    prefix = f"[{timestamp}] [{tag.upper()}]"
    log_message = f"{prefix} {message}"

    file_logger.debug(log_message)

    if data:
        file_logger.debug(f"{prefix} DATA: {pprint.pformat(data, indent=2)}")


def inspect_state(state: Dict[str, Any], node_name: str):
    """Logs state summary to file only."""
    state_info = f"""
--- STATE AFTER {node_name} ---
| Intent:     {state.get('router_intent', 'N/A')}
| Confidence: {state.get('router_confidence', 'N/A')}
| Docs:       {len(state.get('session_docs', []))}
| Route:      {state.get('_router_next', 'N/A')}
| Mode:       {state.get('_chat_mode', 'N/A')}
---------------------------------
"""
    file_logger.debug(state_info)


# ==============================================================================
# HELPERS
# ==============================================================================
def safe_parse_json(text: str) -> Optional[Dict[str, Any]]:
    try:
        return json.loads(text)
    except Exception:
        try:
            start = text.find("{")
            end = text.rfind("}") + 1
            if start != -1 and end != -1 and end > start:
                return json.loads(text[start:end])
        except Exception:
            return None
    return None


def get_conversation_window(messages: List[BaseMessage], max_messages: int = Config.Limits.MAX_MESSAGES, max_chars: int = 300) -> List[Dict[str, str]]:
    """Returns the last N conversational messages trimmed for safe LLM consumption."""
    window = []
    for m in messages[-max_messages:]:
        if isinstance(m, HumanMessage):
            role = "user"
        elif isinstance(m, AIMessage):
            role = "assistant"
        else:
            continue
        content = (m.content or "").strip()
        if content:
            window.append({"role": role, "content": content[:max_chars]})
    return window


def trim_messages_preserve_system(messages: List[BaseMessage], max_messages: int) -> List[BaseMessage]:
    if not messages:
        return messages
    system_msg = None
    rest = messages
    if isinstance(messages[0], SystemMessage):
        system_msg = messages[0]
        rest = messages[1:]
    if len(rest) <= max_messages:
        return ([system_msg] + rest) if system_msg else rest
    trimmed_rest = rest[-max_messages:]
    return ([system_msg] + trimmed_rest) if system_msg else trimmed_rest


# ==============================================================================
# TOKEN UTILITIES
# ==============================================================================
import functools

# Cache tokenizer instances (expensive to create)
_tokenizer_cache = {}

# Use default encoding for all models (cl100k_base works for most)
DEFAULT_ENCODING = "cl100k_base"

def get_tokenizer(model_name: str = "gpt-4o", use_cache: bool = True):
    """Get tiktoken encoding with caching."""
    if not TIKTOKEN_AVAILABLE:
        log("TOKEN_COUNT", "tiktoken not available - get_tokenizer returning None")
        return None
        
    global _tokenizer_cache
    if use_cache and model_name in _tokenizer_cache:
        return _tokenizer_cache[model_name]
    
    try:
        # Most newer OpenAI models use cl100k_base
        encoding = tiktoken.get_encoding(DEFAULT_ENCODING)
        if use_cache:
            _tokenizer_cache[model_name] = encoding
        log("TOKEN_COUNT", f"Tokenizer loaded for model: {model_name} (encoding: {DEFAULT_ENCODING})")
        return encoding
    except Exception as e:
        log("TOKEN_COUNT", f"Error loading tokenizer for {model_name}: {e}")
        return None

def count_tokens(text: str, model_name: str = "gpt-4o") -> int:
    """Count tokens in a text string."""
    if not TIKTOKEN_AVAILABLE or not text:
        return 0
    tokenizer = get_tokenizer(model_name)
    if not tokenizer:
        # Fallback approximation: 4 chars per token
        return len(text) // 4
    try:
        return len(tokenizer.encode(text))
    except Exception as e:
        log("TOKEN_ERROR", f"Error counting tokens: {e}")
        return len(text) // 4

def count_message_tokens(messages: List[BaseMessage], model_name: str = "gpt-4o") -> int:
    """Count tokens in a list of messages."""
    total = 0
    for m in messages:
        content = m.content or ""
        total += count_tokens(str(content), model_name)
    return total

def trim_history_by_tokens(messages: List[BaseMessage], model_name: str = "gpt-4o", max_tokens: int = Config.TokenBudgets.HISTORY_BUDGET) -> List[BaseMessage]:
    """Trim conversation history to fit within token budget, preserving system prompt."""
    if not messages:
        return []

    # Identify system message (usually first)
    system_msg = None
    history = messages
    if isinstance(messages[0], SystemMessage):
        system_msg = messages[0]
        history = messages[1:]
    
    # Simple check first
    current_tokens = count_message_tokens(str(history), model_name) # Approximation for list repr
    # Re-calculate accurately
    current_tokens = count_message_tokens(history, model_name)

    if current_tokens <= max_tokens:
        result = ([system_msg] + history) if system_msg else history
        return result

    # Trim from the beginning of history (oldest messages)
    # We want to keep the most recent messages
    trimmed_history = []
    accumulated_tokens = 0
    
    # Iterate backwards
    for msg in reversed(history):
        msg_tokens = count_tokens(str(msg.content or ""), model_name)
        if accumulated_tokens + msg_tokens > max_tokens:
            break
        trimmed_history.insert(0, msg)
        accumulated_tokens += msg_tokens
    
    log("TOKEN_TRIM", f"Trimmed history from {len(history)} to {len(trimmed_history)} messages ({accumulated_tokens} tokens)")
    
    result = ([system_msg] + trimmed_history) if system_msg else trimmed_history
    return result

def enforce_rag_token_limit(rag_context: str, model_name: str = "gpt-4o", max_tokens: int = Config.TokenBudgets.RAG_BUDGET) -> str:
    """Enforce token limit on RAG context string."""
    if not rag_context:
        return rag_context
        
    current_tokens = count_tokens(rag_context, model_name)
    if current_tokens <= max_tokens:
        return rag_context
        
    log("TOKEN_TRIM", f"Trimming RAG context from {current_tokens} to {max_tokens} tokens")
    
    tokenizer = get_tokenizer(model_name)
    if not tokenizer:
         # Fallback character trimming
        return rag_context[:max_tokens * 4]
        
    encoded = tokenizer.encode(rag_context)
    trimmed_encoded = encoded[:max_tokens]
    trimmed_context = tokenizer.decode(trimmed_encoded)
    
    return trimmed_context + "\n...(truncated due to length)..."


# ==============================================================================
# SESSION HELPERS
# ==============================================================================

# Placeholder for Chroma import - typically we depend on config having Chroma initialized if needed, 
# but here we just need types. Actually hydrate_session_docs uses chroma_client which was global in v2.
# We'll need to handle chroma_client. For now, assume it's available via import if properly set up, 
# or we pass it in. However, the original code had a global chroma_client.
# For modularity, we should probably instantiate it here or in a DB module. 
# Given v2.py structure, we might need a db.py or similar. 
# But for now, let's keep it simple and assume we import it from somewhere or fail gracefully.

# Wait, `chroma_client` in `v2.py` was initialized globally around line 1300? No, line 50.
# "ChromaDB and SentenceTransformer imports removed - no longer needed"
# Wait, `hydrate_session_docs_from_chroma` USES `chroma_client`. 
# In `v2.py` line 683: `collection = chroma_client.get_or_create_collection(...)`
# But if `chroma_client` was removed (as comment says "no longer needed"), then `hydrate_session_docs_from_chroma` would fail?
# Let's check `v2.py` again.
# If `chroma_client` is not defined, `hydrate` will fail.
# In `v2.py` line 50: `# ChromaDB and SentenceTransformer imports removed - no longer needed`
# BUT `hydrate_session_docs_from_chroma` (lines 675+) uses it.
# This suggests `hydrate_session_docs_from_chroma` is dead code OR `chroma_client` IS defined somewhere.
# I will check `v2.py` for `chroma_client`.

# If it's missing in v2.py, I will verify.

def dedupe_session_docs(docs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen: Dict[str, Dict[str, Any]] = {}
    for d in docs:
        doc_id = d.get("doc_id")
        if doc_id:
            seen[doc_id] = d
    return list(seen.values())

def get_session_id(state: Dict[str, Any]) -> str:
    session_id = state.get("session_id", "default")
    session_docs = state.get("session_docs", [])
    if session_docs:
        # In a real app we might check Chroma here, but for now just use state logic
        pass
    if not session_docs and session_id != "default":
        # logic to hydrate from default
        default_docs = hydrate_session_docs_from_chroma("default")
        if default_docs:
            log("SESSION_ID", f"No docs in session_id='{session_id}', found {len(default_docs)} docs in 'default', using 'default'")
            return "default"
    return session_id

def hydrate_session_docs_from_chroma(session_id: str) -> List[Dict[str, Any]]:
    # Placeholder implementation if chroma_client is missing
    # In original v2.py it seemed to depend on a global client.
    # We will log a warning if called.
    try:
        # Assuming chroma_client would be imported if available
        # from .db import chroma_client 
        # For now, return empty or try finding it
        return [] 
    except Exception as e:
        log("HYDRATE", f"Error hydrating docs: {e}")
        return []
