
from typing import List, Dict, Any, Optional
from langchain.tools import tool
from .utils import log

# Import doc_qa from algorithm module
try:
    import sys
    from pathlib import Path
    
    # Add algorithm folder to Python path
    # Assuming v2_modular is one level below root, so parent of simple path is AgenticCode
    algo_path = Path(__file__).parent.parent / "algorithm"
    
    if str(algo_path) not in sys.path:
        sys.path.insert(0, str(algo_path))
    
    from .Document.doc_qa_agentic import doc_qa
    log("IMPORTS", "Successfully imported doc_qa from algorithm/Document/doc_qa_agentic.py")
except ImportError as e:
    # Try alternate path if running from root
    try:
        from algorithm.Document.doc_qa_agentic import doc_qa
        log("IMPORTS", "Successfully imported doc_qa (direct import)")
    except ImportError:
        log("IMPORTS", f"Failed to import doc_qa: {e}")
        doc_qa = None

@tool
def rag_query(query: str, session_id: str, multi_doc: bool = False, file_ids: Optional[List[int]] = None, session_docs: Optional[List[Dict[str, Any]]] = None) -> str:
    """
    Retrieve relevant context using doc_qa from algorithm module.
    
    Args:
        query: User question
        session_id: Session ID (kept for LangGraph compatibility, not used by doc_qa)
        multi_doc: Not used by doc_qa (kept for compatibility)
        file_ids: List of file IDs (integers) to search. If None, uses all docs from session_docs.
        session_docs: Session documents metadata (used to auto-populate file_ids if None)
    
    Returns:
        Retrieved context as string (for LangGraph compatibility)
    """
    # Auto-populate file_ids from session_docs if not provided
    if not file_ids or len(file_ids) == 0:
        if session_docs and len(session_docs) > 0:
            # Extract doc_ids from session_docs
            file_ids = [doc["doc_id"] for doc in session_docs if "doc_id" in doc]
            log("RAG_QUERY", f"Auto-populated file_ids from session_docs: {file_ids}")
        else:
            log("RAG_QUERY", "No file_ids provided and no session_docs available")
            return "No documents available in this session. Please upload documents first."
    
    if not doc_qa:
        log("RAG_QUERY", "doc_qa function not available")
        return "Document retrieval system is not available. Please contact support."
    
    try:
        log("RAG_QUERY", f"Calling doc_qa: query='{query[:100]}...', fileIDs={file_ids}")
        
        # Call doc_qa (returns dict with 'context' or 'error' key)
        K = 10  # Default chunk count for retrieval
        result = doc_qa(query=query, fileIDs=file_ids, K=K)
        
        # Handle error case
        if "error" in result:
            error_msg = result["error"]
            log("RAG_QUERY", f"doc_qa returned error: {error_msg}")
            
            # Provide user-friendly error messages
            if "connection" in error_msg.lower() or "database" in error_msg.lower():
                return "Unable to connect to the document database. Please try again in a moment."
            elif "not found" in error_msg.lower():
                return "The requested documents could not be found. They may have been deleted."
            elif "permission" in error_msg.lower():
                return "You don't have permission to access these documents."
            else:
                return f"Error retrieving documents: {error_msg}"
        
        # Handle success case
        if "context" in result:
            context = result["context"]
            
            # Check for empty context
            if not context or str(context).strip() == "" or str(context).strip() == "[]":
                log("RAG_QUERY", "doc_qa returned empty context")
                return "No relevant information found in the selected documents for your question."
            
            # Convert to string if needed (doc_qa returns str(chunks))
            context_str = str(context)
            log("RAG_QUERY", f"Successfully retrieved context: {len(context_str)} chars")
            return context_str
        
        # Unexpected response format
        log("RAG_QUERY", f"Unexpected doc_qa response format: {result}")
        return "Unexpected response format from document retrieval system. Please try again."
        
    except Exception as e:
        log("RAG_QUERY", f"Exception calling doc_qa: {e}")
        import traceback
        log("RAG_QUERY", f"Traceback: {traceback.format_exc()}")
        return f"An unexpected error occurred while searching documents: {str(e)}"
