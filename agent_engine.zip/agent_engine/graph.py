from .config import *
from .utils import *
from .tools import rag_query
from .classifiers import *
from . import prompts  # Import prompts module
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import InMemorySaver
try:
    from langgraph.checkpoint.sqlite import SqliteSaver
except ImportError:
    pass
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage, SystemMessage
import asyncio
import re

# ==============================================================================
# GRAPH NODES & BUILDER
# ==============================================================================
def build_graph(llm_main: ChatOpenAI, llm_fast: ChatOpenAI, llm_answer: ChatOpenAI, max_messages: int, tools: List,
                user_context: "UserContext" = None):
    """Build the main LangGraph with router, RAG, tools, and chat nodes."""

    # Wrapper for fallback logic (Answer Model -> Main Model)
    class FallbackWrapper:
        def __init__(self, primary, fallback):
            self.primary = primary
            self.fallback = fallback
            # Proxy model_name for token trimming
            self.model_name = getattr(primary, "model_name", "gpt-4o")

        def invoke(self, *args, **kwargs):
            try:
                return self.primary.invoke(*args, **kwargs)
            except Exception as e:
                log("FALLBACK", f"Answer model failed: {e}. Falling back to main model.")
                return self.fallback.invoke(*args, **kwargs)

    # Wrap llm_answer to ensure fallback
    llm_answer = FallbackWrapper(llm_answer, llm_main)
    
    # Convert dict to UserContext object if needed (for compatibility with router.py)
    if isinstance(user_context, dict):
        user_ctx = UserContext(
            username=user_context.get("username", "User"),
            response_style=user_context.get("response_style", "detailed"),
            language_preference=user_context.get("language_preference", "auto"),
            custom_instructions=user_context.get("custom_instructions", "")
        )
    elif isinstance(user_context, UserContext):
        user_ctx = user_context
    else:
        user_ctx = DEFAULT_USER_CONTEXT
    
    # Build user context prompt addition
    user_context_prompt = f"""
USER CONTEXT (Personalization):
{user_ctx.to_prompt_context()}

Address the user by name when appropriate. Follow their style preferences.
"""

    # Helper function to extract user_context from state and format as string
    def get_user_context_str(state: ChatState) -> str:
        """Extract user_context from state and return formatted prompt string."""
        state_user_context = state.get("user_context", {})
        if isinstance(state_user_context, dict):
            ctx = UserContext(
                username=state_user_context.get("username", "User"),
                response_style=state_user_context.get("response_style", "detailed"),
                language_preference=state_user_context.get("language_preference", "auto"),
                custom_instructions=state_user_context.get("custom_instructions", "")
            )
        elif isinstance(state_user_context, UserContext):
            ctx = state_user_context
        else:
            ctx = DEFAULT_USER_CONTEXT
        return ctx.to_prompt_context()

    def chat_node(state: ChatState):
        messages = trim_messages_preserve_system(state["messages"], max_messages)
        last = messages[-1] if messages else None
        if not isinstance(last, HumanMessage):
            # Finalization step; pass router confidence and any RAG context
            router_conf = state.get("router_confidence", "none")
            rag_ctx = state.get("rag_context", None)
            log("FINALIZER",
                f"Finalizing with router_confidence={router_conf}, rag_context={'present' if rag_ctx else 'none'}")

            # Check semantic cache for similar query (context-aware)
            # Get the original user query from messages
            user_query = ""
            for msg in reversed(messages):
                if isinstance(msg, HumanMessage):
                    user_query = msg.content
                    break

            router_intent = state.get("router_intent", "general")
            session_docs = state.get("session_docs", [])

            # Track state updates for finalizer path
            state_updates_finalizer = {}

            # Cache removed - always generate fresh response
            # if user_query:
            #     cached_response = get_cached_response(user_query, None, router_intent, llm_main, session_docs)
            #     if cached_response:
            #         log("FINALIZER", "Using cached response")
            #         print("DEBUG: Hitting cached response LLM call path")
            #         ai = llm_fast.invoke([
            #             SystemMessage(content="You are a helpful assistant. Output the following cached response exactly as provided, without adding or removing anything."),
            #             HumanMessage(content=cached_response)
            #         ], config={"tags": ["final_output"]})
            #         return {"messages": [ai], **state_updates_finalizer}

            # Detect if this is a follow-up to preserve context in medium confidence scenarios
            is_followup = False
            last_resolved = state.get("last_resolved_query")
            if last_resolved and user_query and user_query != last_resolved:
                # Query was rewritten, indicating it's a follow-up
                is_followup = True

            # Handle filtered metadata queries (e.g., "how many documents related to llama")
            # Extract document names from RAG results and count/list them
            is_filtered_metadata = state.get("_filtered_metadata_query", False)
            if is_filtered_metadata and rag_ctx:
                log("FINALIZER", "Processing filtered metadata query - extracting document names from RAG results")
                # Extract document names from RAG context (format: "### From: Document Name")
                doc_names = re.findall(r'### From: ([^\n]+)', rag_ctx)
                # Remove duplicates while preserving order
                seen = set()
                unique_docs = []
                for doc_name in doc_names:
                    if doc_name not in seen:
                        seen.add(doc_name)
                        unique_docs.append(doc_name)

                if unique_docs:
                    count = len(unique_docs)
                    names_list = "\n".join(f"- {name}" for name in unique_docs)
                    response = f"I found **{count} document(s)** related to your query:\n\n{names_list}"
                    log("FINALIZER", f"Filtered metadata query: found {count} matching document(s)")
                    user_ctx_str = get_user_context_str(state)
                    ai = llm_answer.invoke([
                        SystemMessage(content=f"You are a helpful assistant. Report these document findings to the user.\n\nUSER CONTEXT:\n{user_ctx_str}"),
                        HumanMessage(content=response)
                    ], config={"tags": ["final_output"]})
                    return {
                        "messages": [ai],
                        **state_updates_finalizer
                    }
                else:
                    log("FINALIZER", "Filtered metadata query: no matching documents found in RAG results")
                    user_ctx_str = get_user_context_str(state)
                    ai = llm_answer.invoke([
                        SystemMessage(content=f"You are a helpful assistant. Explain to the user that no matching documents were found.\n\nUSER CONTEXT:\n{user_ctx_str}"),
                        HumanMessage(content="I couldn't find any documents matching your query.")
                    ], config={"tags": ["final_output"]})
                    return {
                        "messages": [ai],
                        **state_updates_finalizer
                    }

            # Truncate RAG context using token-based trimming
            if rag_ctx:
                truncated_rag = enforce_rag_token_limit(
                    rag_ctx,
                    model_name=llm_answer.model_name or "gpt-4o"
                )
            else:
                truncated_rag = None

            # Get user_context from state dynamically (per-request)
            state_user_context = state.get("user_context", {})
            if isinstance(state_user_context, dict):
                current_user_ctx = UserContext(
                    username=state_user_context.get("username", "User"),
                    response_style=state_user_context.get("response_style", "detailed"),
                    language_preference=state_user_context.get("language_preference", "auto"),
                    custom_instructions=state_user_context.get("custom_instructions", "")
                )
            elif isinstance(state_user_context, UserContext):
                current_user_ctx = state_user_context
            else:
                current_user_ctx = DEFAULT_USER_CONTEXT
            
            # Generate user context prompt dynamically
            dynamic_user_context_prompt = prompts.get_user_context_prompt(
                user_context_str=current_user_ctx.to_prompt_context()
            )

            finalize_context = SystemMessage(content=json.dumps({
                "router_confidence": router_conf,
                "rag_context": truncated_rag,
                "is_followup": is_followup,
            }) + "\n\n" + dynamic_user_context_prompt)

            # Trim messages using token-based trimming
            trimmed_msgs = trim_history_by_tokens(
                messages,
                model_name=llm_answer.model_name or "gpt-4o"
            )
            # Use prompts.FINALIZE_SYSTEM
            final_ai = llm_answer.invoke([prompts.FINALIZE_SYSTEM, finalize_context] + trimmed_msgs, config={"tags": ["final_output"]})

            # Store last assistant answer for follow-up context
            if final_ai.content:
                state_updates_finalizer["last_assistant_answer"] = final_ai.content[:500]

            # Cache removed - no longer storing responses

            # Extract suggestive question from response for follow-up context
            # Use LLM to identify if there's a follow-up question in the response
            if final_ai.content and router_intent == "document":
                try:
                    extract_prompt = f"""Extract the follow-up question from this response, if any.

Response: "{final_ai.content[-500:]}"

Output EXACT JSON only:
{{"suggestive_question": "the follow-up question" | null}}
"""
                    extract_resp = llm_main.invoke([SystemMessage(content=extract_prompt)])
                    extract_result = safe_parse_json(extract_resp.content or "{}")
                    suggestive = extract_result.get("suggestive_question")
                    if suggestive:
                        state_updates_finalizer["last_suggestive_question"] = suggestive
                        # Store actionable follow-up payload for "yes/ok" continuations
                        session_docs = state.get("session_docs", [])
                        # Extract the TOPIC from the suggestive question (not the question itself)
                        topic_extract = llm_fast.invoke([SystemMessage(content=f"""Extract the core topic/subject from this follow-up question.

Question: "{suggestive}"

Output EXACT JSON only:
{{"topic": "the core topic being offered to explore", "action": "explain" | "compare" | "detail" | "list"}}""")])
                        topic_result = safe_parse_json(topic_extract.content or "{}")
                        topic = topic_result.get("topic", suggestive)
                        action = topic_result.get("action", "explain")

                        state_updates_finalizer["last_followup_action"] = {
                            "type": "expand",  # NOT a direct query
                            "topic": topic,
                            "action": action,
                            "original_question": suggestive,
                            "router_intent": state.get("router_intent", "document"),
                            "router_confidence": state.get("router_confidence", "high"),
                            "multi_doc": state.get("router_multi_doc", False),
                            "session_doc_ids": [d["doc_id"] for d in session_docs],
                        }
                        log("FINALIZER", f"Captured follow-up topic: {topic[:80]}...")
                except Exception as e:
                    log("FINALIZER", f"Error extracting suggestive question: {e}")

            return {"messages": [final_ai], **state_updates_finalizer}

        user_msg: HumanMessage = last

        # Track all state updates to ensure they persist
        state_updates = {}

        # -------------------------
        # Chat node now receives pre-routed requests from router_node
        # Mode-specific fast paths are handled in router_node
        # -------------------------
        session_docs = state.get("session_docs", [])
        chat_mode = state.get("_chat_mode", "auto")

        # Handle file clarification: If router asked for clarification, check if user responded
        needs_clarification = state.get("_needs_file_clarification", False)
        if needs_clarification:
            clarification_msg = state.get("_file_clarification_message")
            available_files = state.get("_available_files", session_docs)

            # Check if we already have selected_file_ids (user already responded)
            if state.get("_selected_file_ids") is not None:
                # User already responded, clear clarification flag
                state_updates["_needs_file_clarification"] = False
                log("CHAT_NODE", "File clarification resolved, proceeding with selected file_ids")
            else:
                # Check if last message was from assistant (showing clarification) or user (responding)
                last_msg_before_user = None
                for msg in reversed(state["messages"][:-1]):  # Exclude current user message
                    if isinstance(msg, (AIMessage, HumanMessage)):
                        last_msg_before_user = msg
                        break

                if isinstance(last_msg_before_user, AIMessage):
                    # Last message was assistant asking clarification - user is now responding
                    log("CHAT_NODE", "User responded to file clarification, extracting file_ids")
                    user_response = user_msg.content

                    # Use LLM to extract file_ids from user's response
                    file_selection = extract_file_ids_from_query(
                        llm_fast,
                        user_response,
                        available_files,
                        get_session_id(state)
                    )

                    if file_selection.get("needs_clarification"):
                        # Still unclear - ask again (but this should be rare)
                        log("CHAT_NODE", "User response still unclear, asking again")
                        msg_content = file_selection.get("clarification_message") or clarification_msg
                        user_ctx_str = get_user_context_str(state)
                        ai = llm_answer.invoke([
                            SystemMessage(content=f"You are a helpful assistant. Ask the user this clarification question.\n\nUSER CONTEXT:\n{user_ctx_str}"),
                            HumanMessage(content=msg_content)
                        ], config={"tags": ["final_output"]})
                        return {"messages": [ai], **state_updates}
                    else:
                        # Got file_ids - clear clarification flag and route to RAG
                        selected_file_ids = file_selection.get("file_ids")
                        log("CHAT_NODE", f"Extracted file_ids from user response: {selected_file_ids}")

                        # Store file_ids and route to RAG
                        state_updates["_needs_file_clarification"] = False
                        state_updates["_selected_file_ids"] = selected_file_ids
                        state_updates["_router_next"] = "rag"
                        state_updates["router_intent"] = "document"
                        state_updates["router_confidence"] = "high"
                        state_updates["last_resolved_query"] = user_response

                        # Re-route to router_node (which will then route to rag_node)
                        return state_updates
                else:
                    # First time - show clarification message
                    log("CHAT_NODE", "Showing file clarification message")
                    if clarification_msg:
                        ai = llm_answer.invoke([
                            SystemMessage(content="You are a helpful assistant. Ask the user this clarification question."),
                            HumanMessage(content=clarification_msg)
                        ], config={"tags": ["final_output"]})
                        state_updates["_needs_file_clarification"] = True  # Keep flag for next turn
                        return {"messages": [ai], **state_updates}

        # Check if we have pre-computed continuation from router_node
        cont = state.get("_continuation")
        if not cont:
            # Fallback: compute continuation if not provided (shouldn't happen normally)
            if state.get("_force_wait"):
                state_updates["_force_wait"] = False
                cont = {"action": "wait", "presence": "light"}
                log("CHAT_NODE", f"Forced wait mode (post-clarify fatigue)")
            else:
                has_pending_followup = bool(state.get("last_followup_action"))
                cont = classify_continuation(
                    llm_fast,
                    user_msg.content,
                    state.get("last_assistant_answer"),
                    has_pending_followup=has_pending_followup
                )

        # For general mode direct response (when router sends here)
        if chat_mode == "general" and state.get("router_confidence") == "high":
            log("CHAT_NODE", f"General mode - direct LLM response")
            trimmed_msgs = trim_messages_preserve_system(messages, max_messages)
            # Use prompts.FINALIZE_SYSTEM
            final = llm_answer.invoke([prompts.FINALIZE_SYSTEM] + trimmed_msgs, config={"tags": ["final_output"]})
            if final.content:
                state_updates["last_assistant_answer"] = final.content[:500]
            return {"messages": [final], **state_updates}

        if cont["action"] == "wait":
            # ChatGPT/Claude style: NEVER return silence, always return presence
            # Energy decays with each consecutive wait interaction
            presence_count = state.get("_presence_count", 0)

            # Honor classifier's engaged hint on first wait only
            style_hint = (
                "slightly more engaged"
                if cont.get("presence") == "engaged" and presence_count == 0
                else "very low energy"
            )
            log("CONTINUATION", f"Action=wait, presence count={presence_count + 1}, style={style_hint}")

            user_ctx_str = get_user_context_str(state)
            ai = llm_answer.invoke([
                SystemMessage(content=f"""You are a calm, human-like conversational assistant (ChatGPT/Claude style).

The user is pausing or acknowledging.
This is interaction #{presence_count + 1}.
Energy level: {style_hint}

Rules:
- ALWAYS respond (never silence)
- Each response should get SHORTER and LOWER energy
- Do NOT repeat previous responses
- Do NOT ask questions after the first response
- Do NOT introduce new topics
- Signal availability, not pressure
- RESPOND IN THE SAME LANGUAGE the user is using (detect from their message)

Energy decay guide:
1 → short friendly presence
2 → very short reassurance
3+ → minimal (emoji or 1–2 words)

Tone: calm, natural, human. Match user's language.

USER CONTEXT:
{user_ctx_str}
"""),
                HumanMessage(content=user_msg.content)
            ], config={"tags": ["final_output"]})
            return {
                "messages": [ai],
                "_presence_count": presence_count + 1,
                **state_updates
            }

        if cont["action"] == "clarify":
            # User intent is ambiguous - LLM-generated clarification (not hardcoded)
            clarify_count = state.get("_clarify_count", 0)
            log("CONTINUATION", f"Action=clarify, attempt {clarify_count + 1}")

            # Clarify fatigue: minimal presence instead of silence (ChatGPT style)
            if clarify_count >= 2:
                log("CONTINUATION", "Clarify fatigue - minimal presence, forcing wait next turn")
                ai = llm_answer.invoke([
                    SystemMessage(content="""You are a calm conversational assistant.

The user seems unsure or not responding clearly.

Rules:
- ALWAYS respond (never silence)
- Very low energy
- No questions
- No guidance
- Just gentle presence (1–3 words or emoji)
- RESPOND IN THE SAME LANGUAGE the user is using (detect from their message)
"""),
                    HumanMessage(content=user_msg.content)
                ], config={"tags": ["final_output"]})
                return {
                    "messages": [ai],
                    "_clarify_count": 0,
                    "_force_wait": True,  # Prevent clarify loop on next turn
                    **state_updates
                }

            conversation_window = get_conversation_window(messages)

            # Use LLM to detect if query requires context that might be missing
            has_context = len(conversation_window) > 1  # More than just current message

            context_status = ""
            if not has_context:
                # Check if query requires context using LLM (no hardcoded keywords)
                try:
                    context_check = llm_fast.invoke([
                        SystemMessage(content="""Analyze if this user query contains references that require previous conversation context to understand.

Examples of context-dependent queries:
- Queries with pronouns or references: "explain it", "what about them", "tell me about those"
- Queries referring to previous topics: "the other thing we discussed", "what about that"
- Queries with ordinal references without clear targets: "the second one", "which one"
- Queries that are incomplete without context: "compare them", "summarize those"

Examples of context-independent queries:
- Clear standalone questions: "what is machine learning", "explain neural networks"
- Direct requests: "list my documents", "how many files do I have"
- Complete questions that don't reference previous conversation

Output EXACT JSON only:
{"requires_context": true | false, "reason": "brief explanation"}"""),
                        HumanMessage(content=user_msg.content)
                    ])
                    context_result = safe_parse_json(context_check.content or "{}")
                    requires_context = context_result.get("requires_context", False)

                    if requires_context:
                        context_status = """
IMPORTANT CONTEXT DETECTION:
- The user's query contains references that require previous conversation context.
- However, there is NO previous conversation history available (this appears to be a new conversation or history was cleared).
- You MUST explicitly mention this in your clarification: "I don't have any previous conversation context to refer to."
- Then ask what specifically they'd like help with.
"""
                except Exception as e:
                    log("CONTINUATION", f"Error checking context dependency: {e}")
                    requires_context = False
            else:
                # Context exists - let LLM infer from conversation window
                context_status = """
IMPORTANT CONTEXT DETECTION:
- Conversation history is available - try to infer what the user means from the conversation context.
- If still unclear, ask for clarification while acknowledging the available context.
"""

            user_ctx_str = get_user_context_str(state)
            ai = llm_answer.invoke([
                SystemMessage(content=f"""You are a conversational AI like ChatGPT or Claude.

The user's message was unclear or ambiguous.
Your job is to ask for clarification in a natural, helpful way.

Context:
- This is clarification attempt number {clarify_count + 1}.
- You have access to the recent conversation window.
- The user may be confused, distracted, or typing randomly.
{context_status}
Behavior rules:
- Be polite and calm.
- Do NOT scold or blame the user.
- Do NOT mention "gibberish" or "invalid input".
- Do NOT repeat yourself across attempts.
- If NO previous context exists and the query has references, explicitly state: "I don't have any previous conversation context to refer to."
- If this is the SECOND attempt, gently guide the user with examples of what they can ask.
- If this is the 3rd attempt, ask only a small question.
- RESPOND IN THE SAME LANGUAGE the user is using (detect from their message or conversation history).

USER CONTEXT:
{user_ctx_str}

Style:
- 1–2 sentences max
- Natural, conversational tone
- No technical explanations
- If context is missing, be explicit about it

Conversation window:
{json.dumps(conversation_window, indent=2)}
"""),
                HumanMessage(content=user_msg.content)
            ], config={"tags": ["final_output"]})

            # Cap clarify count at 2 (graceful silence kicks in at 3+)
            new_clarify_count = min(clarify_count + 1, 2)
            return {
                "messages": [ai],
                "_clarify_count": new_clarify_count,
                **state_updates
            }

        # Reset presence counter only when intent truly changes (not on clarify)
        if cont["action"] in ("proceed_normal", "continue"):
            state_updates["_presence_count"] = 0

        # Initialize effective_query with user message (default)
        effective_query = user_msg.content

        # Handle suggestion selection (LLM decides all matching)
        suggestions = state.get("last_suggestions", [])
        selected_suggestion = None

        if suggestions:
            match_prompt = f"""You are a suggestion matcher. Determine if the user's message refers to one of the available suggestions.

User message: "{user_msg.content}"

Available suggestions (numbered):
{json.dumps({i + 1: s for i, s in enumerate(suggestions)}, indent=2)}

Your task:
- Determine if the user is selecting, referencing, or paraphrasing one of the suggestions
- This includes: numbers ("1", "2"), ordinals ("first one", "second"), partial text, abbreviations, paraphrases
- If the user's message is a completely NEW question unrelated to suggestions, return null
- If the user wants to proceed with a suggestion (even implicitly), return it

Output EXACT JSON only:
{{"matched_suggestion": "the EXACT full suggestion text from the list" | null, "is_new_question": true | false}}"""

            try:
                match_resp = llm_fast.invoke([SystemMessage(content=match_prompt)])
                match_result = safe_parse_json(match_resp.content or "{}")
                matched = match_result.get("matched_suggestion")
                is_new = match_result.get("is_new_question", True)

                if matched and matched in suggestions and not is_new:
                    selected_suggestion = matched
                    effective_query = selected_suggestion
                    cont = {"action": "proceed_normal", "presence": "light"}
                    state_updates["last_suggestions"] = None  # Clear suggestions after use
                    log("CONTINUATION", f"Matched to suggestion: {selected_suggestion[:50]}...")
            except Exception as e:
                log("CONTINUATION", f"Error in suggestion matching: {e}")
        if cont["action"] == "continue":
            # First check if there's a stored follow-up action to execute
            followup_action = state.get("last_followup_action")

            # Issue #2 fix: LLM decides if user provided NEW semantic content that overrides follow-up
            # "yes" continues, but "tell me about X" should override
            user_has_new_intent = False
            if followup_action:
                override_prompt = f"""Determine if the user's message contains NEW semantic content that should override a pending follow-up action.

Pending follow-up question: "{state.get('last_suggestive_question', '')}"
User message: "{user_msg.content}"

Rules:
- Simple acknowledgements (yes, ok, sure, yeah, go ahead) → NOT new intent
- Short confirmations with no new info → NOT new intent
- New questions, requests, or topics → NEW intent
- Specific answers to the follow-up question → NOT new intent (they're answering it)
- Unrelated statements or commands → NEW intent
- User adds constraints/modifiers to the request (language, format, style, length, audience, etc.) → HAS MODIFIER (not new intent, but extract the modifier)

Output EXACT JSON only:
{{"has_new_intent": true | false, "has_modifier": true | false, "modifier": "extract any constraint/modifier the user added (language, format, style, etc.) or empty string", "reason": "brief reason"}}"""
                try:
                    override_resp = llm_fast.invoke([SystemMessage(content=override_prompt)])
                    override_result = safe_parse_json(override_resp.content or "{}")
                    user_has_new_intent = override_result.get("has_new_intent", False)
                    user_has_modifier = override_result.get("has_modifier", False)
                    user_modifier = override_result.get("modifier", "")
                    log("CONTINUATION",
                        f"New intent check: {user_has_new_intent}, modifier: {user_has_modifier} ({override_result.get('reason', 'unknown')})")
                except Exception as e:
                    log("CONTINUATION", f"Error checking new intent: {e}")
                    user_has_modifier = False
                    user_modifier = ""

            if followup_action and not user_has_new_intent:
                # Apply any modifier (language, format) to the follow-up action
                if user_has_modifier and user_modifier:
                    # Append modifier to the topic for the query
                    if followup_action.get("topic"):
                        followup_action["topic"] = f"{followup_action['topic']} ({user_modifier})"
                    followup_action["user_modifier"] = user_modifier
                    log("CONTINUATION", f"Applied modifier to follow-up: {user_modifier}")

                log("CONTINUATION", f"Action=continue, executing stored follow-up")
                state_updates["_execute_followup"] = followup_action
            elif followup_action and user_has_new_intent:
                # User provided new content - clear follow-up and process as new query
                log("CONTINUATION", f"Action=continue but user has new intent - clearing follow-up")
                state_updates["last_followup_action"] = None
                state_updates["last_suggestive_question"] = None
                # Fall through to normal processing
            # Only handle underspecified if NO stored follow-up action exists
            elif cont.get("followup_resolution") == "underspecified":
                log("CONTINUATION", f"Action=continue, underspecified - inferring or asking")
                last_question = state.get("last_suggestive_question", "")
                user_ctx_str = get_user_context_str(state)
                ai = llm_answer.invoke([
                    SystemMessage(content=f"""The user agreed to continue but did not specify details.

Previous question asked: "{last_question}"
User response: "{user_msg.content}"

Your task:
- Move the conversation forward
- Either infer a reasonable default OR ask a more concrete follow-up question

Rules:
- Do NOT repeat the same question
- Be more specific than before
- Keep it short (1-2 sentences)
- If you can reasonably infer what they want, just proceed with that

USER CONTEXT:
{user_ctx_str}
"""),
                    HumanMessage(content=user_msg.content)
                ], config={"tags": ["final_output"]})
                return {
                    "messages": [ai],
                    **state_updates
                }
            # If no stored follow-up and not underspecified, fall through to normal processing

        # -------------------------
        # Safety guardrail (prevents jailbreak/unsafe requests before routing/tools)
        # -------------------------
        safety = run_safety_guardrail(llm_fast, user_msg.content)
        if not safety.get("safe", True):
            log("SAFETY", f"Blocking unsafe request, category={safety.get('category')}")
            user_ctx_str = get_user_context_str(state)
            ai = llm_answer.invoke([
                SystemMessage(content=f"You are a helpful assistant. Refuse this request politely but firmly.\n\nUSER CONTEXT:\n{user_ctx_str}"),
                HumanMessage(content="Sorry, I can’t help with that.")
            ], config={"tags": ["final_output"]})
            return {
                "messages": [ai],
                **state_updates
            }

        # -------------------------
        # Follow-up fast execute (skip router/resolver/cache)
        # -------------------------
        followup_action = state_updates.get("_execute_followup") or state.get("_execute_followup")
        if followup_action:
            # Handle the NEW "expand" type (topic-based, not question-based)
            if followup_action.get("type") == "expand":
                topic = followup_action.get("topic", "")
                action = followup_action.get("action", "explain")
                multi_doc = followup_action.get("multi_doc", False)
                original_question = followup_action.get("original_question", "")

                # Build a proper query from the topic (NOT the original question)
                # Fallback to original question if topic extraction failed
                if topic and topic.strip():
                    query_text = f"{action} {topic}" if action else topic
                else:
                    # Fallback: use LLM to extract a usable query from the original question
                    fallback_resp = llm_fast.invoke([SystemMessage(content=f"""Convert this follow-up question into a direct search query.

Question: "{original_question}"

Rules:
- Remove conversational phrases like "Would you like to know more about"
- Keep the core topic/subject
- Make it a direct query suitable for document search

Output EXACT JSON only:
{{"query": "the direct search query"}}""")])
                    try:
                        fallback_result = safe_parse_json(fallback_resp.content or "{}")
                        query_text = fallback_result.get("query", original_question)
                    except:
                        query_text = original_question
                    log("FOLLOW-UP", f"Topic extraction failed, using LLM fallback: '{query_text[:50]}'")

                # Apply user modifier (language, format) if present
                user_modifier = followup_action.get("user_modifier", "")
                if user_modifier:
                    query_text = f"{query_text} {user_modifier}"
                    log("FOLLOW-UP", f"Applied modifier: '{user_modifier}'")

                log("FOLLOW-UP", f"Expanding topic: '{topic}' with action: '{action}', query: '{query_text[:60]}'")

                ai = AIMessage(content="Continuing as requested.")
                ai.tool_calls = [{
                    "name": "rag_query",
                    "args": {
                        "query": query_text,
                        "session_id": get_session_id(state),
                        "multi_doc": multi_doc,
                    },
                    "id": "followup-rag-1",
                }]
                state_updates["router_intent"] = "document"
                state_updates["router_confidence"] = followup_action.get("router_confidence", "high")
                state_updates["last_resolved_query"] = query_text
                state_updates["_rag_executed"] = True
                state_updates["_execute_followup"] = None
                state_updates["last_followup_action"] = None
                return {"messages": [ai], **state_updates}

            # Legacy support for old "document_rag" type (can be removed later)
            elif followup_action.get("type") == "document_rag":
                query_text = followup_action.get("query")
                multi_doc = followup_action.get("multi_doc", False)
                ai = AIMessage(content="Continuing as requested.")
                ai.tool_calls = [{
                    "name": "rag_query",
                    "args": {
                        "query": query_text,
                        "session_id": get_session_id(state),
                        "multi_doc": multi_doc,
                    },
                    "id": "rag-followup-1",
                }]
                # Keep router state aligned with stored action
                state_updates["router_intent"] = followup_action.get("router_intent", "document")
                state_updates["router_confidence"] = followup_action.get("router_confidence", "high")
                state_updates["router_multi_doc"] = multi_doc
                state_updates["last_resolved_query"] = query_text
                state_updates["_rag_executed"] = True
                # Clear the execute flag AND the stored follow-up action after use
                state_updates["_execute_followup"] = None
                state_updates["last_followup_action"] = None
                return {"messages": [ai], **state_updates}
            # Unknown follow-up type: drop through to normal flow

        # -------------------------
        # Unified Query Resolver (only for proceed_normal or continue without followup)
        # -------------------------
        session_docs = state.get("session_docs", [])

        # Restore qr from persisted state (prevents UnboundLocalError on skipped resolver)
        qr = state.get("_last_qr", {"resolved_query": effective_query, "confidence": "high"})

        # Only run resolver if we didn't already set effective_query from continue action
        # Skip resolver for document metadata queries (they should be handled as-is)
        route = state.get("_last_route", {})
        is_metadata_query = route.get("about_documents") or route.get("doc_metadata")

        if (cont["action"] != "continue" or not state.get("last_suggestive_question")) and not is_metadata_query:
            qr = run_query_resolver(
                llm_fast,
                user_msg.content,
                state.get("last_assistant_answer"),  # last_answer parameter
                session_docs  # session_docs parameter
            )
            effective_query = qr["resolved_query"]
            state_updates["last_resolved_query"] = effective_query
            # Persist resolver state (used later for bias checks, and across turns)
            state_updates["_last_qr"] = qr
            state_updates["last_resolver_confidence"] = qr.get("confidence", "high")
        else:
            # Use original query for metadata queries, or persisted resolver confidence
            if is_metadata_query:
                effective_query = user_msg.content
                state_updates["last_resolved_query"] = effective_query
                log("QUERY_RESOLVER", f"Skipping resolver for metadata query: '{effective_query}'")
            qr = state.get("_last_qr", {"resolved_query": effective_query, "confidence": "high"})
            qr["confidence"] = state.get("last_resolver_confidence", "high")

        # -------------------------
        # Intent Decomposition (handle compound queries like "time and weather")
        # OPTIMIZATION: Check if router_node already computed intents
        # -------------------------
        tool_intents = state.get("_tool_intents", [])
        doc_intents = []
        general_intents = []

        if tool_intents:
            # Router already found tool intents - skip redundant decomposition
            log("DECOMPOSE", f"Using {len(tool_intents)} tool intent(s) from router_node (skipped LLM call)")
            state_updates["_pending_tool_intents"] = tool_intents
        else:
            # Router didn't find tool intents - run decomposition
            intents = decompose_intents(llm_fast, effective_query, has_session_docs=bool(session_docs))

            # Classify intents (no execution here - planner handles tools)
            tool_intents = [i for i in intents if i["type"] == "tool"]
            doc_intents = [i for i in intents if i["type"] == "document"]
            general_intents = [i for i in intents if i["type"] == "general"]

            # Store tool intents for planner to handle (no hardcoded execution)
            if tool_intents:
                state_updates["_pending_tool_intents"] = tool_intents
                log("DECOMPOSE", f"{len(tool_intents)} tool intent(s) queued for planner")

        # Lock router intent if we have doc intents (prevent reclassification drift)
        if doc_intents:
            state_updates["_forced_router_intent"] = "document"
            effective_query = doc_intents[0]["text"]
            log("DECOMPOSE", f"Forcing document intent for: {effective_query[:50]}...")
        elif general_intents:
            effective_query = general_intents[0]["text"]
        # else keep original effective_query

        # -------------------------
        # Router stage
        # OPTIMIZATION: Check if router_node already computed routing
        # -------------------------
        log("ROUTER", f"Effective query: {effective_query[:100]}...")
        log("ROUTER", f"Session docs count: {len(session_docs)}")

        # Check if router_node already set router_intent (skip redundant routing)
        router_already_ran = state.get("router_intent") and state.get("_router_next")

        if router_already_ran:
            # Use pre-computed route from router_node
            # Get full route from _last_route if available (includes about_documents, doc_metadata)
            last_route = state.get("_last_route", {})
            route = {
                "intent": state.get("router_intent", "general"),
                "confidence": state.get("router_confidence", "none"),
                "multi_doc": state.get("router_multi_doc", False),
                "about_documents": last_route.get("about_documents", False),
                "doc_metadata": last_route.get("doc_metadata", False),
                "_embedding_doc_sim": last_route.get("_embedding_doc_sim", 0.0),
            }
            log("ROUTER", f"Using pre-computed route from router_node (skipped LLM call)")
        else:
            # Run unified router (LLM decides: RAG vs Tool vs General)
            # Get previous intent for hysteresis (prevent oscillation)
            previous_intent = state.get("router_intent", "general") if state.get("router_intent") != "general" else None

            # Domain change detection: reset hysteresis if topic changed significantly
            last_resolved = state.get("last_resolved_query", "")
            if last_resolved and previous_intent == "document":
                domain_check = llm_fast.invoke([SystemMessage(content=f"""Determine if these two queries are in the SAME domain/topic.

Previous query: "{last_resolved[:100]}"
Current query: "{effective_query[:100]}"

Domains: document_content, coding, chitchat, tools, metadata
Output EXACT JSON only:
{{"same_domain": true | false, "reason": "brief reason"}}""")])
                try:
                    domain_result = safe_parse_json(domain_check.content or "{}")
                    if not domain_result.get("same_domain", True):
                        log("ROUTER",
                            f"Domain change detected: {domain_result.get('reason', 'unknown')} - resetting hysteresis")
                        previous_intent = None
                        state_updates["last_followup_action"] = None
                        state_updates["last_suggestive_question"] = None
                except:
                    pass

            # Get chat mode for threshold adjustment
            chat_mode = state.get("_chat_mode", "auto")
            route = run_router(llm_fast, effective_query, session_docs, previous_intent=previous_intent,
                               chat_mode=chat_mode)

        log("ROUTER", f"Route decision: {route}")

        # Apply forced router intent from decomposition (prevents reclassification drift)
        # BUT: Don't force document intent for metadata queries (listing, counting, etc.)
        forced_intent = state_updates.get("_forced_router_intent")
        if forced_intent and not route.get("about_documents") and not route.get("doc_metadata"):
            log("ROUTER", f"Applying forced intent from decomposition: {forced_intent}")
            route["intent"] = forced_intent
        elif forced_intent and (route.get("about_documents") or route.get("doc_metadata")):
            log("ROUTER",
                f"Skipping forced intent: query is metadata query (about_documents={route.get('about_documents')}, doc_metadata={route.get('doc_metadata')})")
            route["confidence"] = "high"

        # -------------------------
        # Document fallback with relevance gate (Issue #1 fix)
        # Only apply doc fallback if query is semantically related to documents
        # -------------------------
        # Get embedding similarity to document route (already computed in run_router)
        embedding_doc_sim = route.get("_embedding_doc_sim", 0.0)

        # Document fallback should ONLY trigger if:
        # 1. Query is explicitly about documents (about_documents flag), OR
        # 2. Embedding similarity to document route is above threshold (0.35), OR
        # 3. Query contains document-referencing terms (detected by LLM router)
        should_apply_doc_fallback = (
                route.get("about_documents") or
                route.get("doc_metadata") or
                embedding_doc_sim > DOC_FALLBACK_SIM_THRESHOLD
        )

        if session_docs and route.get("intent") == "general" and should_apply_doc_fallback:
            if qr.get("confidence") == "medium":
                log("ROUTER", f"Applying document bias: medium-confidence query, doc_sim={embedding_doc_sim:.3f}")
                route["intent"] = "document"
                route["confidence"] = "medium"
            elif qr.get("confidence") == "high" and not tool_intents:
                log("ROUTER", f"Applying doc fallback: doc_sim={embedding_doc_sim:.3f} > {DOC_FALLBACK_SIM_THRESHOLD}")
                route["intent"] = "document"
                route["confidence"] = "medium"
                route["multi_doc"] = len(session_docs) > 1
        elif session_docs and route.get("intent") == "general" and not should_apply_doc_fallback:
            log("ROUTER", f"Skipping doc fallback: doc_sim={embedding_doc_sim:.3f} < 0.35, not document-related")

        # If intent is document, auto-select all documents for embedding search
        if route.get("intent") == "document" and session_docs:
            all_doc_ids = [d["doc_id"] for d in session_docs]
            state_updates["last_resolved_query"] = effective_query
            log("ROUTER", f"RAG intent: will search across all {len(all_doc_ids)} documents")

        # Persist router intent, confidence, and multi_doc flag in state
        state["router_intent"] = route.get("intent", "general")
        state["router_confidence"] = route.get("confidence", "none")
        state["router_multi_doc"] = route.get("multi_doc", False)
        state_updates["router_intent"] = state["router_intent"]
        state_updates["router_confidence"] = state["router_confidence"]
        state_updates["router_multi_doc"] = state["router_multi_doc"]
        # Store full route for metadata query detection
        state_updates["_last_route"] = route
        log("ROUTER",
            f"Final intent: {state['router_intent']}, confidence: {state['router_confidence']}, multi_doc: {state['router_multi_doc']}, about_documents={route.get('about_documents')}, doc_metadata={route.get('doc_metadata')}")

        # Handle document inventory questions explicitly (no RAG)
        # Also check if this is a metadata query even if router didn't flag it
        is_metadata_query = route.get("about_documents") or route.get("doc_metadata")
        is_filtered_query = False
        if not is_metadata_query and route.get("intent") == "general":
            # Double-check with LLM if this is a metadata query (fallback for missed cases)
            try:
                metadata_check = llm_fast.invoke([
                    SystemMessage(content="""Determine if the user query is asking about document metadata (listing, counting, names) or document content.

Use these examples to understand the distinction:

Simple metadata queries (about the document collection itself):
- User asks to list all documents they have uploaded
- User asks how many total documents they have
- User asks what documents are available
- These can be answered by listing all documents without reading content

Filtered metadata queries (require finding matching documents first):
- User asks "how many documents related to X" or "list documents about Y"
- User asks "documents related to llama" or "how many docs about transformers"
- These require searching document content to find matches, then counting/listing those matches
- Set is_filtered_query=true for these

Content queries (about information inside documents):
- User asks what a document says about a topic
- User asks to explain or summarize document content
- User asks for analysis of information from documents

IMPORTANT: If the query asks for a COUNT or LIST with a FILTER/TOPIC, this is a FILTERED query that requires RAG to find matching documents first, then count/list them. Set is_filtered_query=true.

Output EXACT JSON only:
{"is_metadata_query": true | false, "is_filtered_query": true | false, "reason": "brief reason"}"""),
                    HumanMessage(content=effective_query)
                ])
                metadata_result = safe_parse_json(metadata_check.content or "{}")
                if metadata_result.get("is_metadata_query", False):
                    is_metadata_query = True
                    route["about_documents"] = True
                    route["doc_metadata"] = True
                    is_filtered_query = metadata_result.get("is_filtered_query", False)
                    log("ROUTER",
                        f"Chat node: Detected metadata query via fallback LLM check, setting about_documents=True, doc_metadata=True, is_filtered_query={is_filtered_query}")
            except Exception as e:
                log("ROUTER", f"Error in chat_node metadata query fallback: {e}")

        # Handle filtered queries (e.g., "how many documents related to llama")
        # These need RAG to find matching documents first, then count/list them
        if is_filtered_query and session_docs:
            log("ROUTER",
                f"Filtered metadata query detected - will use RAG to find matching documents, then count/list")
            # Route to RAG to find matching documents based on the filter/topic
            route["intent"] = "document"
            route["confidence"] = "high"
            route["about_documents"] = True
            route["doc_metadata"] = True
            # Store flag to indicate this is a filtered count/list query
            state_updates["_filtered_metadata_query"] = True
            state_updates["_filtered_query_text"] = effective_query
            # Continue to RAG processing (don't return early)

        if route.get("intent") == "general" and (
                route.get("about_documents") or is_metadata_query) and not is_filtered_query:
            # Hydrate session_docs if empty
            if not session_docs:
                session_id = get_session_id(state)
                session_docs = hydrate_session_docs_from_chroma(session_id)
                if session_docs:
                    state_updates["session_docs"] = session_docs
                    log("ROUTER", f"Hydrated {len(session_docs)} document(s) for inventory query")

            if session_docs:
                names = "\n".join(f"- {d['doc_name']}" for d in session_docs)
                count = len(session_docs)
                log("ROUTER", f"Handling document inventory request: {count} document(s)")
                user_ctx_str = get_user_context_str(state)
                ai = llm_answer.invoke([
                    SystemMessage(content=f"""You are a helpful assistant.
The user asked about their documents.
You have {count} document(s) uploaded:
{names}

Respond to the user with this information in a friendly way.

USER CONTEXT:
{user_ctx_str}
"""),
                    HumanMessage(content=user_msg.content)
                ], config={"tags": ["final_output"]})
                return {
                    "messages": [ai],
                    **state_updates
                }
            else:
                user_ctx_str = get_user_context_str(state)
                ai = llm_answer.invoke([
                    SystemMessage(content=f"""You are a helpful assistant.
The user asked about documents, but they haven't uploaded any yet.
Explain that they need to upload documents or run `embedd.py` first.

USER CONTEXT:
{user_ctx_str}
"""),
                    HumanMessage(content=user_msg.content)
                ], config={"tags": ["final_output"]})
                return {
                    "messages": [ai],
                    **state_updates
                }

        # Handle document metadata/statistics questions (no RAG needed) ONLY if router flagged doc_metadata
        if route.get("doc_metadata"):
            log("ROUTER", f"Handling document metadata/statistics request")

            # Hydrate session_docs if empty
            if not session_docs:
                session_id = get_session_id(state)
                session_docs = hydrate_session_docs_from_chroma(session_id)
                if session_docs:
                    state_updates["session_docs"] = session_docs
                    log("ROUTER", f"Hydrated {len(session_docs)} document(s) for metadata query")

            if session_docs:
                # Query Chroma for document metadata
                try:
                    collection = chroma_client.get_collection(name=RAG_COLLECTION_NAME)
                    session_id = get_session_id(state)

                    metadata_info = []
                    for doc in session_docs:
                        doc_id = doc["doc_id"]
                        doc_name = doc["doc_name"]

                        # Get all chunks for this document
                        results = collection.get(
                            where={"$and": [
                                {"session_id": session_id},
                                {"doc_id": doc_id}
                            ]},
                            include=["documents", "metadatas"]
                        )

                        chunk_count = len(results.get("documents", []))
                        if chunk_count > 0:
                            docs_text = results.get("documents", [])
                            total_chars = sum(len(d) for d in docs_text)
                            avg_chunk_size = total_chars // chunk_count if chunk_count > 0 else 0

                            metadata_info.append({
                                "doc_name": doc_name,
                                "chunk_count": chunk_count,
                                "total_chars": total_chars,
                                "avg_chunk_size": avg_chunk_size
                            })

                    # Use LLM to answer the metadata question using the gathered stats
                    user_ctx_str = get_user_context_str(state)
                    metadata_prompt = f"""User question: "{user_msg.content}"

Available document metadata:
{json.dumps(metadata_info, indent=2)}

Answer the user's question about document metadata/statistics using the information above.
Be specific and helpful. If the question asks about something not captured in the metadata,
explain what information is available.

USER CONTEXT:
{user_ctx_str}"""

                    metadata_resp = llm_answer.invoke([SystemMessage(content=metadata_prompt)], config={"tags": ["final_output"]})
                    return {
                        "messages": [AIMessage(content=metadata_resp.content)],
                        **state_updates
                    }
                except Exception as e:
                    log("ROUTER", f"Error handling metadata query: {e}")
            else:
                # No documents found - give helpful message
                user_ctx_str = get_user_context_str(state)
                ai = llm_answer.invoke([
                    SystemMessage(content=f"""You are a helpful assistant.
The user asked for document metadata/statistics, but no documents are uploaded.
Explain that they need to upload documents first.

USER CONTEXT:
{user_ctx_str}
"""),
                    HumanMessage(content=user_msg.content)
                ], config={"tags": ["final_output"]})
                return {
                    "messages": [ai],
                    **state_updates
                }

        # RAG is allowed if intent is document and we have documents
        router_intent = state.get("router_intent", "general")
        router_conf = state.get("router_confidence", "none")
        router_allows_rag = router_intent == "document" and session_docs

        # -------------------------
        # Fast path: skip planner for document intent with confidence != none
        # This saves LLM calls for clear RAG cases
        # ONLY if no pending tool intents (which need planner)
        # -------------------------
        pending_tools = state_updates.get("_pending_tool_intents", [])
        if router_allows_rag and router_conf in ("high", "medium") and not pending_tools:
            log("FAST_PATH", f"Skipping planner for {router_conf}-confidence RAG")
            rag_query_text = effective_query
            ai = AIMessage(content=f"Direct RAG query ({router_conf} confidence).")
            ai.tool_calls = [{
                "name": "rag_query",
                "args": {
                    "query": rag_query_text,
                    "session_id": state.get("session_id", "default"),
                    "multi_doc": state.get("router_multi_doc", False),
                },
                "id": "rag-query-1",
            }]
            state_updates["last_resolved_query"] = rag_query_text
            state_updates["_rag_executed"] = True  # Prevent double RAG
            return {"messages": [ai], **state_updates}

        # --- OPTIMIZATION START ---
        # If we just came from RAG or the Router said "General", we just want an ANSWER.
        # We do NOT need to Plan or Verify.
        
        skip_planner = state.get("_skip_planner", False)
        rag_executed = state.get("_rag_executed", False)
        
        # If we already did RAG, or Router explicitly said "Chat", jump to Finalizer
        if skip_planner or rag_executed:
            log("CHAT_NODE", "Fast Path: Skipping Planner/Verifier, going straight to Finalizer")
            
            # Prepare Context
            rag_ctx = state.get("rag_context")
            router_conf = state.get("router_confidence", "none")
            router_intent = state.get("router_intent", "general")
            
            # Get user query from messages
            user_query = ""
            for msg in reversed(messages):
                if isinstance(msg, HumanMessage):
                    user_query = msg.content
                    break
            
            # Truncate RAG context using token-based trimming
            if rag_ctx:
                truncated_rag = enforce_rag_token_limit(
                    rag_ctx,
                    model_name=llm_main.model_name or "gpt-4o"
                )
            else:
                truncated_rag = None
            
            finalize_context = SystemMessage(content=json.dumps({
                "router_confidence": router_conf,
                "rag_context": truncated_rag,
                "is_followup": False,
            }) + "\n\n" + user_context_prompt)
            
            # Trim messages using token-based trimming
            trimmed_msgs = trim_history_by_tokens(
                messages,
                model_name=llm_main.model_name or "gpt-4o"
            )
            
            # DIRECT GENERATION (1 LLM Call)
            final_response = llm_main.invoke([prompts.get_finalize_system(Config.Identity.APP_NAME, Config.Identity.DEVELOPER_NAME), finalize_context] + trimmed_msgs, config={"tags": ["final_output"]})
            
            # Store last assistant answer for follow-up context
            if final_response.content:
                state_updates["last_assistant_answer"] = final_response.content[:500]
            
            # Cache removed - no longer storing responses
            
            return {"messages": [final_response], **state_updates}
        # --- OPTIMIZATION END ---

        # -------------------------
        # Planner (only for general intent or no-confidence cases, or when tool intents pending)
        # -------------------------
        pending_tool_intents = state_updates.get("_pending_tool_intents", [])
        
        # Get user_context from state for planner
        state_user_context = state.get("user_context", {})
        if isinstance(state_user_context, dict):
            planner_user_ctx = UserContext(
                username=state_user_context.get("username", "User"),
                response_style=state_user_context.get("response_style", "detailed"),
                language_preference=state_user_context.get("language_preference", "auto"),
                custom_instructions=state_user_context.get("custom_instructions", "")
            )
        elif isinstance(state_user_context, UserContext):
            planner_user_ctx = state_user_context
        else:
            planner_user_ctx = DEFAULT_USER_CONTEXT
        
        planner_user_context_str = planner_user_ctx.to_prompt_context()
        
        planner_context = SystemMessage(content=json.dumps({
            "router_intent": state.get("router_intent", "general"),
            "router_confidence": state.get("router_confidence", "none"),
            "pending_tool_intents": pending_tool_intents,  # Let planner handle these
        }) + "\n\nUSER CONTEXT:\n" + planner_user_context_str)
        plan_ai_msg = llm_main.invoke([planner_context, PLAN_SYSTEM] + messages)
        plan = safe_parse_json(plan_ai_msg.content or {}) or {}
        log("PLANNER", f"Raw plan response: {plan_ai_msg.content[:200]}...")

        call_tool = plan.get("call_tool", False)
        tool_name = plan.get("tool")
        tool_args = plan.get("args") or {}
        tools_array = plan.get("tools", [])  # Support multiple tools array

        # FIX 2: Validate and clean tools_array
        if tools_array:
            if not isinstance(tools_array, list):
                log("PLANNER", f"ERROR: tools_array is not a list: {type(tools_array)}, converting")
                tools_array = [tools_array] if isinstance(tools_array, dict) else []
            else:
                # Validate each tool in the array
                validated_tools = []
                for idx, tool_spec in enumerate(tools_array):
                    if isinstance(tool_spec, dict):
                        t_name = tool_spec.get("tool")
                        t_args = tool_spec.get("args", {})
                        if t_name and isinstance(t_name, str) and isinstance(t_args, dict):
                            validated_tools.append(tool_spec)
                        else:
                            log("PLANNER", f"Invalid tool spec at index {idx}: {tool_spec}")
                    else:
                        log("PLANNER", f"Tool spec at index {idx} is not a dict: {type(tool_spec)}")
                tools_array = validated_tools

        # Check if planner returned multiple tools
        if tools_array and isinstance(tools_array, list) and len(tools_array) > 0:
            log("PLANNER", f"Multiple tools detected: {len(tools_array)} tool(s)")
            call_tool = True  # Override call_tool if tools array is provided
            tool_name = None  # Clear single tool name when using array
        elif tool_name:
            # FIX 2: Validate single tool
            if not isinstance(tool_name, str):
                log("PLANNER", f"ERROR: tool_name is not a string: {tool_name} (type: {type(tool_name)})")
                tool_name = str(tool_name) if tool_name else None
                call_tool = False if not tool_name else call_tool
            if not isinstance(tool_args, dict):
                log("PLANNER", f"ERROR: tool_args is not a dict: {tool_args} (type: {type(tool_args)})")
                tool_args = {}
            if tool_name:
                log("PLANNER", f"Single tool: {tool_name}")

        # Prevent double RAG if fast path already executed
        if state_updates.get("_rag_executed") and (tool_name == "rag_query" or any(
                t.get("tool") == "rag_query" for t in tools_array if isinstance(t, dict))):
            log("PLANNER", f"RAG already executed via fast path, skipping")
            call_tool = False
        log("PLANNER",
            f"Decision: call_tool={call_tool}, tool={tool_name}, tools_array={len(tools_array) if tools_array else 0}, args={tool_args}")

        # Block all tools for pure document-inventory questions
        if route.get("about_documents"):
            log("PLANNER", "Tool plans ignored because query is about document inventory")
            call_tool = False

        # Enforce router authority: ignore RAG plans when router does not allow RAG
        if tool_name == "rag_query" and not router_allows_rag:
            log("PLANNER", "RAG plan ignored due to router intent/confidence")
            call_tool = False

        # -------------------------
        # Verifier
        # -------------------------
        allow_tool = False
        if call_tool and (tool_name or (tools_array and len(tools_array) > 0)):
            verdict = llm_main.invoke([
                VERIFIER_SYSTEM,
                HumanMessage(content=user_msg.content),
                HumanMessage(content=json.dumps(plan))
            ])
            allow_tool = verdict.content.strip().lower().startswith("yes")
            log("VERIFIER", f"Verdict: '{verdict.content.strip()}' -> allow_tool={allow_tool}")
        else:
            log("VERIFIER", f"Skipped (no tool proposed or call_tool=False)")

        # Auto-allow RAG if router says document intent
        if tool_name == "rag_query" and router_allows_rag:
            if not allow_tool:
                log("VERIFIER", "Auto-allowing RAG based on router intent")
            allow_tool = True

        # -------------------------
        # Tool scheduling
        # -------------------------
        # Handle multiple tools array first
        if allow_tool and tools_array and len(tools_array) > 0:
            log("TOOL_SCHEDULE", f"Scheduling {len(tools_array)} tool(s) from array")
            ai = AIMessage(content="Tool calls planned.")
            ai.tool_calls = []
            for idx, tool_spec in enumerate(tools_array):
                if isinstance(tool_spec, dict):
                    t_name = tool_spec.get("tool")
                    t_args = tool_spec.get("args", {})
                    if t_name:
                        log("TOOL_SCHEDULE", f"Adding tool {idx + 1}/{len(tools_array)}: {t_name} with args={t_args}")
                        # FIX 2: Ensure tool call format is correct - validate before adding
                        if t_name and isinstance(t_name, str) and isinstance(t_args, dict):
                            ai.tool_calls.append({
                                "name": t_name,
                                "args": t_args,
                                "id": f"{t_name}-{idx + 1}",
                            })
                        else:
                            log("TOOL_SCHEDULE", f"Invalid tool spec at index {idx}: name={t_name}, args={t_args}")
            if ai.tool_calls:
                return {"messages": [plan_ai_msg, ai], **state_updates}
            else:
                log("TOOL_SCHEDULE", f"No valid tools in array, falling back to single tool")

        # Handle single tool (original logic)
        if allow_tool and tool_name:
            if tool_name == "rag_query":
                if router_allows_rag and session_docs:
                    # Always search across ALL session documents - let embeddings find best match
                    all_doc_ids = [d["doc_id"] for d in session_docs]
                    # Use effective_query (may be expanded from follow-up)
                    rag_query_text = effective_query
                    log("TOOL_SCHEDULE", f"Scheduling rag_query across {len(all_doc_ids)} docs")

                    ai = AIMessage(content="Tool calls planned.")
                    ai.tool_calls = [{
                        "name": "rag_query",
                        "args": {
                            "query": rag_query_text,
                            "session_id": get_session_id(state),
                            "multi_doc": state.get("router_multi_doc", False),
                            "session_docs": session_docs,  # NEW: Pass session docs for auto-population
                        },
                        "id": "rag-query-1",
                    }]
                    # Store the resolved query for follow-up context
                    state_updates["last_resolved_query"] = rag_query_text
                    return {"messages": [plan_ai_msg, ai], **state_updates}
                else:
                    log("TOOL_SCHEDULE", f"rag_query blocked: no documents available")
        else:
            log("TOOL_SCHEDULE", f"No tool scheduled (allow_tool={allow_tool}, tool_name={tool_name})")

        log("FINALIZER", f"Generating final response without tools")

        # Initialize rag_ctx for this path (no RAG was performed)
        rag_ctx = state.get("rag_context")  # May have been set by prior tool execution

        # Check semantic cache (use resolved query for cache key)
        user_query = state.get("last_resolved_query") or user_msg.content
        router_intent = state.get("router_intent", "general")
        session_docs = state.get("session_docs", [])

        # Cache removed - always generate fresh response
        # if user_query and state.get("enable_cache", True):
        #     cached_response = get_cached_response(user_query, None, router_intent, llm_main, session_docs)
        #     if cached_response:
        #         log("FINALIZER", "Using cached response")
        #         cached_ai = llm_fast.invoke([
        #             SystemMessage(content="You are a helpful assistant. Output the following cached response exactly as provided."),
        #             HumanMessage(content=cached_response)
        #         ], config={"tags": ["final_output"]})
        #         return {"messages": [cached_ai], **state_updates}

        # Trim messages to prevent token overflow
        trimmed_msgs = trim_messages_preserve_system(messages, max_messages)

        # Add user context to finalizer (same as in the other finalizer path)
        router_conf = state.get("router_confidence", "none")
        is_followup = False
        last_resolved = state.get("last_resolved_query")
        if last_resolved and user_query and user_query != last_resolved:
            is_followup = True

        # Truncate RAG context using token-based trimming
        if rag_ctx:
            truncated_rag = enforce_rag_token_limit(
                rag_ctx,
                model_name=llm_answer.model_name or "gpt-4o"
            )
        else:
            truncated_rag = None
        
        # Get user_context from state dynamically (per-request)
        state_user_context = state.get("user_context", {})
        if isinstance(state_user_context, dict):
            current_user_ctx = UserContext(
                username=state_user_context.get("username", "User"),
                response_style=state_user_context.get("response_style", "detailed"),
                language_preference=state_user_context.get("language_preference", "auto"),
                custom_instructions=state_user_context.get("custom_instructions", "")
            )
        elif isinstance(state_user_context, UserContext):
            current_user_ctx = state_user_context
        else:
            current_user_ctx = DEFAULT_USER_CONTEXT
        
        # Generate user context prompt dynamically
        dynamic_user_context_prompt = f"""
USER CONTEXT (Personalization):
{current_user_ctx.to_prompt_context()}

Address the user by name when appropriate. Follow their style preferences.
"""
        
        finalize_context = SystemMessage(content=json.dumps({
            "router_confidence": router_conf,
            "rag_context": truncated_rag,
            "is_followup": is_followup,
        }) + "\n\n" + dynamic_user_context_prompt)

        # Finalizer should NOT use tools - generate text only
        # Use bind_tools([]) to explicitly disable tool calling if llm_main has tools bound
        # Finalizer should NOT use tools - generate text only
        # Use llm_answer for user-facing response
        final = llm_answer.invoke([prompts.get_finalize_system(Config.Identity.APP_NAME, Config.Identity.DEVELOPER_NAME), finalize_context] + trimmed_msgs, config={"tags": ["final_output"]})

        # Strip any tool calls from the final response (safety check)
        if hasattr(final, 'tool_calls') and final.tool_calls:
            log("FINALIZER",
                f"WARNING: LLM generated {len(final.tool_calls)} tool call(s) in finalizer - stripping them")
            # Create a new message without tool calls
            final = AIMessage(content=final.content)

        # Cache removed - no longer storing responses
        # if user_query and final.content and state.get("enable_cache", True):
        #     cache_response(user_query, final.content, None, router_intent, session_docs)

        # Extract suggestive question from response for follow-up context
        if final.content and router_intent == "document":
            try:
                extract_prompt = f"""Extract the follow-up question from this response, if any.

Response: "{final.content[-500:]}"

Output EXACT JSON only:
{{"suggestive_question": "the follow-up question" | null}}
"""
                extract_resp = llm_main.invoke([SystemMessage(content=extract_prompt)])
                extract_result = safe_parse_json(extract_resp.content or "{}")
                suggestive = extract_result.get("suggestive_question")
                if suggestive:
                    state_updates["last_suggestive_question"] = suggestive
                    # Extract the TOPIC from the suggestive question (not the question itself)
                    topic_extract = llm_fast.invoke([SystemMessage(content=f"""Extract the core topic/subject from this follow-up question.

Question: "{suggestive}"

Output EXACT JSON only:
{{"topic": "the core topic being offered to explore", "action": "explain" | "compare" | "detail" | "list"}}""")])
                    topic_result = safe_parse_json(topic_extract.content or "{}")
                    topic = topic_result.get("topic", suggestive)
                    action = topic_result.get("action", "explain")

                    state_updates["last_followup_action"] = {
                        "type": "expand",  # NOT a direct query
                        "topic": topic,
                        "action": action,
                        "original_question": suggestive,
                        "router_intent": router_intent,
                        "router_confidence": router_conf,
                        "multi_doc": state.get("router_multi_doc", False),
                        "session_doc_ids": [d["doc_id"] for d in session_docs],
                    }
                    log("FINALIZER", f"Captured follow-up topic: {topic[:80]}...")
            except Exception as e:
                log("FINALIZER", f"Error extracting suggestive question: {e}")

        # -------------------------
        # Suggestion Generator (ChatGPT-style follow-up suggestions)
        # Only show when: high/medium confidence, document intent, or long answer
        # -------------------------
        show_suggestions = (
                router_conf in ("high", "medium") or
                router_intent == "document" or
                len(final.content) > 500
        )

        if show_suggestions:
            try:
                conversation_window = get_conversation_window(messages)
                suggestion_prompt = f"""You are a conversation continuation generator.

Your job is to suggest what the USER might naturally ask or say next.

Context:
- Router intent: {router_intent}
- Router confidence: {router_conf}
- Last resolved query: {state.get("last_resolved_query", "")}
- Assistant answer (last 800 chars): {final.content[-800:]}
- RAG context used: {(rag_ctx or "")[:1000]}
- Recent conversation: {json.dumps(conversation_window[-6:], indent=2)}

Rules:
- Suggestions MUST feel like natural user messages
- Suggestions must continue the SAME topic (no new topics)
- Base them on what the user seems interested in
- Prefer concrete, useful follow-ups over generic ones
- Avoid repeating what was already answered
- Avoid yes/no questions unless natural

When documents are involved:
- At least 2 suggestions must be grounded in the document content
- Use terminology that appeared in the chunks

Output EXACT JSON only:
{{"suggestions": ["suggestion 1", "suggestion 2", "suggestion 3"]}}"""

                suggestions_resp = llm_fast.invoke([SystemMessage(content=suggestion_prompt)])
                suggestions_result = safe_parse_json(suggestions_resp.content or "{}")
                suggestions = suggestions_result.get("suggestions", [])

                if suggestions and len(suggestions) >= 2:
                    state_updates["last_suggestions"] = suggestions
                    # Append suggestions to response (ChatGPT style - text, not buttons)
                    final.content += "\n\n**You could also ask:**\n"
                    for s in suggestions[:4]:
                        final.content += f"- {s}\n"
                    log("FINALIZER", f"Generated {len(suggestions)} suggestions")
            except Exception as e:
                log("FINALIZER", f"Error generating suggestions: {e}")

        return {"messages": [final], **state_updates}

    def tool_node(state: ChatState):
        last = state["messages"][-1]
        msgs = []
        rag_ctx: Optional[str] = None
        new_session_docs = []  # Track new documents added

        if isinstance(last, AIMessage) and getattr(last, "tool_calls", None):
            log("TOOL_EXEC", f"Executing {len(last.tool_calls)} tool call(s)")
            for tc in last.tool_calls:
                log("TOOL_EXEC", f"Calling {tc['name']}", data=tc.get("args", {}))
                for t in tools:
                    if t.name == tc["name"]:
                        res = t.invoke(tc["args"])
                        result_preview = str(res)[:200] + "..." if len(str(res)) > 200 else str(res)
                        log("TOOL_EXEC", f"Result from {tc['name']}: {result_preview}")
                        msgs.append(ToolMessage(content=str(res), tool_call_id=tc["id"]))

                        # Capture RAG context for speculative finalization
                        # Only set rag_context if RAG succeeded (not an error)
                        if t.name == "rag_query":
                            res_str = str(res)
                            if not res_str.startswith("Error"):
                                rag_ctx = res_str
                                log("TOOL_EXEC", f"RAG context captured ({len(rag_ctx)} chars)")
                            else:
                                log("TOOL_EXEC", f"RAG query failed: {res_str[:100]}...")
        else:
            log("TOOL_EXEC", "No tool calls found in last message")

        out: Dict[str, Any] = {"messages": msgs}
        if rag_ctx is not None:
            out["rag_context"] = rag_ctx
            out["_rag_executed"] = True  # CRITICAL for fast path
            out["_skip_planner"] = True  # CRITICAL for fast path

        # Update session_docs if new documents were added
        if new_session_docs:
            current_docs = state.get("session_docs", [])
            merged_docs = current_docs + new_session_docs
            deduped_docs = dedupe_session_docs(merged_docs)
            out["session_docs"] = deduped_docs
            log("TOOL_EXEC", f"Updated session_docs: {len(deduped_docs)} total document(s)")

            # Force hydration from Chroma to ensure consistency
            # This prevents the "first question after upload fails" issue
            session_id = state.get("session_id", "default")
            hydrated_docs = hydrate_session_docs_from_chroma(session_id)
            if hydrated_docs:
                out["session_docs"] = dedupe_session_docs(hydrated_docs)
                log("TOOL_EXEC", f"Force-hydrated session_docs: {len(out['session_docs'])} document(s)")

        return out

    # -------------------------
    # Router Node: Optimized - Single LLM call decision point
    # -------------------------
    def router_node(state: ChatState):
        """
        Optimized Router: Single LLM call decision point.
        Replaces multiple separate calls (Safety, Resolver, Decomposer, Intent Router) with one unified call.
        """
        inspect_state(state, "ROUTER_NODE_START")

        messages = state["messages"]
        last = messages[-1] if messages else None

        # If not a human message, go to finalizer
        if not isinstance(last, HumanMessage):
            return {"_router_next": "finalizer"}

        user_msg = last
        state_updates = {}

        # 1. Get Session Data
        session_id = get_session_id(state)  
        
        session_docs = state_updates.get("session_docs") or state.get("session_docs", [])

        # 2. RUN UNIFIED ROUTER (The only LLM call in this node)
        route_decision = run_unified_router(llm_fast, user_msg.content, session_docs, messages)

        # 3. Handle Safety
        if not route_decision.get("safe", True):
            return {"_router_next": "unsafe", "_safety_reason": "Policy Violation"}

        # 3.5 Handle Clarification (Ambiguity detected by Router)
        if route_decision.get("needs_clarification"):
            state_updates["router_intent"] = "general"
            state_updates["_router_next"] = "chat"
            state_updates["_skip_planner"] = True
            
            # Inject the reason so the Finalizer knows WHAT to ask
            reason = route_decision.get("clarification_reason", "The request is ambiguous.")
            state_updates["rag_context"] = f"SYSTEM NOTE: The user's request was ambiguous: {reason}. Ask them to clarify."
            
            log("ROUTER_NODE", f"Ambiguity detected: {reason} - routing to chat")
            return state_updates

        # 4. Handle Metadata Queries (Inventory) locally - SKIP LLM
        if route_decision.get("is_metadata"):
            state_updates["router_intent"] = "general"
            state_updates["_router_next"] = "chat"
            state_updates["_skip_planner"] = True
            
            # CRITICAL: Set these so chat_node knows to list the files!
            state_updates["_last_route"] = {
                "intent": "general",
                "about_documents": True, # This triggers the listing code in chat_node
                "doc_metadata": True
            }
            
            log("ROUTER_NODE", "Metadata query detected - routing to chat with skip_planner")
            return state_updates

        # 5. Routing Logic
        intent = route_decision.get("intent", "general")
        refined_query = route_decision.get("refined_query", user_msg.content)

        # Store the refined query (saves the Resolver step later)
        state_updates["last_resolved_query"] = refined_query
        state_updates["router_intent"] = intent
        state_updates["router_confidence"] = route_decision.get("confidence", "high")

        if intent == "rag" and session_docs:
            log("ROUTER_NODE", f"Routing to RAG with query: {refined_query}")
            state_updates["_router_next"] = "rag"
            state_updates["_selected_file_ids"] = route_decision.get("file_ids")
        else:
            log("ROUTER_NODE", "Routing to General Chat")
            state_updates["_router_next"] = "chat"
            # CRITICAL: Tell chat node to SKIP planning/verifying for general chat
            state_updates["_skip_planner"] = True

        return state_updates

        # -------------------------
        # RAG MODE: Direct to RAG (with question decomposition)
        # Give LOW PRIORITY to general questions - route them to chat instead
        # -------------------------
        if chat_mode == "rag":
            log("ROUTER_NODE", "RAG mode - checking query type")
            # Initialize effective_query for RAG mode
            effective_query = user_msg.content
            if not session_docs:
                log("ROUTER_NODE", "No docs - falling back to chat")
                state_updates["_router_next"] = "chat"
                state_updates["router_intent"] = "general"
            else:
                # Check if this is a metadata query (list documents, count, etc.) - these should go to chat, not RAG
                # Use LLM to detect metadata queries instead of hardcoded keywords
                metadata_check = llm_fast.invoke([SystemMessage(content=f"""Determine if this query is asking about document metadata (list, count, names) rather than document content.

Query: "{effective_query}"

Use these examples to understand the distinction:

Metadata queries (about the document collection itself):
- User asks to list all documents they have uploaded
- User asks how many total documents they have
- User asks what documents are available or what files are uploaded
- These can be answered by listing all documents without reading content

Content queries (about information inside documents):
- User asks what a document says about a topic
- User asks to explain or summarize document content
- User asks for analysis of information from documents

Output EXACT JSON only:
{{"is_metadata_query": true | false, "reason": "brief reason"}}"""), HumanMessage(content=effective_query)])

                try:
                    metadata_result = safe_parse_json(metadata_check.content or "{}")
                    is_metadata_query = metadata_result.get("is_metadata_query", False)
                except Exception as e:
                    log("ROUTER_NODE", f"Error checking metadata query: {e}, defaulting to False")
                    is_metadata_query = False

                if is_metadata_query:
                    log("ROUTER_NODE", f"RAG mode: Metadata query detected - routing to chat (not RAG)")
                    state_updates["_router_next"] = "chat"
                    state_updates["router_intent"] = "general"
                    state_updates["router_confidence"] = "none"
                    state_updates["_last_route"] = {
                        "intent": "general",
                        "confidence": "none",
                        "about_documents": True,
                        "doc_metadata": True
                    }
                    log("ROUTER_NODE", f"Routing to: {state_updates.get('_router_next')}")
                    return state_updates

                # Decompose multiple questions in RAG mode
                # effective_query already initialized at start of RAG mode block
                intents = decompose_intents(llm_fast, effective_query, bool(session_docs))

                # Filter to only document intents (in RAG mode, we prioritize document queries)
                doc_intents = [i for i in intents if i.get("type") == "document"]
                general_intents = [i for i in intents if i.get("type") == "general"]

                # RAG mode: Give LOW PRIORITY to general questions - route to chat instead
                if len(doc_intents) == 0 and len(general_intents) > 0:
                    # Pure general question in RAG mode - route to chat (low priority)
                    log("ROUTER_NODE",
                        f"RAG mode: General question detected (LOW PRIORITY) - routing to chat instead of RAG")
                    state_updates["_router_next"] = "chat"
                    state_updates["router_intent"] = "general"
                    state_updates["router_confidence"] = "medium"
                    log("ROUTER_NODE", f"Routing to: {state_updates.get('_router_next')}")
                    return state_updates

                if len(doc_intents) > 1:
                    # Multiple document questions - store them for processing
                    log("ROUTER_NODE",
                        f"RAG mode: Detected {len(doc_intents)} document questions, will process separately")
                    state_updates["_multi_rag_queries"] = [i["text"] for i in doc_intents]
                    # Use first question for initial routing
                    effective_query = doc_intents[0]["text"]
                elif len(doc_intents) == 1:
                    # Single document question
                    effective_query = doc_intents[0]["text"]
                elif len(intents) > 1:
                    # Multiple questions but none are document-related - use first one
                    log("ROUTER_NODE",
                        f"RAG mode: {len(intents)} questions detected, but none are document queries. Using first question.")
                    effective_query = intents[0]["text"]

                # File selection: Determine which file(s) to query
                file_selection = extract_file_ids_from_query(
                    llm_fast,
                    effective_query,
                    session_docs,
                    session_id
                )

                # Handle clarification if needed
                if file_selection.get("needs_clarification"):
                    # Store clarification state and route to chat for user interaction
                    state_updates["_router_next"] = "chat"
                    state_updates["router_intent"] = "document"
                    state_updates["_needs_file_clarification"] = True
                    state_updates["_file_clarification_message"] = file_selection.get("clarification_message")
                    state_updates["_available_files"] = session_docs
                    log("ROUTER_NODE", "File selection needs clarification - routing to chat")
                else:
                    # Store selected file_ids for rag_node
                    state_updates["_router_next"] = "rag"
                    state_updates["router_intent"] = "document"
                    state_updates["router_confidence"] = "high"
                    state_updates["last_resolved_query"] = effective_query
                    state_updates["_selected_file_ids"] = file_selection.get("file_ids")
                    log("ROUTER_NODE",
                        f"File selection: file_ids={file_selection.get('file_ids')}, confidence={file_selection.get('confidence')}")
            log("ROUTER_NODE", f"Routing to: {state_updates.get('_router_next')}")
            return state_updates

        # -------------------------
        # GENERAL MODE: Direct to chat (with tool check)
        # -------------------------
        if chat_mode == "general":
            log("ROUTER_NODE", "General mode - checking for tools/explicit doc request")

            # Check for explicit document request
            if session_docs:
                doc_check = llm_fast.invoke([SystemMessage(content=f"""Does this message EXPLICITLY ask about uploaded documents?
Message: "{user_msg.content}"
Output EXACT JSON: {{"explicit_doc_request": true | false}}""")])
                try:
                    wants_docs = safe_parse_json(doc_check.content or "{}").get("explicit_doc_request", False)
                    if wants_docs:
                        log("ROUTER_NODE", "Explicit doc request - routing to rag")
                        state_updates["_router_next"] = "rag"
                        state_updates["router_intent"] = "document"
                        state_updates["router_confidence"] = "medium"
                        return state_updates
                except:
                    pass

            # Check for tool intents
            tool_check = llm_fast.invoke([SystemMessage(content=f"""Does this need a tool? Tools: rag_query
Message: "{user_msg.content}"
Output EXACT JSON: {{"needs_tool": true|false, "tool": "name"|null, "args": {{}}|null}}""")])
            try:
                tool_result = safe_parse_json(tool_check.content or "{}")
                if tool_result.get("needs_tool") and tool_result.get("tool"):
                    state_updates["_router_next"] = "tools"
                    state_updates["_router_tool_call"] = {
                        "name": tool_result["tool"],
                        "args": tool_result.get("args", {})
                    }
                    state_updates["router_intent"] = "general"
                    log("ROUTER_NODE", f"Tool detected - routing to tools", data=tool_result)
                    return state_updates
            except:
                pass

            state_updates["_router_next"] = "chat"
            state_updates["router_intent"] = "general"
            state_updates["router_confidence"] = "high"
            log("ROUTER_NODE", f"Routing to: chat (general mode)")
            return state_updates

        # -------------------------
        # AUTO MODE: Full routing logic
        # -------------------------
        log("ROUTER_NODE", "Auto mode - full routing")

        # ========================================
        # PARALLELIZE: Continuation + Query Resolver (independent operations)
        # Using AsyncIO for optimal performance
        # ========================================
        has_pending_followup = bool(state.get("last_followup_action"))
        force_wait = state.get("_force_wait", False)

        # Run continuation and query resolver in parallel using AsyncIO
        # Use asyncio.to_thread to run sync LLM calls in parallel (optimal for I/O-bound operations)
        async def run_parallel():
            if force_wait:
                cont = {"action": "wait", "presence": "light"}
                # Only run query resolver
                qr = await asyncio.to_thread(
                    run_query_resolver,
                    llm_fast,
                    user_msg.content,
                    state.get("last_assistant_answer"),
                    session_docs
                )
                return cont, qr
            else:
                # Run both in parallel using asyncio.gather (optimal performance)
                cont, qr = await asyncio.gather(
                    asyncio.to_thread(
                        classify_continuation,
                        llm_fast,
                        user_msg.content,
                        state.get("last_assistant_answer"),
                        has_pending_followup
                    ),
                    asyncio.to_thread(
                        run_query_resolver,
                        llm_fast,
                        user_msg.content,
                        state.get("last_assistant_answer"),
                        session_docs
                    )
                )
                return cont, qr

        # Execute async function (LangGraph nodes are sync, so asyncio.run is safe)
        cont, qr = asyncio.run(run_parallel())

        if force_wait:
            state_updates["_force_wait"] = False

        log("ROUTER_NODE", f"AsyncIO parallel execution: Continuation and Query Resolver completed")

        # Store continuation result for chat_node
        state_updates["_continuation"] = cont
        log("ROUTER_NODE", f"Continuation: {cont.get('action')}")

        # Quick exits for wait/clarify
        if cont["action"] in ("wait", "clarify"):
            state_updates["_router_next"] = "chat"  # chat_node handles these
            log("ROUTER_NODE", f"Routing to: chat ({cont['action']})")
            return state_updates

        # For continue with pending followup, route to RAG directly
        if cont["action"] == "continue" and has_pending_followup:
            followup = state.get("last_followup_action", {})
            if followup.get("type") in ("expand", "document_rag"):
                log("ROUTER_NODE", "Continue with followup - routing to rag")
                state_updates["_router_next"] = "rag"
                state_updates["_execute_followup"] = followup
                state_updates["router_intent"] = "document"
                state_updates["router_confidence"] = followup.get("router_confidence", "high")
                return state_updates

        # Full routing for proceed_normal
        effective_query = user_msg.content

        # Use resolved query from parallel execution
        if qr.get("resolved_query"):
            effective_query = qr["resolved_query"]
            state_updates["last_resolved_query"] = effective_query

        # Intent decomposition
        intents = decompose_intents(llm_fast, effective_query, bool(session_docs))
        tool_intents = [i for i in intents if i.get("type") == "tool"]

        # Run router
        previous_intent = state.get("router_intent") if state.get("router_intent") != "general" else None
        # Get chat mode for threshold adjustment
        chat_mode = state.get("_chat_mode", "auto")
        route = run_router(llm_fast, effective_query, session_docs, previous_intent=previous_intent,
                           chat_mode=chat_mode)

        state_updates["router_intent"] = route.get("intent", "general")
        state_updates["router_confidence"] = route.get("confidence", "none")
        state_updates["router_multi_doc"] = route.get("multi_doc", False)
        # Store full route for chat_node to access (includes about_documents, doc_metadata flags)
        state_updates["_last_route"] = route

        # Determine next node based on routing
        if route.get("intent") == "document" and session_docs:
            log("ROUTER_NODE", "Document intent - routing to rag",
                data={"intent": route.get("intent"), "confidence": route.get("confidence")})

            # File selection: Determine which file(s) to query
            file_selection = extract_file_ids_from_query(
                llm_fast,
                effective_query,
                session_docs,
                session_id
            )

            # Handle clarification if needed
            if file_selection.get("needs_clarification"):
                # Store clarification state and route to chat for user interaction
                state_updates["_router_next"] = "chat"
                state_updates["_needs_file_clarification"] = True
                state_updates["_file_clarification_message"] = file_selection.get("clarification_message")
                state_updates["_available_files"] = session_docs
                log("ROUTER_NODE", "File selection needs clarification - routing to chat")
            else:
                # Store selected file_ids for rag_node
                state_updates["_router_next"] = "rag"
                state_updates["_selected_file_ids"] = file_selection.get("file_ids")
                log("ROUTER_NODE",
                    f"File selection: file_ids={file_selection.get('file_ids')}, confidence={file_selection.get('confidence')}")
        elif tool_intents:
            log("ROUTER_NODE", "Tool intent detected - routing to planner",
                data={"tools": [t.get("text") for t in tool_intents]})
            state_updates["_router_next"] = "chat"  # chat_node handles planning
            state_updates["_tool_intents"] = tool_intents
        else:
            log("ROUTER_NODE", "General intent - routing to chat")
            state_updates["_router_next"] = "chat"

        return state_updates

    # -------------------------
    # RAG Node: Direct document retrieval
    # -------------------------
    def rag_node(state: ChatState):
        """
        Dedicated RAG node - handles document retrieval.
        """
        inspect_state(state, "RAG_NODE_START")

        # Get session_id using centralized function
        session_id = get_session_id(state)
        session_docs = state.get("session_docs", [])

        # If session_id was changed by get_session_id, update state
        if session_id != state.get("session_id", "default"):
            # Re-hydrate docs for the correct session_id
            session_docs = hydrate_session_docs_from_chroma(session_id)
            if session_docs:
                log("RAG_NODE", f"Updated session_id to '{session_id}' (found {len(session_docs)} docs)")

        # Get query - either from followup or last resolved
        followup = state.get("_execute_followup")
        if followup:
            if followup.get("type") == "expand":
                topic = followup.get("topic", "")
                action = followup.get("action", "explain")
                query = f"{action} {topic}" if topic else followup.get("original_question", "")
            else:
                query = followup.get("query", "")
            log("RAG_NODE", f"Executing followup query: {query[:60]}...")
        else:
            query = state.get("last_resolved_query") or ""
            if not query:
                # Get from last human message
                for msg in reversed(state["messages"]):
                    if isinstance(msg, HumanMessage):
                        query = msg.content
                        break

            # FIX 4: Use LLM to determine if query is ambiguous and should auto-summarize
            if len(session_docs) == 1:
                # Check if query is ambiguous (e.g., "summarize the paper" without specifying which)
                ambiguity_check_prompt = f"""Analyze this query and determine if it's ambiguous about which document to use.

Query: "{query}"
Available documents: 1 document ({session_docs[0].get('doc_name', 'unknown')})

An ambiguous query is one that refers to "the paper", "the document", "it" without specifying which document.
A specific query mentions document names, topics, or content that identifies a particular document.

Respond with EXACT JSON:
{{
  "is_ambiguous": true|false,
  "should_auto_summarize": true|false,
  "reason": "brief explanation"
}}

If is_ambiguous=true and should_auto_summarize=true, the system should automatically use the single available document."""

                try:
                    ambiguity_check_response = llm_fast.invoke([
                        SystemMessage(
                            content="You are a query analysis expert. Determine if document queries are ambiguous."),
                        HumanMessage(content=ambiguity_check_prompt)
                    ])
                    ambiguity_result = safe_parse_json(ambiguity_check_response.content or "{}")

                    if ambiguity_result.get("should_auto_summarize", False):
                        log("RAG_NODE",
                            f"LLM detected ambiguous query with single document - auto-summarizing. Reason: {ambiguity_result.get('reason', 'N/A')}")
                    else:
                        log("RAG_NODE",
                            f"Query is specific or LLM recommends not auto-summarizing. Reason: {ambiguity_result.get('reason', 'N/A')}")
                except Exception as e:
                    log("RAG_NODE", f"Ambiguity check failed: {e}, proceeding normally")
            elif len(session_docs) == 0:
                log("RAG_NODE", "No documents available")
            elif len(session_docs) > 1:
                log("RAG_NODE", f"Multiple documents ({len(session_docs)}), will use multi_doc if needed")

            log("RAG_NODE", f"Query: {query[:60]}...")

        multi_doc = state.get("router_multi_doc", False) or len(session_docs) > 1
        log("RAG_NODE", f"multi_doc={multi_doc}, docs={len(session_docs)}")

        # Get selected file_ids from router (if any)
        selected_file_ids = state.get("_selected_file_ids")
        log("RAG_NODE", f"Selected file_ids: {selected_file_ids}")

        # Check if there are multiple RAG queries to process
        multi_rag_queries = state.get("_multi_rag_queries", [])

        if multi_rag_queries and len(multi_rag_queries) > 1:
            # Multiple questions: create multiple tool calls
            log("RAG_NODE", f"Processing {len(multi_rag_queries)} separate RAG queries")
            ai = AIMessage(content=f"Searching documents for {len(multi_rag_queries)} questions...")
            ai.tool_calls = []
            for idx, q in enumerate(multi_rag_queries, 1):
                ai.tool_calls.append({
                    "name": "rag_query",
                    "args": {
                        "query": q,
                        "session_id": session_id,
                        "multi_doc": multi_doc,
                        "file_ids": selected_file_ids,  # Pass selected file_ids
                        "session_docs": session_docs,  # NEW: Pass session docs for auto-population
                    },
                    "id": f"rag-node-query-{idx}",
                })
            # Store all queries for finalizer to combine
            state_updates = {
                "messages": [ai],
                "last_resolved_query": query,  # Keep first query as primary
                "_execute_followup": None,
                "last_followup_action": None,
                "_multi_rag_queries": None,  # Clear after use
                "_processed_rag_queries": multi_rag_queries,  # Store for finalizer
                "_rag_executed": True,         # CRITICAL for fast path
                "_skip_planner": True          # CRITICAL for fast path
            }
        else:
            # Single question: normal flow
            ai = AIMessage(content="Searching documents...")
            ai.tool_calls = [{
                "name": "rag_query",
                "args": {
                    "query": query,
                    "session_id": session_id,
                    "multi_doc": multi_doc,
                    "file_ids": selected_file_ids,  # Pass selected file_ids
                    "session_docs": session_docs,  # NEW: Pass session docs for auto-population
                },
                "id": "rag-node-query-1",
            }]
            state_updates = {
                "messages": [ai],
                "last_resolved_query": query,
                "_execute_followup": None,  # Clear after use
                "last_followup_action": None,
                "_router_next": None,  # Clear any routing flags to prevent loops
                "_rag_executed": True,         # CRITICAL for fast path
                "_skip_planner": True          # CRITICAL for fast path
            }

        return state_updates

    # -------------------------
    # Routing function for conditional edges
    # -------------------------
    def route_after_router(state: ChatState) -> str:
        """Determine next node based on router decision."""
        next_node = state.get("_router_next", "chat")

        if next_node == "unsafe":
            return "unsafe_response"
        elif next_node == "rag":
            return "rag"
        elif next_node == "tools":
            return "tools_direct"
        elif next_node == "finalizer":
            return "finalizer"
        else:
            return "chat"

    # -------------------------
    # Unsafe response node
    # -------------------------
    def unsafe_response_node(state: ChatState):
        """Handle unsafe requests."""
        reason = state.get("_safety_reason", "policy violation")
        # Wrap in LLM call for streaming (final_output tag)
        unsafe_ai = llm_answer.invoke([
            SystemMessage(content="You are a helpful assistant. Politely refuse this request."),
            HumanMessage(content=f"I can't help with that request. ({reason})")
        ], config={"tags": ["final_output"]})
        return {
            "messages": [unsafe_ai]
        }

    # -------------------------
    # Direct tools node (for general mode)
    # -------------------------
    def tools_direct_node(state: ChatState):
        """Execute tool directly from router (for general mode speed)."""
        tool_call = state.get("_router_tool_call", {})
        if not tool_call:
            return {"_router_next": "chat"}

        ai = AIMessage(content="Processing...")
        ai.tool_calls = [{
            "name": tool_call["name"],
            "args": tool_call.get("args", {}),
            "id": f"direct-{tool_call['name']}-1",
        }]
        return {"messages": [ai]}

    # -------------------------
    # Build the graph with new architecture
    # -------------------------
    graph = StateGraph(ChatState)

    # Add nodes
    graph.add_node("router", router_node)
    graph.add_node("rag", rag_node)
    graph.add_node("chat", chat_node)
    graph.add_node("tools", tool_node)
    graph.add_node("tools_direct", tools_direct_node)
    graph.add_node("unsafe_response", unsafe_response_node)

    # Entry point is router
    graph.set_entry_point("router")

    # Conditional edges from router
    graph.add_conditional_edges(
        "router",
        route_after_router,
        {
            "rag": "rag",
            "chat": "chat",
            "tools_direct": "tools_direct",
            "unsafe_response": "unsafe_response",
            "finalizer": "chat",  # finalizer logic is in chat_node
        }
    )

    # RAG -> tools (for tool execution) -> chat (for finalization)
    graph.add_edge("rag", "tools")
    graph.add_edge("tools", "chat")

    # tools_direct -> tools -> chat
    graph.add_edge("tools_direct", "tools")

    # Chat conditional edges (for tool calls from planner and re-routing after clarification)
    def route_after_chat(state: ChatState) -> str:
        """Route from chat node based on tool calls or re-routing flags."""
        last_msg = state["messages"][-1] if state["messages"] else None

        # Check if there are tool calls
        if last_msg and getattr(last_msg, "tool_calls", None):
            return "tools"

        # Check if chat_node set _router_next for re-routing (e.g., after file clarification)
        next_node = state.get("_router_next")
        if next_node == "rag":
            return "rag"
        elif next_node == "router":
            return "router"

        return "end"

    graph.add_conditional_edges(
        "chat",
        route_after_chat,
        {
            "tools": "tools",
            "rag": "rag",
            "router": "router",
            "end": END
        }
    )

    # Unsafe response -> end
    graph.add_edge("unsafe_response", END)

    return graph


# endregion

# region === STATE DEFAULTS ===
# State defaults for reference only - DO NOT inject into graph state
# (injecting would wipe per-thread state like session_docs on every turn)
STATE_DEFAULTS: Dict[str, Any] = {
    "session_docs": [],
    "router_intent": "general",
    "router_confidence": "none",
    "router_multi_doc": False,
    "rag_context": None,
    "last_resolved_query": None,
    "last_assistant_answer": None,
    "last_suggestive_question": None,
}
# endregion

# Valid modes for the chat system
CHAT_MODES = ["auto", "rag", "general"]


# region === USER CONTEXT FOR PERSONALIZATION ===
class UserContext:
    """
    User context for personalizing responses.
    Pass this to ShortTermMemoryChat to customize how the assistant addresses the user.
    """

    def __init__(
            self,
            username: str = "User",
            response_style: str = "detailed",  # "brief", "detailed", "technical", "casual"
            language_preference: str = "auto",  # "auto", "english", "hindi", etc.
            custom_instructions: str = "",  # Any additional instructions
    ):
        self.username = username
        self.response_style = response_style
        self.language_preference = language_preference
        self.custom_instructions = custom_instructions

    def to_prompt_context(self) -> str:
        """Generate prompt context string for LLM."""
        parts = []

        parts.append(f"User's name: {self.username}")

        style_instructions = {
            "brief": "Keep responses concise and to the point. Use bullet points.",
            "detailed": "Provide comprehensive, well-structured responses with examples.",
            "technical": "Use technical language and include code examples where relevant.",
            "casual": "Use a friendly, conversational tone. Keep it light and approachable.",
        }
        parts.append(f"Response style: {style_instructions.get(self.response_style, style_instructions['detailed'])}")

        if self.language_preference and self.language_preference.lower() != "auto":
            # Stronger instruction to enforce dominance
            parts.append(f"FORCE LANGUAGE: {self.language_preference}")
            parts.append(f"INSTRUCTION: You MUST respond in {self.language_preference} only, regardless of what language the user types in.")

        if self.custom_instructions:
            parts.append(f"Additional instructions: {self.custom_instructions}")

        return "\n".join(parts)


# Default user context
DEFAULT_USER_CONTEXT = UserContext()


# endregion

# region === MAIN CHAT CLASS ===
class ShortTermMemoryChat:
    def __init__(
            self,
            base_url: str,
            api_key: str,
            fast_base_url: Optional[str] = None,
            fast_model: Optional[str] = None,
            main_model: Optional[str] = None,
            default_mode: str = "auto",  # Default mode: "auto", "rag", or "general"
            user_context: Optional[UserContext] = None,  # User personalization context
            checkpointer_path: Optional[str] = None,
            # Path to SQLite DB for persistent checkpoints (None = InMemorySaver)
            # Answer Model Config (Optional)
            answer_model: Optional[str] = None,
            answer_base_url: Optional[str] = None,
            answer_api_key: Optional[str] = None,
    ):
        if default_mode not in CHAT_MODES:
            raise ValueError(f"Invalid mode '{default_mode}'. Must be one of: {CHAT_MODES}")
        self.default_mode = default_mode
        self.user_context = user_context or DEFAULT_USER_CONTEXT

        # Main LLM for answers/planning/tools
        # Using ChatOpenAI with custom base_url for Chat Completions API compatible endpoints
        # See: https://docs.langchain.com/oss/python/integrations/chat
        self.llm_main = ChatOpenAI(
            model=main_model or DEFAULT_MODEL,
            base_url=base_url,
            api_key=api_key,
            temperature=Config.Models.TEMPERATURE,
        )
        self.llm_fast = ChatOpenAI(
            model=fast_model or FAST_MODEL,
            base_url=fast_base_url or base_url,
            api_key=api_key,
            temperature=Config.Models.TEMPERATURE,  # Use same temperature for consistency
        )

        # Answer LLM for user-facing responses (can be same as main or different)
        self.llm_answer = ChatOpenAI(
            model=answer_model or main_model or DEFAULT_MODEL,
            base_url=answer_base_url or base_url,
            api_key=answer_api_key or api_key,
            temperature=Config.Models.TEMPERATURE,
        )
        # Use SQLiteSaver for multi-user/API deployments, InMemorySaver for single-user
        # SQLiteSaver is thread-safe and persists across restarts
        if checkpointer_path and SQLITE_AVAILABLE:
            try:
                self.checkpointer = SqliteSaver.from_conn_string(checkpointer_path)
                log("INIT", f"Using SQLiteSaver for persistent state: {checkpointer_path}")
            except Exception as e:
                log("INIT", f"Failed to initialize SQLiteSaver: {e}, falling back to InMemorySaver")
                self.checkpointer = InMemorySaver()
        else:
            if checkpointer_path and not SQLITE_AVAILABLE:
                log("INIT", f"SQLiteSaver not available, using InMemorySaver (NOT suitable for multi-user)")
            self.checkpointer = InMemorySaver()
            if not checkpointer_path:
                log("INIT", "Using InMemorySaver (single-user mode)")
        self.tools = [rag_query]
        self.graph = build_graph(self.llm_main, self.llm_fast, self.llm_answer, MAX_MESSAGES, self.tools, self.user_context).compile(
            checkpointer=self.checkpointer)
        # Document loading removed - now using doc_qa for RAG

    def process_pdf_papers_direct(self, paper_mapping: Dict[str, str], thread_id: str = "default") -> Dict[str, Any]:
        """
        Helper method to process PDF papers directly without going through chat.
        NOTE: Disabled - embedd.py functions removed. Use doc_qa instead.

        Args:
            paper_mapping: Dictionary mapping URLs to document names.
            thread_id: Session identifier for scoping documents.

        Returns:
            Error message - functionality removed.
        """
        return {"error": "PDF processing removed - now using doc_qa for document retrieval"}

    def chat(self, user_input: str, thread_id: str, mode: Optional[str] = None):
        """
        Process a chat message (non-streaming).

        Args:
            user_input: The user's message
            thread_id: Session/thread identifier
            mode: Override mode for this message. Options:
                  - "auto": Full routing (embedding → LLM → tools/RAG/general) [default]
                  - "rag": Direct RAG query, fast document-focused responses
                  - "general": Deprioritize RAG, fast general Q&A responses
                  If None, uses the default_mode set at initialization.
        """
        import time
        start_time = time.time()

        effective_mode = mode or self.default_mode
        if effective_mode not in CHAT_MODES:
            raise ValueError(f"Invalid mode '{effective_mode}'. Must be one of: {CHAT_MODES}")

        # Log to file only
        log("CHAT", f"New turn - thread_id={thread_id}, mode={effective_mode}, input: {user_input[:100]}...")

        # Show only Q&A in console
        print(f"\nQ: {user_input}")

        # Normal flow (graph-based)
        cfg = {"configurable": {"thread_id": thread_id}}
        state = {
            "messages": [HumanMessage(content=user_input)],
            "session_id": thread_id,
            "_chat_mode": effective_mode,
        }
        out = self.graph.invoke(state, config=cfg)

        elapsed = time.time() - start_time
        log("CHAT", f"Turn complete in {elapsed:.2f}s")

        for m in reversed(out["messages"]):
            if isinstance(m, AIMessage):
                return m.content

    def chat_stream(self, user_input: str, thread_id: str, mode: Optional[str] = None):
        """
        Process a chat message with streaming output.
        Yields chunks of the final response as they're generated.

        Args:
            user_input: The user's message
            thread_id: Session/thread identifier
            mode: Override mode for this message ("auto", "rag", "general")

        Yields:
            str: Chunks of the response as they're generated
        """
        import time
        start_time = time.time()

        effective_mode = mode or self.default_mode
        if effective_mode not in CHAT_MODES:
            raise ValueError(f"Invalid mode '{effective_mode}'. Must be one of: {CHAT_MODES}")

        # Log to file only
        log("CHAT_STREAM", f"New turn - thread_id={thread_id}, mode={effective_mode}, input: {user_input[:100]}...")

        # Show only Q&A in console
        print(f"\nQ: {user_input}")
        print("A: ", end="", flush=True)

        cfg = {"configurable": {"thread_id": thread_id}}
        state = {
            "messages": [HumanMessage(content=user_input)],
            "session_id": thread_id,
            "_chat_mode": effective_mode,
            "_stream_mode": True,  # Flag for streaming
        }

        # Use stream instead of invoke
        full_response = ""
        for event in self.graph.stream(state, config=cfg, stream_mode="values"):
            # Check if we have a new AI message
            if "messages" in event:
                messages = event["messages"]
                if messages:
                    last_msg = messages[-1]
                    if isinstance(last_msg, AIMessage) and last_msg.content:
                        # Yield new content
                        new_content = last_msg.content[len(full_response):]
                        if new_content:
                            full_response = last_msg.content
                            yield new_content

        elapsed = time.time() - start_time
        print(f"\n[Time: {elapsed:.2f}s]")  # Show timing in console
        log("CHAT_STREAM", f"Turn complete in {elapsed:.2f}s, response length: {len(full_response)} chars")

