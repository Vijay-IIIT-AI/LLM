#!/usr/bin/env python
"""
Celery worker runner for Django
"""
import os
import sys
import django
from django.core.management import execute_from_command_line

if __name__ == "__main__":
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'queue_system.settings')
    django.setup()
    
    # Start Celery worker
    execute_from_command_line(['manage.py', 'celery', 'worker', '--loglevel=info', '--pool=solo'])



