const form = document.getElementById('uploadForm');
const fileInput = document.getElementById('fileInput');
const uploadResult = document.getElementById('uploadResult');
const jobStatus = document.getElementById('jobStatus');
const statusText = document.getElementById('statusText');
const downloadLink = document.getElementById('downloadLink');

let currentJobId = null;
let fileId = null;
let pollTimer = null;
let eventSource = null;

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!fileInput.files.length) return;
  const data = new FormData();
  data.append('file', fileInput.files[0]);

  uploadResult.classList.remove('hidden');
  uploadResult.textContent = 'Uploading...';
  jobStatus.classList.add('hidden');
  downloadLink.classList.add('hidden');

  try {
    const res = await fetch('/upload/', { method: 'POST', body: data });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Upload failed');

    uploadResult.textContent = 'Uploaded successfully';
    currentJobId = json.job_id;
    fileId = json.file_id;

    jobStatus.classList.remove('hidden');
    statusText.textContent = 'PENDING';

    startSSE();
  } catch (err) {
    uploadResult.textContent = `Error: ${err.message}`;
  }
});

function startSSE() {
  if (!!window.EventSource) {
    if (eventSource) eventSource.close();
    eventSource = new EventSource(`/events/${currentJobId}/`);
    eventSource.onmessage = async (e) => {
      try {
        const text = e.data;
        const json = Function('return ' + text)();
        handleStatus(json);
      } catch (err) {
        console.error('SSE parse error', err);
      }
    };
    eventSource.onerror = () => {
      eventSource.close();
      startPolling();
    };
  } else {
    startPolling();
  }
}

function startPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(checkStatus, 1500);
}

async function checkStatus() {
  if (!currentJobId) return;
  try {
    const res = await fetch(`/status/${currentJobId}/`);
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Status error');
    handleStatus(json);
  } catch (err) {
    console.error(err);
  }
}

async function handleStatus(json) {
  statusText.textContent = json.status + (json.message ? ` - ${json.message}` : '');
  if (json.status === 'SUCCESS') {
    const dl = await fetch(`/download_result/${currentJobId}/`);
    const dlJson = await dl.json();
    if (dl.ok && dlJson.url) {
      downloadLink.href = dlJson.url;
      downloadLink.classList.remove('hidden');
      downloadLink.textContent = 'Download Result';
    }
    if (eventSource) eventSource.close();
    if (pollTimer) clearInterval(pollTimer);
  }
  if (json.status === 'FAILURE') {
    if (eventSource) eventSource.close();
    if (pollTimer) clearInterval(pollTimer);
  }
}
