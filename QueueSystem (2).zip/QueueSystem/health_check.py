import os
import sys
from django.core.management import execute_from_command_line
from django.conf import settings
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'queue_system.settings')
django.setup()

from files.models import File, Job
from files.storage import save_upload, copy_to_processed, generate_download_url
from files.redis_client import get_redis
from files.minio_client import get_minio
from io import BytesIO

# Optional deps
try:
    from kombu import Connection
except Exception:
    Connection = None

try:
    from queue_system.celery_app import app as celery_app
except Exception:
    celery_app = None

try:
    import redis
except Exception:
    redis = None


def check_database():
    try:
        # Test database connection
        File.objects.count()
        Job.objects.count()
        return "ok"
    except Exception as exc:
        return f"error: {exc}"


def check_storage():
    try:
        # For MinIO, ensure connectivity and bucket
        if settings.USE_MINIO:
            client = get_minio()
            _ = client.list_buckets()

        # Write small test file via storage abstraction
        class DummyFS:
            name = "health.txt"
            content_type = "text/plain"
            
            def chunks(self):
                yield b"health-check"

        stored_path = save_upload(DummyFS())
        processed_path = copy_to_processed(stored_path, "ok")
        _ = generate_download_url(processed_path)

        # Best-effort cleanup
        if not settings.USE_MINIO:
            try:
                for p in [stored_path, processed_path]:
                    abs_path = os.path.join(settings.LOCAL_STORAGE_DIR, p)
                    if os.path.exists(abs_path):
                        os.remove(abs_path)
            except Exception:
                pass
        else:
            try:
                client = get_minio()
                def parts(obj_path: str):
                    if "/" in obj_path:
                        b, k = obj_path.split("/", 1)
                        return (b, k)
                    return (settings.MINIO_BUCKET, obj_path)
                for p in [stored_path, processed_path]:
                    b, k = parts(p)
                    client.remove_object(b, k)
            except Exception:
                pass

        return "ok"
    except Exception as exc:
        return f"error: {exc}"


def check_broker():
    if Connection is None:
        return "skip: kombu not installed"
    try:
        with Connection(settings.CELERY_BROKER_URL) as conn:
            conn.ensure_connection(max_retries=1)
        return "ok"
    except Exception as exc:
        return f"error: {exc}"


def check_celery():
    if celery_app is None:
        return "skip: celery not importable"
    try:
        replies = celery_app.control.ping(timeout=2.0)
        if not replies:
            return "warn: no workers replied (is the worker running?)"
        return f"ok: {len(replies)} worker(s) replied"
    except Exception as exc:
        return f"error: {exc}"


def check_redis_pubsub():
    if redis is None:
        return "skip: redis module not installed"
    try:
        r = redis.Redis.from_url(settings.REDIS_URL, decode_responses=True)
        p = r.pubsub()
        channel = "health:pubsub"
        p.subscribe(channel)
        r.publish(channel, "ping")
        for message in p.listen():
            if message.get("type") != "message":
                continue
            if message.get("data") == "ping":
                p.unsubscribe(channel)
                return "ok"
        return "error: no pubsub message received"
    except Exception as exc:
        return f"error: {exc}"


def main():
    results = {
        "database": check_database(),
        "storage": check_storage(),
        "broker": check_broker(),
        "celery": check_celery(),
        "redis_pubsub": check_redis_pubsub(),
        "mode": "minio" if settings.USE_MINIO else "local",
    }

    print("Health Check:")
    for key, value in results.items():
        print(f" - {key}: {value}")

    failed = any(str(v).startswith("error") for v in results.values())
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())

