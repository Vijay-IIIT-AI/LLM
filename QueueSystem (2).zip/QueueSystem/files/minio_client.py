from datetime import timedelta
from typing import BinaryIO, Optional
from urllib.parse import quote

from minio import Minio
from minio.error import S3Error
from minio.commonconfig import CopySource
from django.conf import settings


def get_minio() -> Minio:
    client = Minio(
        settings.MINIO_ENDPOINT,
        access_key=settings.MINIO_ACCESS_KEY,
        secret_key=settings.MINIO_SECRET_KEY,
        secure=settings.MINIO_SECURE,
    )
    # Ensure bucket exists
    if not client.bucket_exists(settings.MINIO_BUCKET):
        client.make_bucket(settings.MINIO_BUCKET)
    return client


def put_object_from_file(client: Minio, object_name: str, fileobj: BinaryIO, length: int, content_type: Optional[str]) -> str:
    client.put_object(
        bucket_name=settings.MINIO_BUCKET,
        object_name=object_name,
        data=fileobj,
        length=length,
        content_type=content_type,
    )
    return f"{settings.MINIO_BUCKET}/{object_name}"


def copy_object(client: Minio, source_object: str, dest_object: str) -> str:
    # source_object is like bucket/key or just key; ensure proper path
    bucket = settings.MINIO_BUCKET
    if "/" in source_object:
        parts = source_object.split("/", 1)
        if len(parts) == 2 and parts[0] and parts[1]:
            bucket, source_key = parts[0], parts[1]
        else:
            source_key = source_object
    else:
        source_key = source_object

    client.copy_object(
        bucket,
        dest_object,
        CopySource(bucket, source_key),
    )
    return f"{bucket}/{dest_object}"


def presigned_get_url(client: Minio, object_path: str) -> str:
    # object_path like bucket/key or just key under default bucket
    if "/" in object_path:
        bucket, key = object_path.split("/", 1)
    else:
        bucket, key = settings.MINIO_BUCKET, object_path

    return client.presigned_get_object(bucket, key, expires=timedelta(seconds=settings.PRESIGNED_URL_EXPIRES))

