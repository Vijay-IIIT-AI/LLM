from django.contrib import admin
from .models import File, Job


@admin.register(File)
class FileAdmin(admin.ModelAdmin):
    list_display = ['file_name', 'file_type', 'file_size', 'uploaded_at']
    list_filter = ['file_type', 'uploaded_at']
    search_fields = ['file_name']


@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    list_display = ['id', 'file', 'job_type', 'status', 'created_at']
    list_filter = ['status', 'job_type', 'created_at']
    search_fields = ['id', 'file__file_name']



