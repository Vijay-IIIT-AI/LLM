from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('upload/', views.upload_file, name='upload'),
    path('status/<str:job_id>/', views.job_status, name='status'),
    path('download/<uuid:file_id>/', views.download_file, name='download'),
    path('download_result/<str:job_id>/', views.download_result, name='download_result'),
    path('events/<str:job_id>/', views.sse_events, name='events'),
    path('local/<path:relpath>/', views.download_local, name='local'),
]



