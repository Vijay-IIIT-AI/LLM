import os
import shutil
from datetime import datetime
from typing import Optional
from django.conf import settings
from .minio_client import get_minio, put_object_from_file, presigned_get_url, copy_object


def _timestamped_name(original_name: str) -> str:
    return f"{int(datetime.utcnow().timestamp())}_{original_name}"


def save_upload(file_storage) -> str:
    """Save upload to configured backend.

    Returns a storage path string:
    - MinIO: "bucket/key"
    - Local: "uploads/<timestamp>_<filename>"
    """
    filename = file_storage.name
    content_type = getattr(file_storage, 'content_type', None) or "application/octet-stream"

    if settings.USE_MINIO:
        # Determine size for put_object
        file_storage.seek(0, os.SEEK_END)
        size = file_storage.tell()
        file_storage.seek(0)
        client = get_minio()
        object_key = f"uploads/{_timestamped_name(filename)}"
        storage_path = put_object_from_file(client, object_key, file_storage, size, content_type)
        return storage_path

    # Local filesystem
    rel_path = os.path.join("uploads", _timestamped_name(filename))
    abs_path = os.path.join(settings.LOCAL_STORAGE_DIR, rel_path)
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    
    with open(abs_path, 'wb') as f:
        for chunk in file_storage.chunks():
            f.write(chunk)
    
    return rel_path.replace("\\", "/")


def copy_to_processed(input_path: str, output_suffix: str = "processed") -> str:
    """Copy object/file to processed variant.

    Input path can be:
    - MinIO: "bucket/key" or just "key"
    - Local: relative path under LOCAL_STORAGE_DIR
    Returns same-style path as input.
    """
    if settings.USE_MINIO:
        client = get_minio()
        # derive key and dest
        if "/" in input_path:
            parts = input_path.split("/", 1)
            if len(parts) == 2 and parts[0] and parts[1]:
                bucket, key = parts
            else:
                bucket, key = settings.MINIO_BUCKET, input_path
        else:
            bucket, key = settings.MINIO_BUCKET, input_path
        dest_key = f"{key}.{output_suffix}"
        return copy_object(client, f"{bucket}/{key}", dest_key)

    # Local filesystem copy
    src_abs = os.path.join(settings.LOCAL_STORAGE_DIR, input_path)
    dest_rel = f"{input_path}.{output_suffix}"
    dest_abs = os.path.join(settings.LOCAL_STORAGE_DIR, dest_rel)
    os.makedirs(os.path.dirname(dest_abs), exist_ok=True)
    shutil.copyfile(src_abs, dest_abs)
    return dest_rel.replace("\\", "/")


def generate_download_url(object_path: str) -> str:
    """Return a URL for downloading the object/file.
    MinIO => presigned URL; Local => /local/<path>
    """
    if settings.USE_MINIO:
        client = get_minio()
        return presigned_get_url(client, object_path)
    # Local: return application route path
    return f"/local/{object_path}"


def materialize_to_temp(object_path: str) -> str:
    """Download storage object to a local temp file and return its absolute path."""
    os.makedirs(os.path.join(settings.LOCAL_STORAGE_DIR, "tmp"), exist_ok=True)
    if settings.USE_MINIO:
        client = get_minio()
        if "/" in object_path:
            bucket, key = object_path.split("/", 1)
        else:
            bucket, key = settings.MINIO_BUCKET, object_path
        tmp_abs = os.path.join(settings.LOCAL_STORAGE_DIR, "tmp", os.path.basename(key))
        client.fget_object(bucket, key, tmp_abs)
        return tmp_abs
    # Local mode: already a local relative path; copy to tmp
    src_abs = os.path.join(settings.LOCAL_STORAGE_DIR, object_path)
    tmp_abs = os.path.join(settings.LOCAL_STORAGE_DIR, "tmp", os.path.basename(object_path))
    shutil.copyfile(src_abs, tmp_abs)
    return tmp_abs


def upload_local_file(abs_path: str, dest_name: Optional[str] = None) -> str:
    """Upload a local file at abs_path to the configured backend and return its storage path."""
    file_name = dest_name or os.path.basename(abs_path)
    if settings.USE_MINIO:
        client = get_minio()
        key = f"processed/{_timestamped_name(file_name)}"
        with open(abs_path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(0)
            return put_object_from_file(client, key, f, size, None)
    # Local filesystem: move under processed/
    rel_path = os.path.join("processed", _timestamped_name(file_name))
    dest_abs = os.path.join(settings.LOCAL_STORAGE_DIR, rel_path)
    os.makedirs(os.path.dirname(dest_abs), exist_ok=True)
    shutil.copyfile(abs_path, dest_abs)
    return rel_path.replace("\\", "/")



