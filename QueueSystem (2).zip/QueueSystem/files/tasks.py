from celery import shared_task
from datetime import datetime
from typing import Optional
import os
import time

from .models import Job
from .storage import copy_to_processed, materialize_to_temp, upload_local_file
from .redis_client import publish_status
from .processors import run_translation


@shared_task(bind=True, name="process_file_task")
def process_file_task(self, input_path: str, output_suffix: str = "processed") -> Optional[str]:
    try:
        job_id = self.request.id
        job = Job.objects.get(id=job_id)
    except Job.DoesNotExist:
        return None

    try:
        # Mark started
        job.status = "STARTED"
        job.updated_at = datetime.now()
        job.save()
        publish_status(job_id, job.status, message="Worker started")

        ext = os.path.splitext(input_path)[1].lower()
        if ext == ".pptx":
            publish_status(job_id, job.status, message="Downloading PPTX")
            local_in = materialize_to_temp(input_path)
            base = os.path.splitext(os.path.basename(local_in))[0]
            local_out = os.path.join(os.path.dirname(local_in), f"{base}_ko.pptx")
            publish_status(job_id, job.status, message="Translating slides")
            result = run_translation("pptx", local_in, local_out, target_lang="Korean")
            if result.get("status") != "completed":
                raise RuntimeError(result.get("message") or "translation failed")
            publish_status(job_id, job.status, message="Uploading translated PPTX")
            result_path = upload_local_file(local_out)
        else:
            publish_status(job_id, job.status, message="Simple rename/copy")
            time.sleep(1)
            result_path = copy_to_processed(input_path, output_suffix)

        # Update job result
        job.status = "SUCCESS"
        job.result_path = result_path
        job.updated_at = datetime.now()
        job.save()
        publish_status(job_id, job.status, result_path=result_path, message="Done")
        return result_path
    except Exception as exc:
        job.status = "FAILURE"
        job.error_message = str(exc)
        job.updated_at = datetime.now()
        job.save()
        publish_status(job_id, job.status, error_message=str(exc), message="Failed")
        raise



