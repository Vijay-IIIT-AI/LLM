from typing import Optional
import redis
from django.conf import settings


def get_redis() -> redis.Redis:
    return redis.Redis.from_url(settings.REDIS_URL, decode_responses=True)


def publish_status(job_id: str, status: str, result_path: Optional[str] = None, error_message: Optional[str] = None, message: Optional[str] = None) -> None:
    payload = {
        "job_id": job_id,
        "status": status,
    }
    if result_path:
        payload["result_path"] = result_path
    if error_message:
        payload["error_message"] = error_message
    if message:
        payload["message"] = message
    get_redis().publish(f"job_status:{job_id}", str(payload))



