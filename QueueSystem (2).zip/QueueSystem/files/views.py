from django.shortcuts import render
from django.http import JsonResponse, HttpResponse, StreamingHttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.conf import settings
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
import json
import redis
import os
from .models import File, Job
from .tasks import process_file_task
from .storage import save_upload, generate_download_url


def index(request):
    return render(request, 'index.html')


@csrf_exempt
@require_http_methods(["POST"])
def upload_file(request):
    if 'file' not in request.FILES:
        return JsonResponse({"error": "No file part"}, status=400)
    
    file = request.FILES['file']
    if file.name == "":
        return JsonResponse({"error": "No selected file"}, status=400)
    
    storage_path = save_upload(file)
    
    # Create File record
    db_file = File.objects.create(
        file_name=file.name,
        file_type=file.content_type or "application/octet-stream",
        storage_path=storage_path,
    )
    
    # Enqueue processing
    async_result = process_file_task.delay(storage_path)
    job_id = async_result.id
    
    # Create Job record
    Job.objects.create(
        id=job_id,
        file=db_file,
        job_type="process",
        status="PENDING",
    )
    
    return JsonResponse({
        "file_id": str(db_file.id),
        "job_id": job_id,
        "storage_path": storage_path,
    })


def job_status(request, job_id):
    try:
        job = Job.objects.get(id=job_id)
        return JsonResponse({
            "job_id": job.id,
            "status": job.status,
            "result_path": job.result_path or "",
            "error_message": job.error_message or "",
        })
    except Job.DoesNotExist:
        return JsonResponse({"error": "Job not found"}, status=404)


def download_file(request, file_id):
    try:
        file = File.objects.get(id=file_id)
        url = generate_download_url(file.storage_path)
        return JsonResponse({"url": url})
    except File.DoesNotExist:
        return JsonResponse({"error": "File not found"}, status=404)


def download_result(request, job_id):
    try:
        job = Job.objects.get(id=job_id)
        if not job.result_path:
            return JsonResponse({"error": "Result not available"}, status=404)
        url = generate_download_url(job.result_path)
        return JsonResponse({"url": url})
    except Job.DoesNotExist:
        return JsonResponse({"error": "Job not found"}, status=404)


def sse_events(request, job_id):
    def event_stream():
        r = redis.Redis.from_url(settings.REDIS_URL, decode_responses=True)
        pubsub = r.pubsub()
        channel = f"job_status:{job_id}"
        pubsub.subscribe(channel)
        
        try:
            for message in pubsub.listen():
                if message.get("type") != "message":
                    continue
                data = message.get("data")
                yield f"data: {data}\n\n"
        finally:
            pubsub.unsubscribe(channel)
    
    return StreamingHttpResponse(event_stream(), content_type="text/event-stream")


def download_local(request, relpath):
    """Support serving local files when not using MinIO"""
    from django.conf import settings
    base = os.path.join(settings.LOCAL_STORAGE_DIR)
    # Prevent path traversal
    safe_path = os.path.normpath(os.path.join(base, relpath))
    if not safe_path.startswith(os.path.abspath(base)):
        return JsonResponse({"error": "Invalid path"}, status=400)
    
    if os.path.exists(safe_path):
        with open(safe_path, 'rb') as f:
            response = HttpResponse(f.read(), content_type='application/octet-stream')
            response['Content-Disposition'] = f'attachment; filename="{os.path.basename(safe_path)}"'
            return response
    return JsonResponse({"error": "File not found"}, status=404)



