# Queue System - Django Version

A production-ready file processing system with real-time updates, built with Django, Celery, and Redis.

## Features

- **File Upload**: Drag & drop or file picker with progress tracking
- **Background Processing**: Celery workers for async file processing
- **Real-time Updates**: Server-Sent Events (SSE) for live status updates
- **Storage Backend**: MinIO (S3-compatible) or local filesystem
- **Translation**: Built-in PPTX translation using Mistral AI
- **Admin Interface**: Django admin for managing files and jobs

## Architecture

```
Browser → Django → Celery → Redis → MinIO/Local Storage
```

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run Migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### 3. Create Superuser (Optional)
```bash
python manage.py createsuperuser
```

### 4. Start Services

**Option A: With Redis (Real-time updates)**
```bash
# Terminal 1: Start Django
python manage.py runserver 0.0.0.0:5000

# Terminal 2: Start Celery worker
python manage.py celery worker --loglevel=info --pool=solo

# Terminal 3: Start Redis (if using local Redis)
redis-server
```

**Option B: Without Redis (Polling only)**
```bash
# Terminal 1: Start Django
python manage.py runserver 0.0.0.0:5000

# Terminal 2: Start Celery worker
python manage.py celery worker --loglevel=info --pool=solo
```

### 5. Access the Application
- **Main App**: http://127.0.0.1:5000
- **Admin Interface**: http://127.0.0.1:5000/admin

## Configuration

Edit `queue_system/settings.py`:

```python
# Storage backend
USE_MINIO = False  # Set to True for MinIO, False for local filesystem

# MinIO settings (if USE_MINIO = True)
MINIO_ENDPOINT = "127.0.0.1:9000"
MINIO_ACCESS_KEY = "minioadmin"
MINIO_SECRET_KEY = "minioadmin"

# Celery settings
CELERY_BROKER_URL = "amqp://guest:guest@localhost:5672//"
CELERY_RESULT_BACKEND = "rpc://"

# Redis settings (for real-time updates)
REDIS_URL = "redis://localhost:6379/0"

# Translation API
MISTRAL_API_KEY = "your-api-key"
MISTRAL_API_URL = "https://api.mistral.ai/v1/chat/completions"
```

## Health Check

```bash
python health_check.py
```

## API Endpoints

- `GET /` - Main upload interface
- `POST /upload/` - Upload file
- `GET /status/<job_id>/` - Get job status
- `GET /download/<file_id>/` - Download original file
- `GET /download_result/<job_id>/` - Download processed file
- `GET /events/<job_id>/` - SSE stream for real-time updates
- `GET /local/<path>/` - Serve local files

## File Processing

### PPTX Files
- Automatically translated to Korean using Mistral AI
- Creates `_ko.pptx` version
- Processing time: ~5-10 seconds

### Other Files
- Simple copy with `.processed` suffix
- Processing time: ~1 second

## Production Deployment

### With Redis (Recommended)
- Use Redis Cloud or self-hosted Redis cluster
- Configure Redis connection pooling
- Set up monitoring and alerts

### Without Redis (Simpler)
- Remove Redis dependency
- Use polling for status updates
- Simpler deployment, less real-time

## Monitoring

- **Django Admin**: View files, jobs, and status
- **Celery Flower**: Monitor worker tasks
- **Health Check**: Verify all services

## Troubleshooting

1. **Celery worker not starting**: Ensure RabbitMQ is running
2. **SSE not working**: Check Redis connection
3. **File upload fails**: Verify storage backend (MinIO/local)
4. **Translation fails**: Check Mistral API key

## Development

```bash
# Run tests
python manage.py test

# Create migrations
python manage.py makemigrations

# Apply migrations
python manage.py migrate

# Start development server
python manage.py runserver
```


