# Navigate to the pdf2zh directory
import sys
sys.path.append(r'C:\Users\Vijay\Downloads\PDFMathTranslate-main\PDFMathTranslate-main\pdf2zh')

from V3_translate.main import translate_pdf

# Translate your PDF
mono_pdf, dual_pdf = translate_pdf(
    input_pdf_path=r"C:\Users\Vijay\Downloads\PDFMathTranslate-main\PDFMathTranslate-main\pdf2zh\V3_translate\a_1.pdf",
    output_dir=r"C:\Users\Vijay\Downloads\translated_pdfs",
    lang_in="en",
    lang_out="tamil",
    pages=None,  # All pages, or [1,2,3] for specific pages
    thread=4
)

print(f"✅ Translation completed!")
print(f"📄 Korean only: {mono_pdf}")
print(f"📄 Original + Korean: {dual_pdf}")
print(f"📄 Original + Korean: {dual_pdf}")